package com.example.gestaobilhares.data.dao;

import android.database.Cursor;
import android.os.CancellationSignal;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.room.CoroutinesRoom;
import androidx.room.EntityDeletionOrUpdateAdapter;
import androidx.room.EntityInsertionAdapter;
import androidx.room.RoomDatabase;
import androidx.room.RoomSQLiteQuery;
import androidx.room.SharedSQLiteStatement;
import androidx.room.util.CursorUtil;
import androidx.room.util.DBUtil;
import androidx.sqlite.db.SupportSQLiteStatement;
import com.example.gestaobilhares.data.database.Converters;
import com.example.gestaobilhares.data.entities.Despesa;
import com.example.gestaobilhares.data.entities.DespesaResumo;
import java.lang.Class;
import java.lang.Double;
import java.lang.Exception;
import java.lang.Integer;
import java.lang.Long;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.lang.SuppressWarnings;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.Callable;
import javax.annotation.processing.Generated;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlinx.coroutines.flow.Flow;

@Generated("androidx.room.RoomProcessor")
@SuppressWarnings({"unchecked", "deprecation"})
public final class DespesaDao_Impl implements DespesaDao {
  private final RoomDatabase __db;

  private final EntityInsertionAdapter<Despesa> __insertionAdapterOfDespesa;

  private final Converters __converters = new Converters();

  private final EntityDeletionOrUpdateAdapter<Despesa> __deletionAdapterOfDespesa;

  private final EntityDeletionOrUpdateAdapter<Despesa> __updateAdapterOfDespesa;

  private final SharedSQLiteStatement __preparedStmtOfDeletarPorRota;

  public DespesaDao_Impl(@NonNull final RoomDatabase __db) {
    this.__db = __db;
    this.__insertionAdapterOfDespesa = new EntityInsertionAdapter<Despesa>(__db) {
      @Override
      @NonNull
      protected String createQuery() {
        return "INSERT OR ABORT INTO `despesas` (`id`,`rotaId`,`descricao`,`valor`,`categoria`,`dataHora`,`observacoes`,`criadoPor`) VALUES (nullif(?, 0),?,?,?,?,?,?,?)";
      }

      @Override
      protected void bind(@NonNull final SupportSQLiteStatement statement,
          @NonNull final Despesa entity) {
        statement.bindLong(1, entity.getId());
        statement.bindLong(2, entity.getRotaId());
        if (entity.getDescricao() == null) {
          statement.bindNull(3);
        } else {
          statement.bindString(3, entity.getDescricao());
        }
        statement.bindDouble(4, entity.getValor());
        if (entity.getCategoria() == null) {
          statement.bindNull(5);
        } else {
          statement.bindString(5, entity.getCategoria());
        }
        final String _tmp = __converters.fromLocalDateTime(entity.getDataHora());
        if (_tmp == null) {
          statement.bindNull(6);
        } else {
          statement.bindString(6, _tmp);
        }
        if (entity.getObservacoes() == null) {
          statement.bindNull(7);
        } else {
          statement.bindString(7, entity.getObservacoes());
        }
        if (entity.getCriadoPor() == null) {
          statement.bindNull(8);
        } else {
          statement.bindString(8, entity.getCriadoPor());
        }
      }
    };
    this.__deletionAdapterOfDespesa = new EntityDeletionOrUpdateAdapter<Despesa>(__db) {
      @Override
      @NonNull
      protected String createQuery() {
        return "DELETE FROM `despesas` WHERE `id` = ?";
      }

      @Override
      protected void bind(@NonNull final SupportSQLiteStatement statement,
          @NonNull final Despesa entity) {
        statement.bindLong(1, entity.getId());
      }
    };
    this.__updateAdapterOfDespesa = new EntityDeletionOrUpdateAdapter<Despesa>(__db) {
      @Override
      @NonNull
      protected String createQuery() {
        return "UPDATE OR ABORT `despesas` SET `id` = ?,`rotaId` = ?,`descricao` = ?,`valor` = ?,`categoria` = ?,`dataHora` = ?,`observacoes` = ?,`criadoPor` = ? WHERE `id` = ?";
      }

      @Override
      protected void bind(@NonNull final SupportSQLiteStatement statement,
          @NonNull final Despesa entity) {
        statement.bindLong(1, entity.getId());
        statement.bindLong(2, entity.getRotaId());
        if (entity.getDescricao() == null) {
          statement.bindNull(3);
        } else {
          statement.bindString(3, entity.getDescricao());
        }
        statement.bindDouble(4, entity.getValor());
        if (entity.getCategoria() == null) {
          statement.bindNull(5);
        } else {
          statement.bindString(5, entity.getCategoria());
        }
        final String _tmp = __converters.fromLocalDateTime(entity.getDataHora());
        if (_tmp == null) {
          statement.bindNull(6);
        } else {
          statement.bindString(6, _tmp);
        }
        if (entity.getObservacoes() == null) {
          statement.bindNull(7);
        } else {
          statement.bindString(7, entity.getObservacoes());
        }
        if (entity.getCriadoPor() == null) {
          statement.bindNull(8);
        } else {
          statement.bindString(8, entity.getCriadoPor());
        }
        statement.bindLong(9, entity.getId());
      }
    };
    this.__preparedStmtOfDeletarPorRota = new SharedSQLiteStatement(__db) {
      @Override
      @NonNull
      public String createQuery() {
        final String _query = "DELETE FROM despesas WHERE rotaId = ?";
        return _query;
      }
    };
  }

  @Override
  public Object inserir(final Despesa despesa, final Continuation<? super Long> arg1) {
    return CoroutinesRoom.execute(__db, true, new Callable<Long>() {
      @Override
      @NonNull
      public Long call() throws Exception {
        __db.beginTransaction();
        try {
          final Long _result = __insertionAdapterOfDespesa.insertAndReturnId(despesa);
          __db.setTransactionSuccessful();
          return _result;
        } finally {
          __db.endTransaction();
        }
      }
    }, arg1);
  }

  @Override
  public Object deletar(final Despesa despesa, final Continuation<? super Unit> arg1) {
    return CoroutinesRoom.execute(__db, true, new Callable<Unit>() {
      @Override
      @NonNull
      public Unit call() throws Exception {
        __db.beginTransaction();
        try {
          __deletionAdapterOfDespesa.handle(despesa);
          __db.setTransactionSuccessful();
          return Unit.INSTANCE;
        } finally {
          __db.endTransaction();
        }
      }
    }, arg1);
  }

  @Override
  public Object atualizar(final Despesa despesa, final Continuation<? super Unit> arg1) {
    return CoroutinesRoom.execute(__db, true, new Callable<Unit>() {
      @Override
      @NonNull
      public Unit call() throws Exception {
        __db.beginTransaction();
        try {
          __updateAdapterOfDespesa.handle(despesa);
          __db.setTransactionSuccessful();
          return Unit.INSTANCE;
        } finally {
          __db.endTransaction();
        }
      }
    }, arg1);
  }

  @Override
  public Object deletarPorRota(final long rotaId, final Continuation<? super Unit> arg1) {
    return CoroutinesRoom.execute(__db, true, new Callable<Unit>() {
      @Override
      @NonNull
      public Unit call() throws Exception {
        final SupportSQLiteStatement _stmt = __preparedStmtOfDeletarPorRota.acquire();
        int _argIndex = 1;
        _stmt.bindLong(_argIndex, rotaId);
        try {
          __db.beginTransaction();
          try {
            _stmt.executeUpdateDelete();
            __db.setTransactionSuccessful();
            return Unit.INSTANCE;
          } finally {
            __db.endTransaction();
          }
        } finally {
          __preparedStmtOfDeletarPorRota.release(_stmt);
        }
      }
    }, arg1);
  }

  @Override
  public Object buscarPorId(final long id, final Continuation<? super Despesa> arg1) {
    final String _sql = "SELECT * FROM despesas WHERE id = ?";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 1);
    int _argIndex = 1;
    _statement.bindLong(_argIndex, id);
    final CancellationSignal _cancellationSignal = DBUtil.createCancellationSignal();
    return CoroutinesRoom.execute(__db, false, _cancellationSignal, new Callable<Despesa>() {
      @Override
      @Nullable
      public Despesa call() throws Exception {
        final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
        try {
          final int _cursorIndexOfId = CursorUtil.getColumnIndexOrThrow(_cursor, "id");
          final int _cursorIndexOfRotaId = CursorUtil.getColumnIndexOrThrow(_cursor, "rotaId");
          final int _cursorIndexOfDescricao = CursorUtil.getColumnIndexOrThrow(_cursor, "descricao");
          final int _cursorIndexOfValor = CursorUtil.getColumnIndexOrThrow(_cursor, "valor");
          final int _cursorIndexOfCategoria = CursorUtil.getColumnIndexOrThrow(_cursor, "categoria");
          final int _cursorIndexOfDataHora = CursorUtil.getColumnIndexOrThrow(_cursor, "dataHora");
          final int _cursorIndexOfObservacoes = CursorUtil.getColumnIndexOrThrow(_cursor, "observacoes");
          final int _cursorIndexOfCriadoPor = CursorUtil.getColumnIndexOrThrow(_cursor, "criadoPor");
          final Despesa _result;
          if (_cursor.moveToFirst()) {
            final long _tmpId;
            _tmpId = _cursor.getLong(_cursorIndexOfId);
            final long _tmpRotaId;
            _tmpRotaId = _cursor.getLong(_cursorIndexOfRotaId);
            final String _tmpDescricao;
            if (_cursor.isNull(_cursorIndexOfDescricao)) {
              _tmpDescricao = null;
            } else {
              _tmpDescricao = _cursor.getString(_cursorIndexOfDescricao);
            }
            final double _tmpValor;
            _tmpValor = _cursor.getDouble(_cursorIndexOfValor);
            final String _tmpCategoria;
            if (_cursor.isNull(_cursorIndexOfCategoria)) {
              _tmpCategoria = null;
            } else {
              _tmpCategoria = _cursor.getString(_cursorIndexOfCategoria);
            }
            final LocalDateTime _tmpDataHora;
            final String _tmp;
            if (_cursor.isNull(_cursorIndexOfDataHora)) {
              _tmp = null;
            } else {
              _tmp = _cursor.getString(_cursorIndexOfDataHora);
            }
            _tmpDataHora = __converters.toLocalDateTime(_tmp);
            final String _tmpObservacoes;
            if (_cursor.isNull(_cursorIndexOfObservacoes)) {
              _tmpObservacoes = null;
            } else {
              _tmpObservacoes = _cursor.getString(_cursorIndexOfObservacoes);
            }
            final String _tmpCriadoPor;
            if (_cursor.isNull(_cursorIndexOfCriadoPor)) {
              _tmpCriadoPor = null;
            } else {
              _tmpCriadoPor = _cursor.getString(_cursorIndexOfCriadoPor);
            }
            _result = new Despesa(_tmpId,_tmpRotaId,_tmpDescricao,_tmpValor,_tmpCategoria,_tmpDataHora,_tmpObservacoes,_tmpCriadoPor);
          } else {
            _result = null;
          }
          return _result;
        } finally {
          _cursor.close();
          _statement.release();
        }
      }
    }, arg1);
  }

  @Override
  public Flow<List<Despesa>> buscarPorRota(final long rotaId) {
    final String _sql = "SELECT * FROM despesas WHERE rotaId = ? ORDER BY dataHora DESC";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 1);
    int _argIndex = 1;
    _statement.bindLong(_argIndex, rotaId);
    return CoroutinesRoom.createFlow(__db, false, new String[] {"despesas"}, new Callable<List<Despesa>>() {
      @Override
      @NonNull
      public List<Despesa> call() throws Exception {
        final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
        try {
          final int _cursorIndexOfId = CursorUtil.getColumnIndexOrThrow(_cursor, "id");
          final int _cursorIndexOfRotaId = CursorUtil.getColumnIndexOrThrow(_cursor, "rotaId");
          final int _cursorIndexOfDescricao = CursorUtil.getColumnIndexOrThrow(_cursor, "descricao");
          final int _cursorIndexOfValor = CursorUtil.getColumnIndexOrThrow(_cursor, "valor");
          final int _cursorIndexOfCategoria = CursorUtil.getColumnIndexOrThrow(_cursor, "categoria");
          final int _cursorIndexOfDataHora = CursorUtil.getColumnIndexOrThrow(_cursor, "dataHora");
          final int _cursorIndexOfObservacoes = CursorUtil.getColumnIndexOrThrow(_cursor, "observacoes");
          final int _cursorIndexOfCriadoPor = CursorUtil.getColumnIndexOrThrow(_cursor, "criadoPor");
          final List<Despesa> _result = new ArrayList<Despesa>(_cursor.getCount());
          while (_cursor.moveToNext()) {
            final Despesa _item;
            final long _tmpId;
            _tmpId = _cursor.getLong(_cursorIndexOfId);
            final long _tmpRotaId;
            _tmpRotaId = _cursor.getLong(_cursorIndexOfRotaId);
            final String _tmpDescricao;
            if (_cursor.isNull(_cursorIndexOfDescricao)) {
              _tmpDescricao = null;
            } else {
              _tmpDescricao = _cursor.getString(_cursorIndexOfDescricao);
            }
            final double _tmpValor;
            _tmpValor = _cursor.getDouble(_cursorIndexOfValor);
            final String _tmpCategoria;
            if (_cursor.isNull(_cursorIndexOfCategoria)) {
              _tmpCategoria = null;
            } else {
              _tmpCategoria = _cursor.getString(_cursorIndexOfCategoria);
            }
            final LocalDateTime _tmpDataHora;
            final String _tmp;
            if (_cursor.isNull(_cursorIndexOfDataHora)) {
              _tmp = null;
            } else {
              _tmp = _cursor.getString(_cursorIndexOfDataHora);
            }
            _tmpDataHora = __converters.toLocalDateTime(_tmp);
            final String _tmpObservacoes;
            if (_cursor.isNull(_cursorIndexOfObservacoes)) {
              _tmpObservacoes = null;
            } else {
              _tmpObservacoes = _cursor.getString(_cursorIndexOfObservacoes);
            }
            final String _tmpCriadoPor;
            if (_cursor.isNull(_cursorIndexOfCriadoPor)) {
              _tmpCriadoPor = null;
            } else {
              _tmpCriadoPor = _cursor.getString(_cursorIndexOfCriadoPor);
            }
            _item = new Despesa(_tmpId,_tmpRotaId,_tmpDescricao,_tmpValor,_tmpCategoria,_tmpDataHora,_tmpObservacoes,_tmpCriadoPor);
            _result.add(_item);
          }
          return _result;
        } finally {
          _cursor.close();
        }
      }

      @Override
      protected void finalize() {
        _statement.release();
      }
    });
  }

  @Override
  public Flow<List<DespesaResumo>> buscarTodasComRota() {
    final String _sql = "\n"
            + "        SELECT d.*, r.nome as nomeRota \n"
            + "        FROM despesas d \n"
            + "        INNER JOIN rotas r ON d.rotaId = r.id \n"
            + "        ORDER BY d.dataHora DESC\n"
            + "    ";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 0);
    return CoroutinesRoom.createFlow(__db, false, new String[] {"despesas",
        "rotas"}, new Callable<List<DespesaResumo>>() {
      @Override
      @NonNull
      public List<DespesaResumo> call() throws Exception {
        final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
        try {
          final int _cursorIndexOfId = CursorUtil.getColumnIndexOrThrow(_cursor, "id");
          final int _cursorIndexOfRotaId = CursorUtil.getColumnIndexOrThrow(_cursor, "rotaId");
          final int _cursorIndexOfDescricao = CursorUtil.getColumnIndexOrThrow(_cursor, "descricao");
          final int _cursorIndexOfValor = CursorUtil.getColumnIndexOrThrow(_cursor, "valor");
          final int _cursorIndexOfCategoria = CursorUtil.getColumnIndexOrThrow(_cursor, "categoria");
          final int _cursorIndexOfDataHora = CursorUtil.getColumnIndexOrThrow(_cursor, "dataHora");
          final int _cursorIndexOfObservacoes = CursorUtil.getColumnIndexOrThrow(_cursor, "observacoes");
          final int _cursorIndexOfCriadoPor = CursorUtil.getColumnIndexOrThrow(_cursor, "criadoPor");
          final int _cursorIndexOfNomeRota = CursorUtil.getColumnIndexOrThrow(_cursor, "nomeRota");
          final List<DespesaResumo> _result = new ArrayList<DespesaResumo>(_cursor.getCount());
          while (_cursor.moveToNext()) {
            final DespesaResumo _item;
            final long _tmpId;
            _tmpId = _cursor.getLong(_cursorIndexOfId);
            final long _tmpRotaId;
            _tmpRotaId = _cursor.getLong(_cursorIndexOfRotaId);
            final String _tmpDescricao;
            if (_cursor.isNull(_cursorIndexOfDescricao)) {
              _tmpDescricao = null;
            } else {
              _tmpDescricao = _cursor.getString(_cursorIndexOfDescricao);
            }
            final double _tmpValor;
            _tmpValor = _cursor.getDouble(_cursorIndexOfValor);
            final String _tmpCategoria;
            if (_cursor.isNull(_cursorIndexOfCategoria)) {
              _tmpCategoria = null;
            } else {
              _tmpCategoria = _cursor.getString(_cursorIndexOfCategoria);
            }
            final LocalDateTime _tmpDataHora;
            final String _tmp;
            if (_cursor.isNull(_cursorIndexOfDataHora)) {
              _tmp = null;
            } else {
              _tmp = _cursor.getString(_cursorIndexOfDataHora);
            }
            _tmpDataHora = __converters.toLocalDateTime(_tmp);
            final String _tmpObservacoes;
            if (_cursor.isNull(_cursorIndexOfObservacoes)) {
              _tmpObservacoes = null;
            } else {
              _tmpObservacoes = _cursor.getString(_cursorIndexOfObservacoes);
            }
            final String _tmpCriadoPor;
            if (_cursor.isNull(_cursorIndexOfCriadoPor)) {
              _tmpCriadoPor = null;
            } else {
              _tmpCriadoPor = _cursor.getString(_cursorIndexOfCriadoPor);
            }
            final String _tmpNomeRota;
            if (_cursor.isNull(_cursorIndexOfNomeRota)) {
              _tmpNomeRota = null;
            } else {
              _tmpNomeRota = _cursor.getString(_cursorIndexOfNomeRota);
            }
            _item = new DespesaResumo(_tmpId,_tmpRotaId,_tmpDescricao,_tmpValor,_tmpCategoria,_tmpDataHora,_tmpObservacoes,_tmpCriadoPor,_tmpNomeRota);
            _result.add(_item);
          }
          return _result;
        } finally {
          _cursor.close();
        }
      }

      @Override
      protected void finalize() {
        _statement.release();
      }
    });
  }

  @Override
  public Flow<List<DespesaResumo>> buscarPorPeriodo(final LocalDateTime dataInicio,
      final LocalDateTime dataFim) {
    final String _sql = "\n"
            + "        SELECT d.*, r.nome as nomeRota \n"
            + "        FROM despesas d \n"
            + "        INNER JOIN rotas r ON d.rotaId = r.id \n"
            + "        WHERE d.dataHora BETWEEN ? AND ? \n"
            + "        ORDER BY d.dataHora DESC\n"
            + "    ";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 2);
    int _argIndex = 1;
    final String _tmp = __converters.fromLocalDateTime(dataInicio);
    if (_tmp == null) {
      _statement.bindNull(_argIndex);
    } else {
      _statement.bindString(_argIndex, _tmp);
    }
    _argIndex = 2;
    final String _tmp_1 = __converters.fromLocalDateTime(dataFim);
    if (_tmp_1 == null) {
      _statement.bindNull(_argIndex);
    } else {
      _statement.bindString(_argIndex, _tmp_1);
    }
    return CoroutinesRoom.createFlow(__db, false, new String[] {"despesas",
        "rotas"}, new Callable<List<DespesaResumo>>() {
      @Override
      @NonNull
      public List<DespesaResumo> call() throws Exception {
        final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
        try {
          final int _cursorIndexOfId = CursorUtil.getColumnIndexOrThrow(_cursor, "id");
          final int _cursorIndexOfRotaId = CursorUtil.getColumnIndexOrThrow(_cursor, "rotaId");
          final int _cursorIndexOfDescricao = CursorUtil.getColumnIndexOrThrow(_cursor, "descricao");
          final int _cursorIndexOfValor = CursorUtil.getColumnIndexOrThrow(_cursor, "valor");
          final int _cursorIndexOfCategoria = CursorUtil.getColumnIndexOrThrow(_cursor, "categoria");
          final int _cursorIndexOfDataHora = CursorUtil.getColumnIndexOrThrow(_cursor, "dataHora");
          final int _cursorIndexOfObservacoes = CursorUtil.getColumnIndexOrThrow(_cursor, "observacoes");
          final int _cursorIndexOfCriadoPor = CursorUtil.getColumnIndexOrThrow(_cursor, "criadoPor");
          final int _cursorIndexOfNomeRota = CursorUtil.getColumnIndexOrThrow(_cursor, "nomeRota");
          final List<DespesaResumo> _result = new ArrayList<DespesaResumo>(_cursor.getCount());
          while (_cursor.moveToNext()) {
            final DespesaResumo _item;
            final long _tmpId;
            _tmpId = _cursor.getLong(_cursorIndexOfId);
            final long _tmpRotaId;
            _tmpRotaId = _cursor.getLong(_cursorIndexOfRotaId);
            final String _tmpDescricao;
            if (_cursor.isNull(_cursorIndexOfDescricao)) {
              _tmpDescricao = null;
            } else {
              _tmpDescricao = _cursor.getString(_cursorIndexOfDescricao);
            }
            final double _tmpValor;
            _tmpValor = _cursor.getDouble(_cursorIndexOfValor);
            final String _tmpCategoria;
            if (_cursor.isNull(_cursorIndexOfCategoria)) {
              _tmpCategoria = null;
            } else {
              _tmpCategoria = _cursor.getString(_cursorIndexOfCategoria);
            }
            final LocalDateTime _tmpDataHora;
            final String _tmp_2;
            if (_cursor.isNull(_cursorIndexOfDataHora)) {
              _tmp_2 = null;
            } else {
              _tmp_2 = _cursor.getString(_cursorIndexOfDataHora);
            }
            _tmpDataHora = __converters.toLocalDateTime(_tmp_2);
            final String _tmpObservacoes;
            if (_cursor.isNull(_cursorIndexOfObservacoes)) {
              _tmpObservacoes = null;
            } else {
              _tmpObservacoes = _cursor.getString(_cursorIndexOfObservacoes);
            }
            final String _tmpCriadoPor;
            if (_cursor.isNull(_cursorIndexOfCriadoPor)) {
              _tmpCriadoPor = null;
            } else {
              _tmpCriadoPor = _cursor.getString(_cursorIndexOfCriadoPor);
            }
            final String _tmpNomeRota;
            if (_cursor.isNull(_cursorIndexOfNomeRota)) {
              _tmpNomeRota = null;
            } else {
              _tmpNomeRota = _cursor.getString(_cursorIndexOfNomeRota);
            }
            _item = new DespesaResumo(_tmpId,_tmpRotaId,_tmpDescricao,_tmpValor,_tmpCategoria,_tmpDataHora,_tmpObservacoes,_tmpCriadoPor,_tmpNomeRota);
            _result.add(_item);
          }
          return _result;
        } finally {
          _cursor.close();
        }
      }

      @Override
      protected void finalize() {
        _statement.release();
      }
    });
  }

  @Override
  public Flow<List<DespesaResumo>> buscarPorCategoria(final String categoria) {
    final String _sql = "\n"
            + "        SELECT d.*, r.nome as nomeRota \n"
            + "        FROM despesas d \n"
            + "        INNER JOIN rotas r ON d.rotaId = r.id \n"
            + "        WHERE d.categoria = ? \n"
            + "        ORDER BY d.dataHora DESC\n"
            + "    ";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 1);
    int _argIndex = 1;
    if (categoria == null) {
      _statement.bindNull(_argIndex);
    } else {
      _statement.bindString(_argIndex, categoria);
    }
    return CoroutinesRoom.createFlow(__db, false, new String[] {"despesas",
        "rotas"}, new Callable<List<DespesaResumo>>() {
      @Override
      @NonNull
      public List<DespesaResumo> call() throws Exception {
        final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
        try {
          final int _cursorIndexOfId = CursorUtil.getColumnIndexOrThrow(_cursor, "id");
          final int _cursorIndexOfRotaId = CursorUtil.getColumnIndexOrThrow(_cursor, "rotaId");
          final int _cursorIndexOfDescricao = CursorUtil.getColumnIndexOrThrow(_cursor, "descricao");
          final int _cursorIndexOfValor = CursorUtil.getColumnIndexOrThrow(_cursor, "valor");
          final int _cursorIndexOfCategoria = CursorUtil.getColumnIndexOrThrow(_cursor, "categoria");
          final int _cursorIndexOfDataHora = CursorUtil.getColumnIndexOrThrow(_cursor, "dataHora");
          final int _cursorIndexOfObservacoes = CursorUtil.getColumnIndexOrThrow(_cursor, "observacoes");
          final int _cursorIndexOfCriadoPor = CursorUtil.getColumnIndexOrThrow(_cursor, "criadoPor");
          final int _cursorIndexOfNomeRota = CursorUtil.getColumnIndexOrThrow(_cursor, "nomeRota");
          final List<DespesaResumo> _result = new ArrayList<DespesaResumo>(_cursor.getCount());
          while (_cursor.moveToNext()) {
            final DespesaResumo _item;
            final long _tmpId;
            _tmpId = _cursor.getLong(_cursorIndexOfId);
            final long _tmpRotaId;
            _tmpRotaId = _cursor.getLong(_cursorIndexOfRotaId);
            final String _tmpDescricao;
            if (_cursor.isNull(_cursorIndexOfDescricao)) {
              _tmpDescricao = null;
            } else {
              _tmpDescricao = _cursor.getString(_cursorIndexOfDescricao);
            }
            final double _tmpValor;
            _tmpValor = _cursor.getDouble(_cursorIndexOfValor);
            final String _tmpCategoria;
            if (_cursor.isNull(_cursorIndexOfCategoria)) {
              _tmpCategoria = null;
            } else {
              _tmpCategoria = _cursor.getString(_cursorIndexOfCategoria);
            }
            final LocalDateTime _tmpDataHora;
            final String _tmp;
            if (_cursor.isNull(_cursorIndexOfDataHora)) {
              _tmp = null;
            } else {
              _tmp = _cursor.getString(_cursorIndexOfDataHora);
            }
            _tmpDataHora = __converters.toLocalDateTime(_tmp);
            final String _tmpObservacoes;
            if (_cursor.isNull(_cursorIndexOfObservacoes)) {
              _tmpObservacoes = null;
            } else {
              _tmpObservacoes = _cursor.getString(_cursorIndexOfObservacoes);
            }
            final String _tmpCriadoPor;
            if (_cursor.isNull(_cursorIndexOfCriadoPor)) {
              _tmpCriadoPor = null;
            } else {
              _tmpCriadoPor = _cursor.getString(_cursorIndexOfCriadoPor);
            }
            final String _tmpNomeRota;
            if (_cursor.isNull(_cursorIndexOfNomeRota)) {
              _tmpNomeRota = null;
            } else {
              _tmpNomeRota = _cursor.getString(_cursorIndexOfNomeRota);
            }
            _item = new DespesaResumo(_tmpId,_tmpRotaId,_tmpDescricao,_tmpValor,_tmpCategoria,_tmpDataHora,_tmpObservacoes,_tmpCriadoPor,_tmpNomeRota);
            _result.add(_item);
          }
          return _result;
        } finally {
          _cursor.close();
        }
      }

      @Override
      protected void finalize() {
        _statement.release();
      }
    });
  }

  @Override
  public Object calcularTotalPorRota(final long rotaId, final Continuation<? super Double> arg1) {
    final String _sql = "SELECT COALESCE(SUM(valor), 0.0) FROM despesas WHERE rotaId = ?";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 1);
    int _argIndex = 1;
    _statement.bindLong(_argIndex, rotaId);
    final CancellationSignal _cancellationSignal = DBUtil.createCancellationSignal();
    return CoroutinesRoom.execute(__db, false, _cancellationSignal, new Callable<Double>() {
      @Override
      @NonNull
      public Double call() throws Exception {
        final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
        try {
          final Double _result;
          if (_cursor.moveToFirst()) {
            final Double _tmp;
            if (_cursor.isNull(0)) {
              _tmp = null;
            } else {
              _tmp = _cursor.getDouble(0);
            }
            _result = _tmp;
          } else {
            _result = null;
          }
          return _result;
        } finally {
          _cursor.close();
          _statement.release();
        }
      }
    }, arg1);
  }

  @Override
  public Object calcularTotalGeral(final Continuation<? super Double> arg0) {
    final String _sql = "SELECT COALESCE(SUM(valor), 0.0) FROM despesas";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 0);
    final CancellationSignal _cancellationSignal = DBUtil.createCancellationSignal();
    return CoroutinesRoom.execute(__db, false, _cancellationSignal, new Callable<Double>() {
      @Override
      @NonNull
      public Double call() throws Exception {
        final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
        try {
          final Double _result;
          if (_cursor.moveToFirst()) {
            final Double _tmp;
            if (_cursor.isNull(0)) {
              _tmp = null;
            } else {
              _tmp = _cursor.getDouble(0);
            }
            _result = _tmp;
          } else {
            _result = null;
          }
          return _result;
        } finally {
          _cursor.close();
          _statement.release();
        }
      }
    }, arg0);
  }

  @Override
  public Object contarPorRota(final long rotaId, final Continuation<? super Integer> arg1) {
    final String _sql = "SELECT COUNT(*) FROM despesas WHERE rotaId = ?";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 1);
    int _argIndex = 1;
    _statement.bindLong(_argIndex, rotaId);
    final CancellationSignal _cancellationSignal = DBUtil.createCancellationSignal();
    return CoroutinesRoom.execute(__db, false, _cancellationSignal, new Callable<Integer>() {
      @Override
      @NonNull
      public Integer call() throws Exception {
        final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
        try {
          final Integer _result;
          if (_cursor.moveToFirst()) {
            final Integer _tmp;
            if (_cursor.isNull(0)) {
              _tmp = null;
            } else {
              _tmp = _cursor.getInt(0);
            }
            _result = _tmp;
          } else {
            _result = null;
          }
          return _result;
        } finally {
          _cursor.close();
          _statement.release();
        }
      }
    }, arg1);
  }

  @Override
  public Object buscarPorRotaEPeriodo(final long rotaId, final LocalDateTime dataInicio,
      final LocalDateTime dataFim, final Continuation<? super List<Despesa>> arg3) {
    final String _sql = "\n"
            + "        SELECT * FROM despesas \n"
            + "        WHERE rotaId = ? AND dataHora BETWEEN ? AND ? \n"
            + "        ORDER BY dataHora DESC\n"
            + "    ";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 3);
    int _argIndex = 1;
    _statement.bindLong(_argIndex, rotaId);
    _argIndex = 2;
    final String _tmp = __converters.fromLocalDateTime(dataInicio);
    if (_tmp == null) {
      _statement.bindNull(_argIndex);
    } else {
      _statement.bindString(_argIndex, _tmp);
    }
    _argIndex = 3;
    final String _tmp_1 = __converters.fromLocalDateTime(dataFim);
    if (_tmp_1 == null) {
      _statement.bindNull(_argIndex);
    } else {
      _statement.bindString(_argIndex, _tmp_1);
    }
    final CancellationSignal _cancellationSignal = DBUtil.createCancellationSignal();
    return CoroutinesRoom.execute(__db, false, _cancellationSignal, new Callable<List<Despesa>>() {
      @Override
      @NonNull
      public List<Despesa> call() throws Exception {
        final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
        try {
          final int _cursorIndexOfId = CursorUtil.getColumnIndexOrThrow(_cursor, "id");
          final int _cursorIndexOfRotaId = CursorUtil.getColumnIndexOrThrow(_cursor, "rotaId");
          final int _cursorIndexOfDescricao = CursorUtil.getColumnIndexOrThrow(_cursor, "descricao");
          final int _cursorIndexOfValor = CursorUtil.getColumnIndexOrThrow(_cursor, "valor");
          final int _cursorIndexOfCategoria = CursorUtil.getColumnIndexOrThrow(_cursor, "categoria");
          final int _cursorIndexOfDataHora = CursorUtil.getColumnIndexOrThrow(_cursor, "dataHora");
          final int _cursorIndexOfObservacoes = CursorUtil.getColumnIndexOrThrow(_cursor, "observacoes");
          final int _cursorIndexOfCriadoPor = CursorUtil.getColumnIndexOrThrow(_cursor, "criadoPor");
          final List<Despesa> _result = new ArrayList<Despesa>(_cursor.getCount());
          while (_cursor.moveToNext()) {
            final Despesa _item;
            final long _tmpId;
            _tmpId = _cursor.getLong(_cursorIndexOfId);
            final long _tmpRotaId;
            _tmpRotaId = _cursor.getLong(_cursorIndexOfRotaId);
            final String _tmpDescricao;
            if (_cursor.isNull(_cursorIndexOfDescricao)) {
              _tmpDescricao = null;
            } else {
              _tmpDescricao = _cursor.getString(_cursorIndexOfDescricao);
            }
            final double _tmpValor;
            _tmpValor = _cursor.getDouble(_cursorIndexOfValor);
            final String _tmpCategoria;
            if (_cursor.isNull(_cursorIndexOfCategoria)) {
              _tmpCategoria = null;
            } else {
              _tmpCategoria = _cursor.getString(_cursorIndexOfCategoria);
            }
            final LocalDateTime _tmpDataHora;
            final String _tmp_2;
            if (_cursor.isNull(_cursorIndexOfDataHora)) {
              _tmp_2 = null;
            } else {
              _tmp_2 = _cursor.getString(_cursorIndexOfDataHora);
            }
            _tmpDataHora = __converters.toLocalDateTime(_tmp_2);
            final String _tmpObservacoes;
            if (_cursor.isNull(_cursorIndexOfObservacoes)) {
              _tmpObservacoes = null;
            } else {
              _tmpObservacoes = _cursor.getString(_cursorIndexOfObservacoes);
            }
            final String _tmpCriadoPor;
            if (_cursor.isNull(_cursorIndexOfCriadoPor)) {
              _tmpCriadoPor = null;
            } else {
              _tmpCriadoPor = _cursor.getString(_cursorIndexOfCriadoPor);
            }
            _item = new Despesa(_tmpId,_tmpRotaId,_tmpDescricao,_tmpValor,_tmpCategoria,_tmpDataHora,_tmpObservacoes,_tmpCriadoPor);
            _result.add(_item);
          }
          return _result;
        } finally {
          _cursor.close();
          _statement.release();
        }
      }
    }, arg3);
  }

  @NonNull
  public static List<Class<?>> getRequiredConverters() {
    return Collections.emptyList();
  }
}
