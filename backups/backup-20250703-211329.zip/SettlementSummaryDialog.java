package com.example.gestaobilhares.ui.settlement;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000H\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0006\n\u0000\n\u0002\u0010$\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\u0018\u0000 \u001c2\u00020\u0001:\u0002\u001c\u001dB\u0005\u00a2\u0006\u0002\u0010\u0002J\u0010\u0010\t\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\fH\u0002JJ\u0010\r\u001a\u00020\f2\u0006\u0010\u000e\u001a\u00020\f2\f\u0010\u000f\u001a\b\u0012\u0004\u0012\u00020\u00110\u00102\u0006\u0010\u0012\u001a\u00020\u00132\u0012\u0010\u0014\u001a\u000e\u0012\u0004\u0012\u00020\f\u0012\u0004\u0012\u00020\u00130\u00152\u0006\u0010\u0016\u001a\u00020\f2\u0006\u0010\u0017\u001a\u00020\u0013H\u0002J\u0012\u0010\u0018\u001a\u00020\u00192\b\u0010\u001a\u001a\u0004\u0018\u00010\u001bH\u0016R\u001c\u0010\u0003\u001a\u0004\u0018\u00010\u0004X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u0005\u0010\u0006\"\u0004\b\u0007\u0010\b\u00a8\u0006\u001e"}, d2 = {"Lcom/example/gestaobilhares/ui/settlement/SettlementSummaryDialog;", "Landroidx/fragment/app/DialogFragment;", "()V", "acertoCompartilhadoListener", "Lcom/example/gestaobilhares/ui/settlement/SettlementSummaryDialog$OnAcertoCompartilhadoListener;", "getAcertoCompartilhadoListener", "()Lcom/example/gestaobilhares/ui/settlement/SettlementSummaryDialog$OnAcertoCompartilhadoListener;", "setAcertoCompartilhadoListener", "(Lcom/example/gestaobilhares/ui/settlement/SettlementSummaryDialog$OnAcertoCompartilhadoListener;)V", "enviarViaWhatsApp", "", "texto", "", "gerarTextoResumo", "clienteNome", "mesas", "", "Lcom/example/gestaobilhares/data/entities/Mesa;", "total", "", "metodosPagamento", "", "observacao", "debitoAtual", "onCreateDialog", "Landroid/app/Dialog;", "savedInstanceState", "Landroid/os/Bundle;", "Companion", "OnAcertoCompartilhadoListener", "app_debug"})
public final class SettlementSummaryDialog extends androidx.fragment.app.DialogFragment {
    @org.jetbrains.annotations.Nullable()
    private com.example.gestaobilhares.ui.settlement.SettlementSummaryDialog.OnAcertoCompartilhadoListener acertoCompartilhadoListener;
    @org.jetbrains.annotations.NotNull()
    public static final com.example.gestaobilhares.ui.settlement.SettlementSummaryDialog.Companion Companion = null;
    
    public SettlementSummaryDialog() {
        super();
    }
    
    @org.jetbrains.annotations.Nullable()
    public final com.example.gestaobilhares.ui.settlement.SettlementSummaryDialog.OnAcertoCompartilhadoListener getAcertoCompartilhadoListener() {
        return null;
    }
    
    public final void setAcertoCompartilhadoListener(@org.jetbrains.annotations.Nullable()
    com.example.gestaobilhares.ui.settlement.SettlementSummaryDialog.OnAcertoCompartilhadoListener p0) {
    }
    
    @java.lang.Override()
    @org.jetbrains.annotations.NotNull()
    public android.app.Dialog onCreateDialog(@org.jetbrains.annotations.Nullable()
    android.os.Bundle savedInstanceState) {
        return null;
    }
    
    /**
     * Gera texto formatado do resumo para compartilhamento
     */
    private final java.lang.String gerarTextoResumo(java.lang.String clienteNome, java.util.List<com.example.gestaobilhares.data.entities.Mesa> mesas, double total, java.util.Map<java.lang.String, java.lang.Double> metodosPagamento, java.lang.String observacao, double debitoAtual) {
        return null;
    }
    
    /**
     * ✅ CORRIGIDO: Envia o resumo via WhatsApp nativo
     * Usa a mesma estratégia robusta do ClientDetailFragment
     */
    private final void enviarViaWhatsApp(java.lang.String texto) {
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u00000\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0006\n\u0000\n\u0002\u0010$\n\u0002\b\u0003\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002JL\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u00062\f\u0010\u0007\u001a\b\u0012\u0004\u0012\u00020\t0\b2\u0006\u0010\n\u001a\u00020\u000b2\u0012\u0010\f\u001a\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\u000b0\r2\b\u0010\u000e\u001a\u0004\u0018\u00010\u00062\b\b\u0002\u0010\u000f\u001a\u00020\u000b\u00a8\u0006\u0010"}, d2 = {"Lcom/example/gestaobilhares/ui/settlement/SettlementSummaryDialog$Companion;", "", "()V", "newInstance", "Lcom/example/gestaobilhares/ui/settlement/SettlementSummaryDialog;", "clienteNome", "", "mesas", "", "Lcom/example/gestaobilhares/data/entities/Mesa;", "total", "", "metodosPagamento", "", "observacao", "debitoAtual", "app_debug"})
    public static final class Companion {
        
        private Companion() {
            super();
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.example.gestaobilhares.ui.settlement.SettlementSummaryDialog newInstance(@org.jetbrains.annotations.NotNull()
        java.lang.String clienteNome, @org.jetbrains.annotations.NotNull()
        java.util.List<com.example.gestaobilhares.data.entities.Mesa> mesas, double total, @org.jetbrains.annotations.NotNull()
        java.util.Map<java.lang.String, java.lang.Double> metodosPagamento, @org.jetbrains.annotations.Nullable()
        java.lang.String observacao, double debitoAtual) {
            return null;
        }
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0002\n\u0000\bf\u0018\u00002\u00020\u0001J\b\u0010\u0002\u001a\u00020\u0003H&\u00a8\u0006\u0004"}, d2 = {"Lcom/example/gestaobilhares/ui/settlement/SettlementSummaryDialog$OnAcertoCompartilhadoListener;", "", "onAcertoCompartilhado", "", "app_debug"})
    public static abstract interface OnAcertoCompartilhadoListener {
        
        public abstract void onAcertoCompartilhado();
    }
}