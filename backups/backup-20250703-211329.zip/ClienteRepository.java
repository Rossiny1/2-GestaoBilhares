package com.example.gestaobilhares.data.repositories;

/**
 * Repository para operações relacionadas a clientes
 *
 * Implementa o padrão Repository para abstrair a camada de dados
 * e fornecer uma interface limpa para os ViewModels.
 */
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000B\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\t\n\u0000\n\u0002\u0010\u0006\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\u0010 \n\u0002\b\u0006\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0002\u0010\u0004J\u0016\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\bH\u0086@\u00a2\u0006\u0002\u0010\tJ\u001e\u0010\n\u001a\u00020\u00062\u0006\u0010\u000b\u001a\u00020\f2\u0006\u0010\r\u001a\u00020\u000eH\u0086@\u00a2\u0006\u0002\u0010\u000fJ\u001e\u0010\u0010\u001a\u00020\u00062\u0006\u0010\u000b\u001a\u00020\f2\u0006\u0010\u0011\u001a\u00020\u0012H\u0086@\u00a2\u0006\u0002\u0010\u0013J\u0016\u0010\u0014\u001a\u00020\u000e2\u0006\u0010\u000b\u001a\u00020\fH\u0086@\u00a2\u0006\u0002\u0010\u0015J\u0016\u0010\u0016\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\bH\u0086@\u00a2\u0006\u0002\u0010\tJ\u0016\u0010\u0017\u001a\u00020\f2\u0006\u0010\u0007\u001a\u00020\bH\u0086@\u00a2\u0006\u0002\u0010\tJ\u0018\u0010\u0018\u001a\u0004\u0018\u00010\b2\u0006\u0010\u000b\u001a\u00020\fH\u0086@\u00a2\u0006\u0002\u0010\u0015J\u001a\u0010\u0019\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\b0\u001b0\u001a2\u0006\u0010\u001c\u001a\u00020\fJ\u0016\u0010\u001d\u001a\u00020\u000e2\u0006\u0010\u000b\u001a\u00020\fH\u0086@\u00a2\u0006\u0002\u0010\u0015J\u0018\u0010\u001e\u001a\u0004\u0018\u00010\b2\u0006\u0010\u001f\u001a\u00020\fH\u0086@\u00a2\u0006\u0002\u0010\u0015J\u0012\u0010 \u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\b0\u001b0\u001aR\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006!"}, d2 = {"Lcom/example/gestaobilhares/data/repositories/ClienteRepository;", "", "clienteDao", "Lcom/example/gestaobilhares/data/dao/ClienteDao;", "(Lcom/example/gestaobilhares/data/dao/ClienteDao;)V", "atualizar", "", "cliente", "Lcom/example/gestaobilhares/data/entities/Cliente;", "(Lcom/example/gestaobilhares/data/entities/Cliente;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "atualizarDebitoAtual", "clienteId", "", "novoDebito", "", "(JDLkotlin/coroutines/Continuation;)Ljava/lang/Object;", "atualizarObservacao", "observacao", "", "(JLjava/lang/String;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "calcularDebitoAtualEmTempoReal", "(JLkotlin/coroutines/Continuation;)Ljava/lang/Object;", "deletar", "inserir", "obterClienteComDebitoAtual", "obterClientesPorRota", "Lkotlinx/coroutines/flow/Flow;", "", "rotaId", "obterDebitoAtual", "obterPorId", "id", "obterTodos", "app_debug"})
public final class ClienteRepository {
    @org.jetbrains.annotations.NotNull()
    private final com.example.gestaobilhares.data.dao.ClienteDao clienteDao = null;
    
    public ClienteRepository(@org.jetbrains.annotations.NotNull()
    com.example.gestaobilhares.data.dao.ClienteDao clienteDao) {
        super();
    }
    
    /**
     * Obtém todos os clientes por rota
     */
    @org.jetbrains.annotations.NotNull()
    public final kotlinx.coroutines.flow.Flow<java.util.List<com.example.gestaobilhares.data.entities.Cliente>> obterClientesPorRota(long rotaId) {
        return null;
    }
    
    /**
     * Insere um novo cliente
     */
    @org.jetbrains.annotations.Nullable()
    public final java.lang.Object inserir(@org.jetbrains.annotations.NotNull()
    com.example.gestaobilhares.data.entities.Cliente cliente, @org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super java.lang.Long> $completion) {
        return null;
    }
    
    /**
     * Atualiza um cliente
     */
    @org.jetbrains.annotations.Nullable()
    public final java.lang.Object atualizar(@org.jetbrains.annotations.NotNull()
    com.example.gestaobilhares.data.entities.Cliente cliente, @org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super kotlin.Unit> $completion) {
        return null;
    }
    
    /**
     * Deleta um cliente
     */
    @org.jetbrains.annotations.Nullable()
    public final java.lang.Object deletar(@org.jetbrains.annotations.NotNull()
    com.example.gestaobilhares.data.entities.Cliente cliente, @org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super kotlin.Unit> $completion) {
        return null;
    }
    
    /**
     * Obtém cliente por ID
     */
    @org.jetbrains.annotations.Nullable()
    public final java.lang.Object obterPorId(long id, @org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super com.example.gestaobilhares.data.entities.Cliente> $completion) {
        return null;
    }
    
    /**
     * Obtém todos os clientes
     */
    @org.jetbrains.annotations.NotNull()
    public final kotlinx.coroutines.flow.Flow<java.util.List<com.example.gestaobilhares.data.entities.Cliente>> obterTodos() {
        return null;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.lang.Object atualizarObservacao(long clienteId, @org.jetbrains.annotations.NotNull()
    java.lang.String observacao, @org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super kotlin.Unit> $completion) {
        return null;
    }
    
    /**
     * Obtém o débito atual do cliente
     */
    @org.jetbrains.annotations.Nullable()
    public final java.lang.Object obterDebitoAtual(long clienteId, @org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super java.lang.Double> $completion) {
        return null;
    }
    
    /**
     * Atualiza o débito atual do cliente
     */
    @org.jetbrains.annotations.Nullable()
    public final java.lang.Object atualizarDebitoAtual(long clienteId, double novoDebito, @org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super kotlin.Unit> $completion) {
        return null;
    }
    
    /**
     * ✅ NOVO: Calcula o débito atual em tempo real diretamente do banco
     * Garante consistência total com os dados salvos
     */
    @org.jetbrains.annotations.Nullable()
    public final java.lang.Object calcularDebitoAtualEmTempoReal(long clienteId, @org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super java.lang.Double> $completion) {
        return null;
    }
    
    /**
     * Obtém cliente com débito atual calculado
     */
    @org.jetbrains.annotations.Nullable()
    public final java.lang.Object obterClienteComDebitoAtual(long clienteId, @org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super com.example.gestaobilhares.data.entities.Cliente> $completion) {
        return null;
    }
}