package com.example.gestaobilhares.ui.clients;

/**
 * ViewModel para ClientDetailFragment
 * FASE 4A - Implementação crítica com dados mock
 */
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u0088\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0010\t\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0010\u0006\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u00002\u00020\u0001B%\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\b\u001a\u00020\t\u00a2\u0006\u0002\u0010\nJ\u000e\u0010!\u001a\u00020\"2\u0006\u0010#\u001a\u00020\u0015J\u0016\u0010$\u001a\u00020\"2\u0006\u0010%\u001a\u00020&2\u0006\u0010\'\u001a\u00020&J\"\u0010(\u001a\u00020\"2\u0006\u0010\'\u001a\u00020&2\u0012\u0010)\u001a\u000e\u0012\u0004\u0012\u00020+\u0012\u0004\u0012\u00020\"0*J\u0018\u0010,\u001a\u0004\u0018\u00010-2\u0006\u0010%\u001a\u00020&H\u0086@\u00a2\u0006\u0002\u0010.J\u0010\u0010/\u001a\u00020+2\u0006\u00100\u001a\u000201H\u0002J\u0006\u00102\u001a\u00020\u000fJ\u000e\u00103\u001a\u00020\"2\u0006\u0010\'\u001a\u00020&J\u0006\u00104\u001a\u00020\"J\u000e\u00105\u001a\u00020\"2\u0006\u0010\'\u001a\u00020&J&\u00106\u001a\u00020\"2\u0006\u0010%\u001a\u00020&2\u0006\u0010\'\u001a\u00020&2\u0006\u00107\u001a\u00020-2\u0006\u00108\u001a\u000209J\u0016\u0010:\u001a\u00020\"2\u0006\u0010\'\u001a\u00020&2\u0006\u0010;\u001a\u00020+J\u001e\u0010<\u001a\u00020=2\u0006\u0010%\u001a\u00020&2\u0006\u0010\'\u001a\u00020&H\u0086@\u00a2\u0006\u0002\u0010>R\u0016\u0010\u000b\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\r0\fX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u0010\u000e\u001a\b\u0012\u0004\u0012\u00020\u000f0\fX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u001a\u0010\u0010\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00120\u00110\fX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u001a\u0010\u0013\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00120\u00110\fX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u001a\u0010\u0014\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00150\u00110\fX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\tX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0019\u0010\u0016\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\r0\u0017\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0018\u0010\u0019R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0017\u0010\u001a\u001a\b\u0012\u0004\u0012\u00020\u000f0\u0017\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001a\u0010\u0019R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u001d\u0010\u001b\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00120\u00110\u0017\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001c\u0010\u0019R\u001d\u0010\u001d\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00120\u00110\u0017\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001e\u0010\u0019R\u001d\u0010\u001f\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00150\u00110\u0017\u00a2\u0006\b\n\u0000\u001a\u0004\b \u0010\u0019\u00a8\u0006?"}, d2 = {"Lcom/example/gestaobilhares/ui/clients/ClientDetailViewModel;", "Landroidx/lifecycle/ViewModel;", "clienteRepository", "Lcom/example/gestaobilhares/data/repositories/ClienteRepository;", "mesaRepository", "Lcom/example/gestaobilhares/data/repository/MesaRepository;", "acertoRepository", "Lcom/example/gestaobilhares/data/repository/AcertoRepository;", "acertoMesaRepository", "Lcom/example/gestaobilhares/data/repository/AcertoMesaRepository;", "(Lcom/example/gestaobilhares/data/repositories/ClienteRepository;Lcom/example/gestaobilhares/data/repository/MesaRepository;Lcom/example/gestaobilhares/data/repository/AcertoRepository;Lcom/example/gestaobilhares/data/repository/AcertoMesaRepository;)V", "_clientDetails", "Lkotlinx/coroutines/flow/MutableStateFlow;", "Lcom/example/gestaobilhares/ui/clients/ClienteResumo;", "_isLoading", "", "_mesasCliente", "", "Lcom/example/gestaobilhares/data/entities/Mesa;", "_mesasDisponiveis", "_settlementHistory", "Lcom/example/gestaobilhares/ui/clients/AcertoResumo;", "clientDetails", "Lkotlinx/coroutines/flow/StateFlow;", "getClientDetails", "()Lkotlinx/coroutines/flow/StateFlow;", "isLoading", "mesasCliente", "getMesasCliente", "mesasDisponiveis", "getMesasDisponiveis", "settlementHistory", "getSettlementHistory", "adicionarAcertoNoHistorico", "", "novoAcerto", "adicionarMesaAoCliente", "mesaId", "", "clienteId", "buscarDataUltimoAcerto", "callback", "Lkotlin/Function1;", "", "buscarRelogioFinalUltimoAcerto", "", "(JLkotlin/coroutines/Continuation;)Ljava/lang/Object;", "calcularTempoRelativoReal", "data", "Ljava/util/Date;", "isAdminUser", "loadClientDetails", "loadMesasDisponiveis", "loadSettlementHistory", "retirarMesaDoCliente", "relogioFinal", "valorRecebido", "", "salvarObservacaoCliente", "observacao", "verificarSeRetiradaEPermitida", "Lcom/example/gestaobilhares/ui/clients/RetiradaStatus;", "(JJLkotlin/coroutines/Continuation;)Ljava/lang/Object;", "app_debug"})
public final class ClientDetailViewModel extends androidx.lifecycle.ViewModel {
    @org.jetbrains.annotations.NotNull()
    private final com.example.gestaobilhares.data.repositories.ClienteRepository clienteRepository = null;
    @org.jetbrains.annotations.NotNull()
    private final com.example.gestaobilhares.data.repository.MesaRepository mesaRepository = null;
    @org.jetbrains.annotations.NotNull()
    private final com.example.gestaobilhares.data.repository.AcertoRepository acertoRepository = null;
    @org.jetbrains.annotations.NotNull()
    private final com.example.gestaobilhares.data.repository.AcertoMesaRepository acertoMesaRepository = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlinx.coroutines.flow.MutableStateFlow<com.example.gestaobilhares.ui.clients.ClienteResumo> _clientDetails = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlinx.coroutines.flow.StateFlow<com.example.gestaobilhares.ui.clients.ClienteResumo> clientDetails = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlinx.coroutines.flow.MutableStateFlow<java.util.List<com.example.gestaobilhares.ui.clients.AcertoResumo>> _settlementHistory = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlinx.coroutines.flow.StateFlow<java.util.List<com.example.gestaobilhares.ui.clients.AcertoResumo>> settlementHistory = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlinx.coroutines.flow.MutableStateFlow<java.lang.Boolean> _isLoading = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlinx.coroutines.flow.StateFlow<java.lang.Boolean> isLoading = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlinx.coroutines.flow.MutableStateFlow<java.util.List<com.example.gestaobilhares.data.entities.Mesa>> _mesasCliente = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlinx.coroutines.flow.StateFlow<java.util.List<com.example.gestaobilhares.data.entities.Mesa>> mesasCliente = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlinx.coroutines.flow.MutableStateFlow<java.util.List<com.example.gestaobilhares.data.entities.Mesa>> _mesasDisponiveis = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlinx.coroutines.flow.StateFlow<java.util.List<com.example.gestaobilhares.data.entities.Mesa>> mesasDisponiveis = null;
    
    public ClientDetailViewModel(@org.jetbrains.annotations.NotNull()
    com.example.gestaobilhares.data.repositories.ClienteRepository clienteRepository, @org.jetbrains.annotations.NotNull()
    com.example.gestaobilhares.data.repository.MesaRepository mesaRepository, @org.jetbrains.annotations.NotNull()
    com.example.gestaobilhares.data.repository.AcertoRepository acertoRepository, @org.jetbrains.annotations.NotNull()
    com.example.gestaobilhares.data.repository.AcertoMesaRepository acertoMesaRepository) {
        super();
    }
    
    @org.jetbrains.annotations.NotNull()
    public final kotlinx.coroutines.flow.StateFlow<com.example.gestaobilhares.ui.clients.ClienteResumo> getClientDetails() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final kotlinx.coroutines.flow.StateFlow<java.util.List<com.example.gestaobilhares.ui.clients.AcertoResumo>> getSettlementHistory() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final kotlinx.coroutines.flow.StateFlow<java.lang.Boolean> isLoading() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final kotlinx.coroutines.flow.StateFlow<java.util.List<com.example.gestaobilhares.data.entities.Mesa>> getMesasCliente() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final kotlinx.coroutines.flow.StateFlow<java.util.List<com.example.gestaobilhares.data.entities.Mesa>> getMesasDisponiveis() {
        return null;
    }
    
    public final void loadClientDetails(long clienteId) {
    }
    
    public final void adicionarMesaAoCliente(long mesaId, long clienteId) {
    }
    
    /**
     * ✅ NOVO FLUXO: Verifica se mesa pode ser retirada ou precisa de acerto
     */
    @org.jetbrains.annotations.Nullable()
    public final java.lang.Object verificarSeRetiradaEPermitida(long mesaId, long clienteId, @org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super com.example.gestaobilhares.ui.clients.RetiradaStatus> $completion) {
        return null;
    }
    
    public final void retirarMesaDoCliente(long mesaId, long clienteId, int relogioFinal, double valorRecebido) {
    }
    
    public final void loadMesasDisponiveis() {
    }
    
    public final boolean isAdminUser() {
        return false;
    }
    
    public final void salvarObservacaoCliente(long clienteId, @org.jetbrains.annotations.NotNull()
    java.lang.String observacao) {
    }
    
    /**
     * Adiciona um novo acerto ao histórico do cliente e recarrega do banco de dados.
     */
    public final void adicionarAcertoNoHistorico(@org.jetbrains.annotations.NotNull()
    com.example.gestaobilhares.ui.clients.AcertoResumo novoAcerto) {
    }
    
    public final void loadSettlementHistory(long clienteId) {
    }
    
    /**
     * Busca a data do último acerto do cliente para exibir como "última visita"
     */
    public final void buscarDataUltimoAcerto(long clienteId, @org.jetbrains.annotations.NotNull()
    kotlin.jvm.functions.Function1<? super java.lang.String, kotlin.Unit> callback) {
    }
    
    /**
     * Calcula a diferença de tempo entre a data passada e hoje, retornando string amigável
     */
    private final java.lang.String calcularTempoRelativoReal(java.util.Date data) {
        return null;
    }
    
    /**
     * ✅ NOVO: Busca o relógio final do último acerto de uma mesa
     */
    @org.jetbrains.annotations.Nullable()
    public final java.lang.Object buscarRelogioFinalUltimoAcerto(long mesaId, @org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super java.lang.Integer> $completion) {
        return null;
    }
}