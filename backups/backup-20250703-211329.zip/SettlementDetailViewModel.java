package com.example.gestaobilhares.ui.settlement;

/**
 * ViewModel para SettlementDetailFragment
 * Busca dados reais do acerto no banco de dados
 */
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000>\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\t\n\u0002\b\u0002\u0018\u00002\u00020\u0001:\u0001\u0015B\u0015\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\u0002\u0010\u0006J\u000e\u0010\u0011\u001a\u00020\u00122\u0006\u0010\u0013\u001a\u00020\u0014R\u0014\u0010\u0007\u001a\b\u0012\u0004\u0012\u00020\t0\bX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0016\u0010\n\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u000b0\bX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0017\u0010\f\u001a\b\u0012\u0004\u0012\u00020\t0\r\u00a2\u0006\b\n\u0000\u001a\u0004\b\f\u0010\u000eR\u0019\u0010\u000f\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u000b0\r\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u000e\u00a8\u0006\u0016"}, d2 = {"Lcom/example/gestaobilhares/ui/settlement/SettlementDetailViewModel;", "Landroidx/lifecycle/ViewModel;", "acertoRepository", "Lcom/example/gestaobilhares/data/repository/AcertoRepository;", "acertoMesaRepository", "Lcom/example/gestaobilhares/data/repository/AcertoMesaRepository;", "(Lcom/example/gestaobilhares/data/repository/AcertoRepository;Lcom/example/gestaobilhares/data/repository/AcertoMesaRepository;)V", "_isLoading", "Lkotlinx/coroutines/flow/MutableStateFlow;", "", "_settlementDetails", "Lcom/example/gestaobilhares/ui/settlement/SettlementDetailViewModel$SettlementDetail;", "isLoading", "Lkotlinx/coroutines/flow/StateFlow;", "()Lkotlinx/coroutines/flow/StateFlow;", "settlementDetails", "getSettlementDetails", "loadSettlementDetails", "", "acertoId", "", "SettlementDetail", "app_debug"})
public final class SettlementDetailViewModel extends androidx.lifecycle.ViewModel {
    @org.jetbrains.annotations.NotNull()
    private final com.example.gestaobilhares.data.repository.AcertoRepository acertoRepository = null;
    @org.jetbrains.annotations.NotNull()
    private final com.example.gestaobilhares.data.repository.AcertoMesaRepository acertoMesaRepository = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlinx.coroutines.flow.MutableStateFlow<com.example.gestaobilhares.ui.settlement.SettlementDetailViewModel.SettlementDetail> _settlementDetails = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlinx.coroutines.flow.StateFlow<com.example.gestaobilhares.ui.settlement.SettlementDetailViewModel.SettlementDetail> settlementDetails = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlinx.coroutines.flow.MutableStateFlow<java.lang.Boolean> _isLoading = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlinx.coroutines.flow.StateFlow<java.lang.Boolean> isLoading = null;
    
    public SettlementDetailViewModel(@org.jetbrains.annotations.NotNull()
    com.example.gestaobilhares.data.repository.AcertoRepository acertoRepository, @org.jetbrains.annotations.NotNull()
    com.example.gestaobilhares.data.repository.AcertoMesaRepository acertoMesaRepository) {
        super();
    }
    
    @org.jetbrains.annotations.NotNull()
    public final kotlinx.coroutines.flow.StateFlow<com.example.gestaobilhares.ui.settlement.SettlementDetailViewModel.SettlementDetail> getSettlementDetails() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final kotlinx.coroutines.flow.StateFlow<java.lang.Boolean> isLoading() {
        return null;
    }
    
    public final void loadSettlementDetails(long acertoId) {
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000J\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\u0006\n\u0002\b\u0005\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010$\n\u0000\n\u0002\u0018\u0002\n\u0002\b1\b\u0086\b\u0018\u00002\u00020\u0001B\u00a3\u0001\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0005\u0012\u0006\u0010\u0007\u001a\u00020\b\u0012\u0006\u0010\t\u001a\u00020\b\u0012\u0006\u0010\n\u001a\u00020\b\u0012\u0006\u0010\u000b\u001a\u00020\b\u0012\u0006\u0010\f\u001a\u00020\b\u0012\u0006\u0010\r\u001a\u00020\u000e\u0012\u0006\u0010\u000f\u001a\u00020\u0005\u0012\f\u0010\u0010\u001a\b\u0012\u0004\u0012\u00020\u00120\u0011\u0012\u0006\u0010\u0013\u001a\u00020\u0005\u0012\u0006\u0010\u0014\u001a\u00020\u0005\u0012\u0006\u0010\u0015\u001a\u00020\u0016\u0012\b\u0010\u0017\u001a\u0004\u0018\u00010\u0005\u0012\u0012\u0010\u0018\u001a\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\b0\u0019\u0012\b\u0010\u001a\u001a\u0004\u0018\u00010\u001b\u00a2\u0006\u0002\u0010\u001cJ\t\u00106\u001a\u00020\u0003H\u00c6\u0003J\t\u00107\u001a\u00020\u0005H\u00c6\u0003J\u000f\u00108\u001a\b\u0012\u0004\u0012\u00020\u00120\u0011H\u00c6\u0003J\t\u00109\u001a\u00020\u0005H\u00c6\u0003J\t\u0010:\u001a\u00020\u0005H\u00c6\u0003J\t\u0010;\u001a\u00020\u0016H\u00c6\u0003J\u000b\u0010<\u001a\u0004\u0018\u00010\u0005H\u00c6\u0003J\u0015\u0010=\u001a\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\b0\u0019H\u00c6\u0003J\u000b\u0010>\u001a\u0004\u0018\u00010\u001bH\u00c6\u0003J\t\u0010?\u001a\u00020\u0005H\u00c6\u0003J\t\u0010@\u001a\u00020\u0005H\u00c6\u0003J\t\u0010A\u001a\u00020\bH\u00c6\u0003J\t\u0010B\u001a\u00020\bH\u00c6\u0003J\t\u0010C\u001a\u00020\bH\u00c6\u0003J\t\u0010D\u001a\u00020\bH\u00c6\u0003J\t\u0010E\u001a\u00020\bH\u00c6\u0003J\t\u0010F\u001a\u00020\u000eH\u00c6\u0003J\u00c9\u0001\u0010G\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u00052\b\b\u0002\u0010\u0007\u001a\u00020\b2\b\b\u0002\u0010\t\u001a\u00020\b2\b\b\u0002\u0010\n\u001a\u00020\b2\b\b\u0002\u0010\u000b\u001a\u00020\b2\b\b\u0002\u0010\f\u001a\u00020\b2\b\b\u0002\u0010\r\u001a\u00020\u000e2\b\b\u0002\u0010\u000f\u001a\u00020\u00052\u000e\b\u0002\u0010\u0010\u001a\b\u0012\u0004\u0012\u00020\u00120\u00112\b\b\u0002\u0010\u0013\u001a\u00020\u00052\b\b\u0002\u0010\u0014\u001a\u00020\u00052\b\b\u0002\u0010\u0015\u001a\u00020\u00162\n\b\u0002\u0010\u0017\u001a\u0004\u0018\u00010\u00052\u0014\b\u0002\u0010\u0018\u001a\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\b0\u00192\n\b\u0002\u0010\u001a\u001a\u0004\u0018\u00010\u001bH\u00c6\u0001J\u0013\u0010H\u001a\u00020\u00162\b\u0010I\u001a\u0004\u0018\u00010\u0001H\u00d6\u0003J\t\u0010J\u001a\u00020\u000eH\u00d6\u0001J\t\u0010K\u001a\u00020\u0005H\u00d6\u0001R\u0017\u0010\u0010\u001a\b\u0012\u0004\u0012\u00020\u00120\u0011\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001d\u0010\u001eR\u0013\u0010\u001a\u001a\u0004\u0018\u00010\u001b\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001f\u0010 R\u0011\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\b\n\u0000\u001a\u0004\b!\u0010\"R\u0011\u0010\u000b\u001a\u00020\b\u00a2\u0006\b\n\u0000\u001a\u0004\b#\u0010$R\u0011\u0010\f\u001a\u00020\b\u00a2\u0006\b\n\u0000\u001a\u0004\b%\u0010$R\u0011\u0010\n\u001a\u00020\b\u00a2\u0006\b\n\u0000\u001a\u0004\b&\u0010$R\u0011\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\b\n\u0000\u001a\u0004\b\'\u0010(R\u001d\u0010\u0018\u001a\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\b0\u0019\u00a2\u0006\b\n\u0000\u001a\u0004\b)\u0010*R\u0013\u0010\u0017\u001a\u0004\u0018\u00010\u0005\u00a2\u0006\b\n\u0000\u001a\u0004\b+\u0010\"R\u0011\u0010\u000f\u001a\u00020\u0005\u00a2\u0006\b\n\u0000\u001a\u0004\b,\u0010\"R\u0011\u0010\u0015\u001a\u00020\u0016\u00a2\u0006\b\n\u0000\u001a\u0004\b-\u0010.R\u0011\u0010\u0013\u001a\u00020\u0005\u00a2\u0006\b\n\u0000\u001a\u0004\b/\u0010\"R\u0011\u0010\u0006\u001a\u00020\u0005\u00a2\u0006\b\n\u0000\u001a\u0004\b0\u0010\"R\u0011\u0010\u0014\u001a\u00020\u0005\u00a2\u0006\b\n\u0000\u001a\u0004\b1\u0010\"R\u0011\u0010\r\u001a\u00020\u000e\u00a2\u0006\b\n\u0000\u001a\u0004\b2\u00103R\u0011\u0010\t\u001a\u00020\b\u00a2\u0006\b\n\u0000\u001a\u0004\b4\u0010$R\u0011\u0010\u0007\u001a\u00020\b\u00a2\u0006\b\n\u0000\u001a\u0004\b5\u0010$\u00a8\u0006L"}, d2 = {"Lcom/example/gestaobilhares/ui/settlement/SettlementDetailViewModel$SettlementDetail;", "", "id", "", "date", "", "status", "valorTotal", "", "valorRecebido", "desconto", "debitoAnterior", "debitoAtual", "totalMesas", "", "observacoes", "acertoMesas", "", "Lcom/example/gestaobilhares/data/entities/AcertoMesa;", "representante", "tipoAcerto", "panoTrocado", "", "numeroPano", "metodosPagamento", "", "dataFinalizacao", "Ljava/util/Date;", "(JLjava/lang/String;Ljava/lang/String;DDDDDILjava/lang/String;Ljava/util/List;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;Ljava/util/Map;Ljava/util/Date;)V", "getAcertoMesas", "()Ljava/util/List;", "getDataFinalizacao", "()Ljava/util/Date;", "getDate", "()Ljava/lang/String;", "getDebitoAnterior", "()D", "getDebitoAtual", "getDesconto", "getId", "()J", "getMetodosPagamento", "()Ljava/util/Map;", "getNumeroPano", "getObservacoes", "getPanoTrocado", "()Z", "getRepresentante", "getStatus", "getTipoAcerto", "getTotalMesas", "()I", "getValorRecebido", "getValorTotal", "component1", "component10", "component11", "component12", "component13", "component14", "component15", "component16", "component17", "component2", "component3", "component4", "component5", "component6", "component7", "component8", "component9", "copy", "equals", "other", "hashCode", "toString", "app_debug"})
    public static final class SettlementDetail {
        private final long id = 0L;
        @org.jetbrains.annotations.NotNull()
        private final java.lang.String date = null;
        @org.jetbrains.annotations.NotNull()
        private final java.lang.String status = null;
        private final double valorTotal = 0.0;
        private final double valorRecebido = 0.0;
        private final double desconto = 0.0;
        private final double debitoAnterior = 0.0;
        private final double debitoAtual = 0.0;
        private final int totalMesas = 0;
        @org.jetbrains.annotations.NotNull()
        private final java.lang.String observacoes = null;
        @org.jetbrains.annotations.NotNull()
        private final java.util.List<com.example.gestaobilhares.data.entities.AcertoMesa> acertoMesas = null;
        @org.jetbrains.annotations.NotNull()
        private final java.lang.String representante = null;
        @org.jetbrains.annotations.NotNull()
        private final java.lang.String tipoAcerto = null;
        private final boolean panoTrocado = false;
        @org.jetbrains.annotations.Nullable()
        private final java.lang.String numeroPano = null;
        @org.jetbrains.annotations.NotNull()
        private final java.util.Map<java.lang.String, java.lang.Double> metodosPagamento = null;
        @org.jetbrains.annotations.Nullable()
        private final java.util.Date dataFinalizacao = null;
        
        public SettlementDetail(long id, @org.jetbrains.annotations.NotNull()
        java.lang.String date, @org.jetbrains.annotations.NotNull()
        java.lang.String status, double valorTotal, double valorRecebido, double desconto, double debitoAnterior, double debitoAtual, int totalMesas, @org.jetbrains.annotations.NotNull()
        java.lang.String observacoes, @org.jetbrains.annotations.NotNull()
        java.util.List<com.example.gestaobilhares.data.entities.AcertoMesa> acertoMesas, @org.jetbrains.annotations.NotNull()
        java.lang.String representante, @org.jetbrains.annotations.NotNull()
        java.lang.String tipoAcerto, boolean panoTrocado, @org.jetbrains.annotations.Nullable()
        java.lang.String numeroPano, @org.jetbrains.annotations.NotNull()
        java.util.Map<java.lang.String, java.lang.Double> metodosPagamento, @org.jetbrains.annotations.Nullable()
        java.util.Date dataFinalizacao) {
            super();
        }
        
        public final long getId() {
            return 0L;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final java.lang.String getDate() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final java.lang.String getStatus() {
            return null;
        }
        
        public final double getValorTotal() {
            return 0.0;
        }
        
        public final double getValorRecebido() {
            return 0.0;
        }
        
        public final double getDesconto() {
            return 0.0;
        }
        
        public final double getDebitoAnterior() {
            return 0.0;
        }
        
        public final double getDebitoAtual() {
            return 0.0;
        }
        
        public final int getTotalMesas() {
            return 0;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final java.lang.String getObservacoes() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final java.util.List<com.example.gestaobilhares.data.entities.AcertoMesa> getAcertoMesas() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final java.lang.String getRepresentante() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final java.lang.String getTipoAcerto() {
            return null;
        }
        
        public final boolean getPanoTrocado() {
            return false;
        }
        
        @org.jetbrains.annotations.Nullable()
        public final java.lang.String getNumeroPano() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final java.util.Map<java.lang.String, java.lang.Double> getMetodosPagamento() {
            return null;
        }
        
        @org.jetbrains.annotations.Nullable()
        public final java.util.Date getDataFinalizacao() {
            return null;
        }
        
        public final long component1() {
            return 0L;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final java.lang.String component10() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final java.util.List<com.example.gestaobilhares.data.entities.AcertoMesa> component11() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final java.lang.String component12() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final java.lang.String component13() {
            return null;
        }
        
        public final boolean component14() {
            return false;
        }
        
        @org.jetbrains.annotations.Nullable()
        public final java.lang.String component15() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final java.util.Map<java.lang.String, java.lang.Double> component16() {
            return null;
        }
        
        @org.jetbrains.annotations.Nullable()
        public final java.util.Date component17() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final java.lang.String component2() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final java.lang.String component3() {
            return null;
        }
        
        public final double component4() {
            return 0.0;
        }
        
        public final double component5() {
            return 0.0;
        }
        
        public final double component6() {
            return 0.0;
        }
        
        public final double component7() {
            return 0.0;
        }
        
        public final double component8() {
            return 0.0;
        }
        
        public final int component9() {
            return 0;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.example.gestaobilhares.ui.settlement.SettlementDetailViewModel.SettlementDetail copy(long id, @org.jetbrains.annotations.NotNull()
        java.lang.String date, @org.jetbrains.annotations.NotNull()
        java.lang.String status, double valorTotal, double valorRecebido, double desconto, double debitoAnterior, double debitoAtual, int totalMesas, @org.jetbrains.annotations.NotNull()
        java.lang.String observacoes, @org.jetbrains.annotations.NotNull()
        java.util.List<com.example.gestaobilhares.data.entities.AcertoMesa> acertoMesas, @org.jetbrains.annotations.NotNull()
        java.lang.String representante, @org.jetbrains.annotations.NotNull()
        java.lang.String tipoAcerto, boolean panoTrocado, @org.jetbrains.annotations.Nullable()
        java.lang.String numeroPano, @org.jetbrains.annotations.NotNull()
        java.util.Map<java.lang.String, java.lang.Double> metodosPagamento, @org.jetbrains.annotations.Nullable()
        java.util.Date dataFinalizacao) {
            return null;
        }
        
        @java.lang.Override()
        public boolean equals(@org.jetbrains.annotations.Nullable()
        java.lang.Object other) {
            return false;
        }
        
        @java.lang.Override()
        public int hashCode() {
            return 0;
        }
        
        @java.lang.Override()
        @org.jetbrains.annotations.NotNull()
        public java.lang.String toString() {
            return null;
        }
    }
}