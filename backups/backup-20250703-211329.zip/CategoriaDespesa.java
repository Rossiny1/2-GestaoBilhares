package com.example.gestaobilhares.data.entities;

/**
 * Enum para categorias de despesas
 */
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0000\n\u0002\u0010\u000e\n\u0002\b\n\b\u0086\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\u000f\b\u0002\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0002\u0010\u0004R\u0011\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0006j\u0002\b\u0007j\u0002\b\bj\u0002\b\tj\u0002\b\nj\u0002\b\u000bj\u0002\b\f\u00a8\u0006\r"}, d2 = {"Lcom/example/gestaobilhares/data/entities/CategoriaDespesa;", "", "displayName", "", "(Ljava/lang/String;ILjava/lang/String;)V", "getDisplayName", "()Ljava/lang/String;", "COMBUSTIVEL", "ALIMENTACAO", "TRANSPORTE", "MANUTENCAO", "MATERIAIS", "OUTROS", "app_debug"})
public enum CategoriaDespesa {
    /*public static final*/ COMBUSTIVEL /* = new COMBUSTIVEL(null) */,
    /*public static final*/ ALIMENTACAO /* = new ALIMENTACAO(null) */,
    /*public static final*/ TRANSPORTE /* = new TRANSPORTE(null) */,
    /*public static final*/ MANUTENCAO /* = new MANUTENCAO(null) */,
    /*public static final*/ MATERIAIS /* = new MATERIAIS(null) */,
    /*public static final*/ OUTROS /* = new OUTROS(null) */;
    @org.jetbrains.annotations.NotNull()
    private final java.lang.String displayName = null;
    
    CategoriaDespesa(java.lang.String displayName) {
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.lang.String getDisplayName() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public static kotlin.enums.EnumEntries<com.example.gestaobilhares.data.entities.CategoriaDespesa> getEntries() {
        return null;
    }
}