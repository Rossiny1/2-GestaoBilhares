package com.example.gestaobilhares.data.entities;

/**
 * Entidade que representa um Acerto no banco de dados.
 * Acertos são registros financeiros periódicos por cliente.
 */
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000@\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\t\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0006\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0006\n\u0002\u0010\u000b\n\u0002\b>\n\u0002\u0010\b\n\u0002\b\u0002\b\u0087\b\u0018\u00002\u00020\u0001B\u00f5\u0001\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\n\b\u0002\u0010\u0005\u001a\u0004\u0018\u00010\u0003\u0012\b\b\u0002\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\b\u001a\u00020\u0007\u0012\u0006\u0010\t\u001a\u00020\u0007\u0012\b\b\u0002\u0010\n\u001a\u00020\u000b\u0012\b\b\u0002\u0010\f\u001a\u00020\u000b\u0012\b\b\u0002\u0010\r\u001a\u00020\u000b\u0012\b\b\u0002\u0010\u000e\u001a\u00020\u000b\u0012\b\b\u0002\u0010\u000f\u001a\u00020\u000b\u0012\b\b\u0002\u0010\u0010\u001a\u00020\u000b\u0012\b\b\u0002\u0010\u0011\u001a\u00020\u000b\u0012\b\b\u0002\u0010\u0012\u001a\u00020\u0013\u0012\n\b\u0002\u0010\u0014\u001a\u0004\u0018\u00010\u0015\u0012\b\b\u0002\u0010\u0016\u001a\u00020\u0007\u0012\n\b\u0002\u0010\u0017\u001a\u0004\u0018\u00010\u0007\u0012\n\b\u0002\u0010\u0018\u001a\u0004\u0018\u00010\u0015\u0012\n\b\u0002\u0010\u0019\u001a\u0004\u0018\u00010\u0015\u0012\n\b\u0002\u0010\u001a\u001a\u0004\u0018\u00010\u0015\u0012\b\b\u0002\u0010\u001b\u001a\u00020\u001c\u0012\n\b\u0002\u0010\u001d\u001a\u0004\u0018\u00010\u0015\u0012\n\b\u0002\u0010\u001e\u001a\u0004\u0018\u00010\u0015\u00a2\u0006\u0002\u0010\u001fJ\t\u0010?\u001a\u00020\u0003H\u00c6\u0003J\t\u0010@\u001a\u00020\u000bH\u00c6\u0003J\t\u0010A\u001a\u00020\u000bH\u00c6\u0003J\t\u0010B\u001a\u00020\u000bH\u00c6\u0003J\t\u0010C\u001a\u00020\u000bH\u00c6\u0003J\t\u0010D\u001a\u00020\u0013H\u00c6\u0003J\u000b\u0010E\u001a\u0004\u0018\u00010\u0015H\u00c6\u0003J\t\u0010F\u001a\u00020\u0007H\u00c6\u0003J\u000b\u0010G\u001a\u0004\u0018\u00010\u0007H\u00c6\u0003J\u000b\u0010H\u001a\u0004\u0018\u00010\u0015H\u00c6\u0003J\u000b\u0010I\u001a\u0004\u0018\u00010\u0015H\u00c6\u0003J\t\u0010J\u001a\u00020\u0003H\u00c6\u0003J\u000b\u0010K\u001a\u0004\u0018\u00010\u0015H\u00c6\u0003J\t\u0010L\u001a\u00020\u001cH\u00c6\u0003J\u000b\u0010M\u001a\u0004\u0018\u00010\u0015H\u00c6\u0003J\u000b\u0010N\u001a\u0004\u0018\u00010\u0015H\u00c6\u0003J\u0010\u0010O\u001a\u0004\u0018\u00010\u0003H\u00c6\u0003\u00a2\u0006\u0002\u0010#J\t\u0010P\u001a\u00020\u0007H\u00c6\u0003J\t\u0010Q\u001a\u00020\u0007H\u00c6\u0003J\t\u0010R\u001a\u00020\u0007H\u00c6\u0003J\t\u0010S\u001a\u00020\u000bH\u00c6\u0003J\t\u0010T\u001a\u00020\u000bH\u00c6\u0003J\t\u0010U\u001a\u00020\u000bH\u00c6\u0003J\u0084\u0002\u0010V\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00032\n\b\u0002\u0010\u0005\u001a\u0004\u0018\u00010\u00032\b\b\u0002\u0010\u0006\u001a\u00020\u00072\b\b\u0002\u0010\b\u001a\u00020\u00072\b\b\u0002\u0010\t\u001a\u00020\u00072\b\b\u0002\u0010\n\u001a\u00020\u000b2\b\b\u0002\u0010\f\u001a\u00020\u000b2\b\b\u0002\u0010\r\u001a\u00020\u000b2\b\b\u0002\u0010\u000e\u001a\u00020\u000b2\b\b\u0002\u0010\u000f\u001a\u00020\u000b2\b\b\u0002\u0010\u0010\u001a\u00020\u000b2\b\b\u0002\u0010\u0011\u001a\u00020\u000b2\b\b\u0002\u0010\u0012\u001a\u00020\u00132\n\b\u0002\u0010\u0014\u001a\u0004\u0018\u00010\u00152\b\b\u0002\u0010\u0016\u001a\u00020\u00072\n\b\u0002\u0010\u0017\u001a\u0004\u0018\u00010\u00072\n\b\u0002\u0010\u0018\u001a\u0004\u0018\u00010\u00152\n\b\u0002\u0010\u0019\u001a\u0004\u0018\u00010\u00152\n\b\u0002\u0010\u001a\u001a\u0004\u0018\u00010\u00152\b\b\u0002\u0010\u001b\u001a\u00020\u001c2\n\b\u0002\u0010\u001d\u001a\u0004\u0018\u00010\u00152\n\b\u0002\u0010\u001e\u001a\u0004\u0018\u00010\u0015H\u00c6\u0001\u00a2\u0006\u0002\u0010WJ\u0013\u0010X\u001a\u00020\u001c2\b\u0010Y\u001a\u0004\u0018\u00010\u0001H\u00d6\u0003J\t\u0010Z\u001a\u00020[H\u00d6\u0001J\t\u0010\\\u001a\u00020\u0015H\u00d6\u0001R\u0016\u0010\u0004\u001a\u00020\u00038\u0006X\u0087\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b \u0010!R\u001a\u0010\u0005\u001a\u0004\u0018\u00010\u00038\u0006X\u0087\u0004\u00a2\u0006\n\n\u0002\u0010$\u001a\u0004\b\"\u0010#R\u0018\u0010\u001e\u001a\u0004\u0018\u00010\u00158\u0006X\u0087\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b%\u0010&R\u0016\u0010\u0006\u001a\u00020\u00078\u0006X\u0087\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\'\u0010(R\u0016\u0010\u0016\u001a\u00020\u00078\u0006X\u0087\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b)\u0010(R\u0018\u0010\u0017\u001a\u0004\u0018\u00010\u00078\u0006X\u0087\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b*\u0010(R\u0016\u0010\f\u001a\u00020\u000b8\u0006X\u0087\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b+\u0010,R\u0016\u0010\u0011\u001a\u00020\u000b8\u0006X\u0087\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b-\u0010,R\u0016\u0010\u000e\u001a\u00020\u000b8\u0006X\u0087\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b.\u0010,R\u0016\u0010\u0002\u001a\u00020\u00038\u0006X\u0087\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b/\u0010!R\u0018\u0010\u0018\u001a\u0004\u0018\u00010\u00158\u0006X\u0087\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b0\u0010&R\u0018\u0010\u001d\u001a\u0004\u0018\u00010\u00158\u0006X\u0087\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b1\u0010&R\u0018\u0010\u0014\u001a\u0004\u0018\u00010\u00158\u0006X\u0087\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b2\u0010&R\u0016\u0010\u001b\u001a\u00020\u001c8\u0006X\u0087\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b3\u00104R\u0016\u0010\t\u001a\u00020\u00078\u0006X\u0087\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b5\u0010(R\u0016\u0010\b\u001a\u00020\u00078\u0006X\u0087\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b6\u0010(R\u0018\u0010\u0019\u001a\u0004\u0018\u00010\u00158\u0006X\u0087\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b7\u0010&R\u0016\u0010\u0012\u001a\u00020\u00138\u0006X\u0087\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b8\u00109R\u0018\u0010\u001a\u001a\u0004\u0018\u00010\u00158\u0006X\u0087\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b:\u0010&R\u0016\u0010\n\u001a\u00020\u000b8\u0006X\u0087\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b;\u0010,R\u0016\u0010\u000f\u001a\u00020\u000b8\u0006X\u0087\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b<\u0010,R\u0016\u0010\u0010\u001a\u00020\u000b8\u0006X\u0087\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b=\u0010,R\u0016\u0010\r\u001a\u00020\u000b8\u0006X\u0087\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b>\u0010,\u00a8\u0006]"}, d2 = {"Lcom/example/gestaobilhares/data/entities/Acerto;", "", "id", "", "clienteId", "colaboradorId", "dataAcerto", "Ljava/util/Date;", "periodoInicio", "periodoFim", "totalMesas", "", "debitoAnterior", "valorTotal", "desconto", "valorComDesconto", "valorRecebido", "debitoAtual", "status", "Lcom/example/gestaobilhares/data/entities/StatusAcerto;", "observacoes", "", "dataCriacao", "dataFinalizacao", "metodosPagamentoJson", "representante", "tipoAcerto", "panoTrocado", "", "numeroPano", "dadosExtrasJson", "(JJLjava/lang/Long;Ljava/util/Date;Ljava/util/Date;Ljava/util/Date;DDDDDDDLcom/example/gestaobilhares/data/entities/StatusAcerto;Ljava/lang/String;Ljava/util/Date;Ljava/util/Date;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;Ljava/lang/String;)V", "getClienteId", "()J", "getColaboradorId", "()Ljava/lang/Long;", "Ljava/lang/Long;", "getDadosExtrasJson", "()Ljava/lang/String;", "getDataAcerto", "()Ljava/util/Date;", "getDataCriacao", "getDataFinalizacao", "getDebitoAnterior", "()D", "getDebitoAtual", "getDesconto", "getId", "getMetodosPagamentoJson", "getNumeroPano", "getObservacoes", "getPanoTrocado", "()Z", "getPeriodoFim", "getPeriodoInicio", "getRepresentante", "getStatus", "()Lcom/example/gestaobilhares/data/entities/StatusAcerto;", "getTipoAcerto", "getTotalMesas", "getValorComDesconto", "getValorRecebido", "getValorTotal", "component1", "component10", "component11", "component12", "component13", "component14", "component15", "component16", "component17", "component18", "component19", "component2", "component20", "component21", "component22", "component23", "component3", "component4", "component5", "component6", "component7", "component8", "component9", "copy", "(JJLjava/lang/Long;Ljava/util/Date;Ljava/util/Date;Ljava/util/Date;DDDDDDDLcom/example/gestaobilhares/data/entities/StatusAcerto;Ljava/lang/String;Ljava/util/Date;Ljava/util/Date;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;Ljava/lang/String;)Lcom/example/gestaobilhares/data/entities/Acerto;", "equals", "other", "hashCode", "", "toString", "app_debug"})
@androidx.room.Entity(tableName = "acertos", foreignKeys = {@androidx.room.ForeignKey(entity = com.example.gestaobilhares.data.entities.Cliente.class, parentColumns = {"id"}, childColumns = {"cliente_id"}, onDelete = 5), @androidx.room.ForeignKey(entity = com.example.gestaobilhares.data.entities.Colaborador.class, parentColumns = {"id"}, childColumns = {"colaborador_id"}, onDelete = 3)}, indices = {@androidx.room.Index(value = {"cliente_id"}), @androidx.room.Index(value = {"colaborador_id"})})
public final class Acerto {
    @androidx.room.PrimaryKey(autoGenerate = true)
    private final long id = 0L;
    @androidx.room.ColumnInfo(name = "cliente_id")
    private final long clienteId = 0L;
    @androidx.room.ColumnInfo(name = "colaborador_id")
    @org.jetbrains.annotations.Nullable()
    private final java.lang.Long colaboradorId = null;
    @androidx.room.ColumnInfo(name = "data_acerto")
    @org.jetbrains.annotations.NotNull()
    private final java.util.Date dataAcerto = null;
    @androidx.room.ColumnInfo(name = "periodo_inicio")
    @org.jetbrains.annotations.NotNull()
    private final java.util.Date periodoInicio = null;
    @androidx.room.ColumnInfo(name = "periodo_fim")
    @org.jetbrains.annotations.NotNull()
    private final java.util.Date periodoFim = null;
    @androidx.room.ColumnInfo(name = "total_mesas")
    private final double totalMesas = 0.0;
    @androidx.room.ColumnInfo(name = "debito_anterior")
    private final double debitoAnterior = 0.0;
    @androidx.room.ColumnInfo(name = "valor_total")
    private final double valorTotal = 0.0;
    @androidx.room.ColumnInfo(name = "desconto")
    private final double desconto = 0.0;
    @androidx.room.ColumnInfo(name = "valor_com_desconto")
    private final double valorComDesconto = 0.0;
    @androidx.room.ColumnInfo(name = "valor_recebido")
    private final double valorRecebido = 0.0;
    @androidx.room.ColumnInfo(name = "debito_atual")
    private final double debitoAtual = 0.0;
    @androidx.room.ColumnInfo(name = "status")
    @org.jetbrains.annotations.NotNull()
    private final com.example.gestaobilhares.data.entities.StatusAcerto status = null;
    @androidx.room.ColumnInfo(name = "observacoes")
    @org.jetbrains.annotations.Nullable()
    private final java.lang.String observacoes = null;
    @androidx.room.ColumnInfo(name = "data_criacao")
    @org.jetbrains.annotations.NotNull()
    private final java.util.Date dataCriacao = null;
    @androidx.room.ColumnInfo(name = "data_finalizacao")
    @org.jetbrains.annotations.Nullable()
    private final java.util.Date dataFinalizacao = null;
    @androidx.room.ColumnInfo(name = "metodos_pagamento_json")
    @org.jetbrains.annotations.Nullable()
    private final java.lang.String metodosPagamentoJson = null;
    @androidx.room.ColumnInfo(name = "representante")
    @org.jetbrains.annotations.Nullable()
    private final java.lang.String representante = null;
    @androidx.room.ColumnInfo(name = "tipo_acerto")
    @org.jetbrains.annotations.Nullable()
    private final java.lang.String tipoAcerto = null;
    @androidx.room.ColumnInfo(name = "pano_trocado")
    private final boolean panoTrocado = false;
    @androidx.room.ColumnInfo(name = "numero_pano")
    @org.jetbrains.annotations.Nullable()
    private final java.lang.String numeroPano = null;
    @androidx.room.ColumnInfo(name = "dados_extras_json")
    @org.jetbrains.annotations.Nullable()
    private final java.lang.String dadosExtrasJson = null;
    
    public Acerto(long id, long clienteId, @org.jetbrains.annotations.Nullable()
    java.lang.Long colaboradorId, @org.jetbrains.annotations.NotNull()
    java.util.Date dataAcerto, @org.jetbrains.annotations.NotNull()
    java.util.Date periodoInicio, @org.jetbrains.annotations.NotNull()
    java.util.Date periodoFim, double totalMesas, double debitoAnterior, double valorTotal, double desconto, double valorComDesconto, double valorRecebido, double debitoAtual, @org.jetbrains.annotations.NotNull()
    com.example.gestaobilhares.data.entities.StatusAcerto status, @org.jetbrains.annotations.Nullable()
    java.lang.String observacoes, @org.jetbrains.annotations.NotNull()
    java.util.Date dataCriacao, @org.jetbrains.annotations.Nullable()
    java.util.Date dataFinalizacao, @org.jetbrains.annotations.Nullable()
    java.lang.String metodosPagamentoJson, @org.jetbrains.annotations.Nullable()
    java.lang.String representante, @org.jetbrains.annotations.Nullable()
    java.lang.String tipoAcerto, boolean panoTrocado, @org.jetbrains.annotations.Nullable()
    java.lang.String numeroPano, @org.jetbrains.annotations.Nullable()
    java.lang.String dadosExtrasJson) {
        super();
    }
    
    public final long getId() {
        return 0L;
    }
    
    public final long getClienteId() {
        return 0L;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.lang.Long getColaboradorId() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.util.Date getDataAcerto() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.util.Date getPeriodoInicio() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.util.Date getPeriodoFim() {
        return null;
    }
    
    public final double getTotalMesas() {
        return 0.0;
    }
    
    public final double getDebitoAnterior() {
        return 0.0;
    }
    
    public final double getValorTotal() {
        return 0.0;
    }
    
    public final double getDesconto() {
        return 0.0;
    }
    
    public final double getValorComDesconto() {
        return 0.0;
    }
    
    public final double getValorRecebido() {
        return 0.0;
    }
    
    public final double getDebitoAtual() {
        return 0.0;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.example.gestaobilhares.data.entities.StatusAcerto getStatus() {
        return null;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.lang.String getObservacoes() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.util.Date getDataCriacao() {
        return null;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.util.Date getDataFinalizacao() {
        return null;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.lang.String getMetodosPagamentoJson() {
        return null;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.lang.String getRepresentante() {
        return null;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.lang.String getTipoAcerto() {
        return null;
    }
    
    public final boolean getPanoTrocado() {
        return false;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.lang.String getNumeroPano() {
        return null;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.lang.String getDadosExtrasJson() {
        return null;
    }
    
    public final long component1() {
        return 0L;
    }
    
    public final double component10() {
        return 0.0;
    }
    
    public final double component11() {
        return 0.0;
    }
    
    public final double component12() {
        return 0.0;
    }
    
    public final double component13() {
        return 0.0;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.example.gestaobilhares.data.entities.StatusAcerto component14() {
        return null;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.lang.String component15() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.util.Date component16() {
        return null;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.util.Date component17() {
        return null;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.lang.String component18() {
        return null;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.lang.String component19() {
        return null;
    }
    
    public final long component2() {
        return 0L;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.lang.String component20() {
        return null;
    }
    
    public final boolean component21() {
        return false;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.lang.String component22() {
        return null;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.lang.String component23() {
        return null;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.lang.Long component3() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.util.Date component4() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.util.Date component5() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.util.Date component6() {
        return null;
    }
    
    public final double component7() {
        return 0.0;
    }
    
    public final double component8() {
        return 0.0;
    }
    
    public final double component9() {
        return 0.0;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.example.gestaobilhares.data.entities.Acerto copy(long id, long clienteId, @org.jetbrains.annotations.Nullable()
    java.lang.Long colaboradorId, @org.jetbrains.annotations.NotNull()
    java.util.Date dataAcerto, @org.jetbrains.annotations.NotNull()
    java.util.Date periodoInicio, @org.jetbrains.annotations.NotNull()
    java.util.Date periodoFim, double totalMesas, double debitoAnterior, double valorTotal, double desconto, double valorComDesconto, double valorRecebido, double debitoAtual, @org.jetbrains.annotations.NotNull()
    com.example.gestaobilhares.data.entities.StatusAcerto status, @org.jetbrains.annotations.Nullable()
    java.lang.String observacoes, @org.jetbrains.annotations.NotNull()
    java.util.Date dataCriacao, @org.jetbrains.annotations.Nullable()
    java.util.Date dataFinalizacao, @org.jetbrains.annotations.Nullable()
    java.lang.String metodosPagamentoJson, @org.jetbrains.annotations.Nullable()
    java.lang.String representante, @org.jetbrains.annotations.Nullable()
    java.lang.String tipoAcerto, boolean panoTrocado, @org.jetbrains.annotations.Nullable()
    java.lang.String numeroPano, @org.jetbrains.annotations.Nullable()
    java.lang.String dadosExtrasJson) {
        return null;
    }
    
    @java.lang.Override()
    public boolean equals(@org.jetbrains.annotations.Nullable()
    java.lang.Object other) {
        return false;
    }
    
    @java.lang.Override()
    public int hashCode() {
        return 0;
    }
    
    @java.lang.Override()
    @org.jetbrains.annotations.NotNull()
    public java.lang.String toString() {
        return null;
    }
}