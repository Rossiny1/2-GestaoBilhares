package com.example.gestaobilhares.data.entities;

/**
 * Entidade que representa o relacionamento entre Acerto e Mesa.
 * Armazena o histórico detalhado de cada mesa em cada acerto.
 */
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u00006\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\t\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0010\u0006\n\u0002\b\u0004\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\'\b\u0087\b\u0018\u00002\u00020\u0001B}\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0003\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\b\u001a\u00020\u0007\u0012\u0006\u0010\t\u001a\u00020\u0007\u0012\b\b\u0002\u0010\n\u001a\u00020\u000b\u0012\b\b\u0002\u0010\f\u001a\u00020\u000b\u0012\b\b\u0002\u0010\r\u001a\u00020\u000b\u0012\u0006\u0010\u000e\u001a\u00020\u000b\u0012\b\b\u0002\u0010\u000f\u001a\u00020\u0010\u0012\n\b\u0002\u0010\u0011\u001a\u0004\u0018\u00010\u0012\u0012\b\b\u0002\u0010\u0013\u001a\u00020\u0014\u00a2\u0006\u0002\u0010\u0015J\t\u0010)\u001a\u00020\u0003H\u00c6\u0003J\t\u0010*\u001a\u00020\u000bH\u00c6\u0003J\t\u0010+\u001a\u00020\u0010H\u00c6\u0003J\u000b\u0010,\u001a\u0004\u0018\u00010\u0012H\u00c6\u0003J\t\u0010-\u001a\u00020\u0014H\u00c6\u0003J\t\u0010.\u001a\u00020\u0003H\u00c6\u0003J\t\u0010/\u001a\u00020\u0003H\u00c6\u0003J\t\u00100\u001a\u00020\u0007H\u00c6\u0003J\t\u00101\u001a\u00020\u0007H\u00c6\u0003J\t\u00102\u001a\u00020\u0007H\u00c6\u0003J\t\u00103\u001a\u00020\u000bH\u00c6\u0003J\t\u00104\u001a\u00020\u000bH\u00c6\u0003J\t\u00105\u001a\u00020\u000bH\u00c6\u0003J\u008d\u0001\u00106\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00032\b\b\u0002\u0010\u0005\u001a\u00020\u00032\b\b\u0002\u0010\u0006\u001a\u00020\u00072\b\b\u0002\u0010\b\u001a\u00020\u00072\b\b\u0002\u0010\t\u001a\u00020\u00072\b\b\u0002\u0010\n\u001a\u00020\u000b2\b\b\u0002\u0010\f\u001a\u00020\u000b2\b\b\u0002\u0010\r\u001a\u00020\u000b2\b\b\u0002\u0010\u000e\u001a\u00020\u000b2\b\b\u0002\u0010\u000f\u001a\u00020\u00102\n\b\u0002\u0010\u0011\u001a\u0004\u0018\u00010\u00122\b\b\u0002\u0010\u0013\u001a\u00020\u0014H\u00c6\u0001J\u0013\u00107\u001a\u00020\u00102\b\u00108\u001a\u0004\u0018\u00010\u0001H\u00d6\u0003J\t\u00109\u001a\u00020\u0007H\u00d6\u0001J\t\u0010:\u001a\u00020\u0012H\u00d6\u0001R\u0016\u0010\u0004\u001a\u00020\u00038\u0006X\u0087\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0016\u0010\u0017R\u0016\u0010\u000f\u001a\u00020\u00108\u0006X\u0087\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0018\u0010\u0019R\u0016\u0010\r\u001a\u00020\u000b8\u0006X\u0087\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001a\u0010\u001bR\u0016\u0010\u0013\u001a\u00020\u00148\u0006X\u0087\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001c\u0010\u001dR\u0016\u0010\t\u001a\u00020\u00078\u0006X\u0087\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001e\u0010\u001fR\u0016\u0010\u0002\u001a\u00020\u00038\u0006X\u0087\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b \u0010\u0017R\u0016\u0010\u0005\u001a\u00020\u00038\u0006X\u0087\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b!\u0010\u0017R\u0018\u0010\u0011\u001a\u0004\u0018\u00010\u00128\u0006X\u0087\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\"\u0010#R\u0016\u0010\b\u001a\u00020\u00078\u0006X\u0087\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b$\u0010\u001fR\u0016\u0010\u0006\u001a\u00020\u00078\u0006X\u0087\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b%\u0010\u001fR\u0016\u0010\u000e\u001a\u00020\u000b8\u0006X\u0087\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b&\u0010\u001bR\u0016\u0010\f\u001a\u00020\u000b8\u0006X\u0087\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\'\u0010\u001bR\u0016\u0010\n\u001a\u00020\u000b8\u0006X\u0087\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b(\u0010\u001b\u00a8\u0006;"}, d2 = {"Lcom/example/gestaobilhares/data/entities/AcertoMesa;", "", "id", "", "acertoId", "mesaId", "relogioInicial", "", "relogioFinal", "fichasJogadas", "valorFixo", "", "valorFicha", "comissaoFicha", "subtotal", "comDefeito", "", "observacoes", "", "dataCriacao", "Ljava/util/Date;", "(JJJIIIDDDDZLjava/lang/String;Ljava/util/Date;)V", "getAcertoId", "()J", "getComDefeito", "()Z", "getComissaoFicha", "()D", "getDataCriacao", "()Ljava/util/Date;", "getFichasJogadas", "()I", "getId", "getMesaId", "getObservacoes", "()Ljava/lang/String;", "getRelogioFinal", "getRelogioInicial", "getSubtotal", "getValorFicha", "getValorFixo", "component1", "component10", "component11", "component12", "component13", "component2", "component3", "component4", "component5", "component6", "component7", "component8", "component9", "copy", "equals", "other", "hashCode", "toString", "app_debug"})
@androidx.room.Entity(tableName = "acerto_mesas", foreignKeys = {@androidx.room.ForeignKey(entity = com.example.gestaobilhares.data.entities.Acerto.class, parentColumns = {"id"}, childColumns = {"acerto_id"}, onDelete = 5), @androidx.room.ForeignKey(entity = com.example.gestaobilhares.data.entities.Mesa.class, parentColumns = {"id"}, childColumns = {"mesa_id"}, onDelete = 5)}, indices = {@androidx.room.Index(value = {"acerto_id"}), @androidx.room.Index(value = {"mesa_id"}), @androidx.room.Index(value = {"acerto_id", "mesa_id"}, unique = true)})
public final class AcertoMesa {
    @androidx.room.PrimaryKey(autoGenerate = true)
    private final long id = 0L;
    @androidx.room.ColumnInfo(name = "acerto_id")
    private final long acertoId = 0L;
    @androidx.room.ColumnInfo(name = "mesa_id")
    private final long mesaId = 0L;
    @androidx.room.ColumnInfo(name = "relogio_inicial")
    private final int relogioInicial = 0;
    @androidx.room.ColumnInfo(name = "relogio_final")
    private final int relogioFinal = 0;
    @androidx.room.ColumnInfo(name = "fichas_jogadas")
    private final int fichasJogadas = 0;
    @androidx.room.ColumnInfo(name = "valor_fixo")
    private final double valorFixo = 0.0;
    @androidx.room.ColumnInfo(name = "valor_ficha")
    private final double valorFicha = 0.0;
    @androidx.room.ColumnInfo(name = "comissao_ficha")
    private final double comissaoFicha = 0.0;
    @androidx.room.ColumnInfo(name = "subtotal")
    private final double subtotal = 0.0;
    @androidx.room.ColumnInfo(name = "com_defeito")
    private final boolean comDefeito = false;
    @androidx.room.ColumnInfo(name = "observacoes")
    @org.jetbrains.annotations.Nullable()
    private final java.lang.String observacoes = null;
    @androidx.room.ColumnInfo(name = "data_criacao")
    @org.jetbrains.annotations.NotNull()
    private final java.util.Date dataCriacao = null;
    
    public AcertoMesa(long id, long acertoId, long mesaId, int relogioInicial, int relogioFinal, int fichasJogadas, double valorFixo, double valorFicha, double comissaoFicha, double subtotal, boolean comDefeito, @org.jetbrains.annotations.Nullable()
    java.lang.String observacoes, @org.jetbrains.annotations.NotNull()
    java.util.Date dataCriacao) {
        super();
    }
    
    public final long getId() {
        return 0L;
    }
    
    public final long getAcertoId() {
        return 0L;
    }
    
    public final long getMesaId() {
        return 0L;
    }
    
    public final int getRelogioInicial() {
        return 0;
    }
    
    public final int getRelogioFinal() {
        return 0;
    }
    
    public final int getFichasJogadas() {
        return 0;
    }
    
    public final double getValorFixo() {
        return 0.0;
    }
    
    public final double getValorFicha() {
        return 0.0;
    }
    
    public final double getComissaoFicha() {
        return 0.0;
    }
    
    public final double getSubtotal() {
        return 0.0;
    }
    
    public final boolean getComDefeito() {
        return false;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.lang.String getObservacoes() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.util.Date getDataCriacao() {
        return null;
    }
    
    public final long component1() {
        return 0L;
    }
    
    public final double component10() {
        return 0.0;
    }
    
    public final boolean component11() {
        return false;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.lang.String component12() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.util.Date component13() {
        return null;
    }
    
    public final long component2() {
        return 0L;
    }
    
    public final long component3() {
        return 0L;
    }
    
    public final int component4() {
        return 0;
    }
    
    public final int component5() {
        return 0;
    }
    
    public final int component6() {
        return 0;
    }
    
    public final double component7() {
        return 0.0;
    }
    
    public final double component8() {
        return 0.0;
    }
    
    public final double component9() {
        return 0.0;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.example.gestaobilhares.data.entities.AcertoMesa copy(long id, long acertoId, long mesaId, int relogioInicial, int relogioFinal, int fichasJogadas, double valorFixo, double valorFicha, double comissaoFicha, double subtotal, boolean comDefeito, @org.jetbrains.annotations.Nullable()
    java.lang.String observacoes, @org.jetbrains.annotations.NotNull()
    java.util.Date dataCriacao) {
        return null;
    }
    
    @java.lang.Override()
    public boolean equals(@org.jetbrains.annotations.Nullable()
    java.lang.Object other) {
        return false;
    }
    
    @java.lang.Override()
    public int hashCode() {
        return 0;
    }
    
    @java.lang.Override()
    @org.jetbrains.annotations.NotNull()
    public java.lang.String toString() {
        return null;
    }
}