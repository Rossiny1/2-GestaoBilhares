package com.example.gestaobilhares.ui.routes.management;

/**
 * Fragment para gerenciamento de rotas (CRUD).
 * Permite criar, editar e excluir rotas.
 * Acesso restrito apenas para administradores.
 */
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000H\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u00002\u00020\u0001B\u0005\u00a2\u0006\u0002\u0010\u0002J\b\u0010\f\u001a\u00020\rH\u0002J$\u0010\u000e\u001a\u00020\u000f2\u0006\u0010\u0010\u001a\u00020\u00112\b\u0010\u0012\u001a\u0004\u0018\u00010\u00132\b\u0010\u0014\u001a\u0004\u0018\u00010\u0015H\u0016J\b\u0010\u0016\u001a\u00020\rH\u0016J\u001a\u0010\u0017\u001a\u00020\r2\u0006\u0010\u0018\u001a\u00020\u000f2\b\u0010\u0014\u001a\u0004\u0018\u00010\u0015H\u0016J\b\u0010\u0019\u001a\u00020\rH\u0002J\b\u0010\u001a\u001a\u00020\rH\u0002J\u0012\u0010\u001b\u001a\u00020\r2\b\u0010\u001c\u001a\u0004\u0018\u00010\u001dH\u0002J\u0010\u0010\u001e\u001a\u00020\r2\u0006\u0010\u001c\u001a\u00020\u001dH\u0002R\u0010\u0010\u0003\u001a\u0004\u0018\u00010\u0004X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0014\u0010\u0005\u001a\u00020\u00048BX\u0082\u0004\u00a2\u0006\u0006\u001a\u0004\b\u0006\u0010\u0007R\u000e\u0010\b\u001a\u00020\tX\u0082.\u00a2\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u000bX\u0082.\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u001f"}, d2 = {"Lcom/example/gestaobilhares/ui/routes/management/RouteManagementFragment;", "Landroidx/fragment/app/Fragment;", "()V", "_binding", "Lcom/example/gestaobilhares/databinding/FragmentRouteManagementBinding;", "binding", "getBinding", "()Lcom/example/gestaobilhares/databinding/FragmentRouteManagementBinding;", "routeAdapter", "Lcom/example/gestaobilhares/ui/routes/management/RouteManagementAdapter;", "viewModel", "Lcom/example/gestaobilhares/ui/routes/management/RouteManagementViewModel;", "observeViewModel", "", "onCreateView", "Landroid/view/View;", "inflater", "Landroid/view/LayoutInflater;", "container", "Landroid/view/ViewGroup;", "savedInstanceState", "Landroid/os/Bundle;", "onDestroyView", "onViewCreated", "view", "setupClickListeners", "setupRecyclerView", "showAddEditRouteDialog", "rota", "Lcom/example/gestaobilhares/data/entities/Rota;", "showDeleteConfirmationDialog", "app_debug"})
public final class RouteManagementFragment extends androidx.fragment.app.Fragment {
    @org.jetbrains.annotations.Nullable()
    private com.example.gestaobilhares.databinding.FragmentRouteManagementBinding _binding;
    private com.example.gestaobilhares.ui.routes.management.RouteManagementViewModel viewModel;
    private com.example.gestaobilhares.ui.routes.management.RouteManagementAdapter routeAdapter;
    
    public RouteManagementFragment() {
        super();
    }
    
    private final com.example.gestaobilhares.databinding.FragmentRouteManagementBinding getBinding() {
        return null;
    }
    
    @java.lang.Override()
    @org.jetbrains.annotations.NotNull()
    public android.view.View onCreateView(@org.jetbrains.annotations.NotNull()
    android.view.LayoutInflater inflater, @org.jetbrains.annotations.Nullable()
    android.view.ViewGroup container, @org.jetbrains.annotations.Nullable()
    android.os.Bundle savedInstanceState) {
        return null;
    }
    
    @java.lang.Override()
    public void onViewCreated(@org.jetbrains.annotations.NotNull()
    android.view.View view, @org.jetbrains.annotations.Nullable()
    android.os.Bundle savedInstanceState) {
    }
    
    /**
     * Configura o RecyclerView com o adapter para gerenciamento de rotas.
     */
    private final void setupRecyclerView() {
    }
    
    /**
     * Configura os listeners de clique dos botões.
     */
    private final void setupClickListeners() {
    }
    
    /**
     * Observa as mudanças no ViewModel e atualiza a UI.
     */
    private final void observeViewModel() {
    }
    
    /**
     * Mostra o diálogo para adicionar ou editar uma rota.
     */
    private final void showAddEditRouteDialog(com.example.gestaobilhares.data.entities.Rota rota) {
    }
    
    /**
     * Mostra o diálogo de confirmação para excluir uma rota.
     */
    private final void showDeleteConfirmationDialog(com.example.gestaobilhares.data.entities.Rota rota) {
    }
    
    @java.lang.Override()
    public void onDestroyView() {
    }
}