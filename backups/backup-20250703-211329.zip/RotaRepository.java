package com.example.gestaobilhares.data.repository;

/**
 * Repository para gerenciar dados das rotas.
 * Atua como uma única fonte de verdade para os dados das rotas.
 * Coordena entre o banco de dados local e futuras fontes remotas.
 */
@javax.inject.Singleton()
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000X\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\t\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0004\n\u0002\u0010\u000e\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0002\b\u0006\b\u0007\u0018\u00002\u00020\u0001B\u000f\b\u0007\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0002\u0010\u0004J\u0016\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\bH\u0086@\u00a2\u0006\u0002\u0010\tJ\u001e\u0010\n\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\b2\u0006\u0010\u000b\u001a\u00020\fH\u0086@\u00a2\u0006\u0002\u0010\rJ\u000e\u0010\u000e\u001a\u00020\u000fH\u0086@\u00a2\u0006\u0002\u0010\u0010J\u0016\u0010\u0011\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\bH\u0086@\u00a2\u0006\u0002\u0010\tJ \u0010\u0012\u001a\u00020\u00062\u0006\u0010\u0013\u001a\u00020\u00142\b\b\u0002\u0010\u0015\u001a\u00020\bH\u0086@\u00a2\u0006\u0002\u0010\u0016J\u0016\u0010\u0017\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\bH\u0086@\u00a2\u0006\u0002\u0010\tJ\u0012\u0010\u0018\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u001b0\u001a0\u0019J\u0012\u0010\u001c\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u001b0\u001a0\u0019J\u0018\u0010\u001d\u001a\u0004\u0018\u00010\u001b2\u0006\u0010\u0007\u001a\u00020\bH\u0086@\u00a2\u0006\u0002\u0010\tJ\u0018\u0010\u001e\u001a\u0004\u0018\u00010\u001b2\u0006\u0010\u0013\u001a\u00020\u0014H\u0086@\u00a2\u0006\u0002\u0010\u001fJ\u0012\u0010 \u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020!0\u001a0\u0019J\u001e\u0010\"\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\b2\u0006\u0010#\u001a\u00020\u000fH\u0086@\u00a2\u0006\u0002\u0010$J\u000e\u0010%\u001a\u00020&H\u0086@\u00a2\u0006\u0002\u0010\u0010J\u0018\u0010\'\u001a\u0004\u0018\u00010\b2\u0006\u0010(\u001a\u00020\u001bH\u0086@\u00a2\u0006\u0002\u0010)J\u0016\u0010*\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u001b0\u00192\u0006\u0010\u0007\u001a\u00020\bJ\u0016\u0010+\u001a\u00020\u00062\u0006\u0010(\u001a\u00020\u001bH\u0086@\u00a2\u0006\u0002\u0010)R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006,"}, d2 = {"Lcom/example/gestaobilhares/data/repository/RotaRepository;", "", "rotaDao", "Lcom/example/gestaobilhares/data/dao/RotaDao;", "(Lcom/example/gestaobilhares/data/dao/RotaDao;)V", "ativarRota", "", "rotaId", "", "(JLkotlin/coroutines/Continuation;)Ljava/lang/Object;", "atualizarStatusRota", "status", "Lcom/example/gestaobilhares/data/entities/StatusRota;", "(JLcom/example/gestaobilhares/data/entities/StatusRota;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "contarRotasAtivas", "", "(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "desativarRota", "existeRotaComNome", "nome", "", "excludeId", "(Ljava/lang/String;JLkotlin/coroutines/Continuation;)Ljava/lang/Object;", "finalizarCicloRota", "getAllRotas", "Lkotlinx/coroutines/flow/Flow;", "", "Lcom/example/gestaobilhares/data/entities/Rota;", "getAllRotasAtivas", "getRotaById", "getRotaByNome", "(Ljava/lang/String;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "getRotasResumo", "Lcom/example/gestaobilhares/data/entities/RotaResumo;", "iniciarCicloRota", "numeroCiclo", "(JILkotlin/coroutines/Continuation;)Ljava/lang/Object;", "inserirRotasExemplo", "", "insertRota", "rota", "(Lcom/example/gestaobilhares/data/entities/Rota;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "obterRotaPorId", "updateRota", "app_debug"})
public final class RotaRepository {
    @org.jetbrains.annotations.NotNull()
    private final com.example.gestaobilhares.data.dao.RotaDao rotaDao = null;
    
    @javax.inject.Inject()
    public RotaRepository(@org.jetbrains.annotations.NotNull()
    com.example.gestaobilhares.data.dao.RotaDao rotaDao) {
        super();
    }
    
    /**
     * Obtém todas as rotas ativas como Flow.
     * O Flow permite observar mudanças em tempo real.
     */
    @org.jetbrains.annotations.NotNull()
    public final kotlinx.coroutines.flow.Flow<java.util.List<com.example.gestaobilhares.data.entities.Rota>> getAllRotasAtivas() {
        return null;
    }
    
    /**
     * Obtém todas as rotas (ativas e inativas).
     */
    @org.jetbrains.annotations.NotNull()
    public final kotlinx.coroutines.flow.Flow<java.util.List<com.example.gestaobilhares.data.entities.Rota>> getAllRotas() {
        return null;
    }
    
    /**
     * Obtém um resumo de todas as rotas com estatísticas simuladas.
     * TODO: Implementar cálculos reais quando as outras entidades estiverem prontas.
     */
    @org.jetbrains.annotations.NotNull()
    public final kotlinx.coroutines.flow.Flow<java.util.List<com.example.gestaobilhares.data.entities.RotaResumo>> getRotasResumo() {
        return null;
    }
    
    /**
     * Obtém uma rota específica por ID.
     */
    @org.jetbrains.annotations.Nullable()
    public final java.lang.Object getRotaById(long rotaId, @org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super com.example.gestaobilhares.data.entities.Rota> $completion) {
        return null;
    }
    
    /**
     * Obtém uma rota específica por ID como Flow.
     */
    @org.jetbrains.annotations.NotNull()
    public final kotlinx.coroutines.flow.Flow<com.example.gestaobilhares.data.entities.Rota> obterRotaPorId(long rotaId) {
        return null;
    }
    
    /**
     * Obtém uma rota por nome (útil para validação).
     */
    @org.jetbrains.annotations.Nullable()
    public final java.lang.Object getRotaByNome(@org.jetbrains.annotations.NotNull()
    java.lang.String nome, @org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super com.example.gestaobilhares.data.entities.Rota> $completion) {
        return null;
    }
    
    /**
     * Insere uma nova rota.
     * @param rota A rota a ser inserida
     * @return O ID da rota inserida ou null se houve erro
     */
    @org.jetbrains.annotations.Nullable()
    public final java.lang.Object insertRota(@org.jetbrains.annotations.NotNull()
    com.example.gestaobilhares.data.entities.Rota rota, @org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super java.lang.Long> $completion) {
        return null;
    }
    
    /**
     * Atualiza uma rota existente.
     */
    @org.jetbrains.annotations.Nullable()
    public final java.lang.Object updateRota(@org.jetbrains.annotations.NotNull()
    com.example.gestaobilhares.data.entities.Rota rota, @org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super java.lang.Boolean> $completion) {
        return null;
    }
    
    /**
     * Desativa uma rota (soft delete).
     */
    @org.jetbrains.annotations.Nullable()
    public final java.lang.Object desativarRota(long rotaId, @org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super java.lang.Boolean> $completion) {
        return null;
    }
    
    /**
     * Ativa uma rota novamente.
     */
    @org.jetbrains.annotations.Nullable()
    public final java.lang.Object ativarRota(long rotaId, @org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super java.lang.Boolean> $completion) {
        return null;
    }
    
    /**
     * Verifica se uma rota com o nome especificado já existe.
     */
    @org.jetbrains.annotations.Nullable()
    public final java.lang.Object existeRotaComNome(@org.jetbrains.annotations.NotNull()
    java.lang.String nome, long excludeId, @org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super java.lang.Boolean> $completion) {
        return null;
    }
    
    /**
     * Conta o total de rotas ativas.
     */
    @org.jetbrains.annotations.Nullable()
    public final java.lang.Object contarRotasAtivas(@org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super java.lang.Integer> $completion) {
        return null;
    }
    
    /**
     * Insere rotas de exemplo para demonstração.
     * Este método deve ser chamado apenas para popular o banco com dados iniciais.
     */
    @org.jetbrains.annotations.Nullable()
    public final java.lang.Object inserirRotasExemplo(@org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super kotlin.Unit> $completion) {
        return null;
    }
    
    /**
     * Atualiza o status da rota.
     */
    @org.jetbrains.annotations.Nullable()
    public final java.lang.Object atualizarStatusRota(long rotaId, @org.jetbrains.annotations.NotNull()
    com.example.gestaobilhares.data.entities.StatusRota status, @org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super java.lang.Boolean> $completion) {
        return null;
    }
    
    /**
     * Inicia um novo ciclo de acerto para a rota.
     */
    @org.jetbrains.annotations.Nullable()
    public final java.lang.Object iniciarCicloRota(long rotaId, int numeroCiclo, @org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super java.lang.Boolean> $completion) {
        return null;
    }
    
    /**
     * Finaliza o ciclo atual da rota.
     */
    @org.jetbrains.annotations.Nullable()
    public final java.lang.Object finalizarCicloRota(long rotaId, @org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super java.lang.Boolean> $completion) {
        return null;
    }
}