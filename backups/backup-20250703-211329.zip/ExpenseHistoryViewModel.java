package com.example.gestaobilhares.ui.expenses;

/**
 * ViewModel para a tela de histórico de despesas.
 * Gerencia dados de despesas, filtros e estados da UI.
 */
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000^\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0010\u0002\n\u0002\b\u0007\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u0006\n\u0002\b\u0006\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0002\u0010\u0004J\u0006\u0010\u001f\u001a\u00020 J\u0006\u0010!\u001a\u00020 J\u000e\u0010\"\u001a\u00020 2\u0006\u0010#\u001a\u00020\u000bJ\u0006\u0010$\u001a\u00020 J\u0010\u0010%\u001a\u00020 2\b\u0010&\u001a\u0004\u0018\u00010\u0007J\u0006\u0010\'\u001a\u00020(J\u0006\u0010)\u001a\u00020*J\u0006\u0010+\u001a\u00020\rJ\b\u0010,\u001a\u00020 H\u0002J\u0006\u0010-\u001a\u00020 J\u000e\u0010.\u001a\u00020 2\u0006\u0010/\u001a\u00020\u0007R\u0016\u0010\u0005\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00070\u0006X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u001a\u0010\b\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u000b0\n0\tX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u0010\f\u001a\b\u0012\u0004\u0012\u00020\r0\tX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0016\u0010\u000e\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00070\tX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0016\u0010\u000f\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00070\u0006X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u001a\u0010\u0010\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u000b0\n0\u0011X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0019\u0010\u0012\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00070\u0013\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0014\u0010\u0015R\u001d\u0010\u0016\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u000b0\n0\u0017\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0018\u0010\u0019R\u0017\u0010\u001a\u001a\b\u0012\u0004\u0012\u00020\r0\u0017\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001a\u0010\u0019R\u0019\u0010\u001b\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00070\u0017\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001c\u0010\u0019R\u0019\u0010\u001d\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00070\u0013\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001e\u0010\u0015\u00a8\u00060"}, d2 = {"Lcom/example/gestaobilhares/ui/expenses/ExpenseHistoryViewModel;", "Landroidx/lifecycle/ViewModel;", "despesaRepository", "Lcom/example/gestaobilhares/data/repository/DespesaRepository;", "(Lcom/example/gestaobilhares/data/repository/DespesaRepository;)V", "_errorMessage", "Landroidx/lifecycle/MutableLiveData;", "", "_filteredExpenses", "Lkotlinx/coroutines/flow/MutableStateFlow;", "", "Lcom/example/gestaobilhares/data/entities/DespesaResumo;", "_isLoading", "", "_selectedCategory", "_successMessage", "allExpenses", "Lkotlinx/coroutines/flow/Flow;", "errorMessage", "Landroidx/lifecycle/LiveData;", "getErrorMessage", "()Landroidx/lifecycle/LiveData;", "filteredExpenses", "Lkotlinx/coroutines/flow/StateFlow;", "getFilteredExpenses", "()Lkotlinx/coroutines/flow/StateFlow;", "isLoading", "selectedCategory", "getSelectedCategory", "successMessage", "getSuccessMessage", "clearFilters", "", "clearMessages", "deleteExpense", "despesaResumo", "exportExpensesReport", "filterByCategory", "categoria", "getFilteredCount", "", "getFilteredTotal", "", "hasActiveFilters", "loadExpenses", "refreshExpenses", "searchExpenses", "query", "app_debug"})
public final class ExpenseHistoryViewModel extends androidx.lifecycle.ViewModel {
    @org.jetbrains.annotations.NotNull()
    private final com.example.gestaobilhares.data.repository.DespesaRepository despesaRepository = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlinx.coroutines.flow.MutableStateFlow<java.lang.Boolean> _isLoading = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlinx.coroutines.flow.StateFlow<java.lang.Boolean> isLoading = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlinx.coroutines.flow.MutableStateFlow<java.lang.String> _selectedCategory = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlinx.coroutines.flow.StateFlow<java.lang.String> selectedCategory = null;
    @org.jetbrains.annotations.NotNull()
    private final androidx.lifecycle.MutableLiveData<java.lang.String> _errorMessage = null;
    @org.jetbrains.annotations.NotNull()
    private final androidx.lifecycle.LiveData<java.lang.String> errorMessage = null;
    @org.jetbrains.annotations.NotNull()
    private final androidx.lifecycle.MutableLiveData<java.lang.String> _successMessage = null;
    @org.jetbrains.annotations.NotNull()
    private final androidx.lifecycle.LiveData<java.lang.String> successMessage = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlinx.coroutines.flow.MutableStateFlow<java.util.List<com.example.gestaobilhares.data.entities.DespesaResumo>> _filteredExpenses = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlinx.coroutines.flow.StateFlow<java.util.List<com.example.gestaobilhares.data.entities.DespesaResumo>> filteredExpenses = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlinx.coroutines.flow.Flow<java.util.List<com.example.gestaobilhares.data.entities.DespesaResumo>> allExpenses = null;
    
    public ExpenseHistoryViewModel(@org.jetbrains.annotations.NotNull()
    com.example.gestaobilhares.data.repository.DespesaRepository despesaRepository) {
        super();
    }
    
    @org.jetbrains.annotations.NotNull()
    public final kotlinx.coroutines.flow.StateFlow<java.lang.Boolean> isLoading() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final kotlinx.coroutines.flow.StateFlow<java.lang.String> getSelectedCategory() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final androidx.lifecycle.LiveData<java.lang.String> getErrorMessage() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final androidx.lifecycle.LiveData<java.lang.String> getSuccessMessage() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final kotlinx.coroutines.flow.StateFlow<java.util.List<com.example.gestaobilhares.data.entities.DespesaResumo>> getFilteredExpenses() {
        return null;
    }
    
    /**
     * Carrega as despesas e aplica filtros.
     */
    private final void loadExpenses() {
    }
    
    /**
     * Aplica filtro por categoria.
     * @param categoria Nome da categoria ou null para mostrar todas
     */
    public final void filterByCategory(@org.jetbrains.annotations.Nullable()
    java.lang.String categoria) {
    }
    
    /**
     * Remove filtros e mostra todas as despesas.
     */
    public final void clearFilters() {
    }
    
    /**
     * Atualiza as despesas (pull to refresh).
     */
    public final void refreshExpenses() {
    }
    
    /**
     * Deleta uma despesa específica.
     * @param despesaResumo A despesa a ser deletada
     */
    public final void deleteExpense(@org.jetbrains.annotations.NotNull()
    com.example.gestaobilhares.data.entities.DespesaResumo despesaResumo) {
    }
    
    /**
     * Busca despesas por texto (descrição ou observações).
     * @param query Texto a ser buscado
     */
    public final void searchExpenses(@org.jetbrains.annotations.NotNull()
    java.lang.String query) {
    }
    
    /**
     * Exporta relatório de despesas.
     */
    public final void exportExpensesReport() {
    }
    
    /**
     * Limpa mensagens de erro e sucesso.
     */
    public final void clearMessages() {
    }
    
    /**
     * Obtém o total de despesas filtradas.
     */
    public final double getFilteredTotal() {
        return 0.0;
    }
    
    /**
     * Obtém a quantidade de despesas filtradas.
     */
    public final int getFilteredCount() {
        return 0;
    }
    
    /**
     * Verifica se há filtros ativos.
     */
    public final boolean hasActiveFilters() {
        return false;
    }
}