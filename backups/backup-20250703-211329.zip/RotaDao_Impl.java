package com.example.gestaobilhares.data.dao;

import android.database.Cursor;
import android.os.CancellationSignal;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.room.CoroutinesRoom;
import androidx.room.EntityDeletionOrUpdateAdapter;
import androidx.room.EntityInsertionAdapter;
import androidx.room.RoomDatabase;
import androidx.room.RoomSQLiteQuery;
import androidx.room.SharedSQLiteStatement;
import androidx.room.util.CursorUtil;
import androidx.room.util.DBUtil;
import androidx.sqlite.db.SupportSQLiteStatement;
import com.example.gestaobilhares.data.entities.Rota;
import com.example.gestaobilhares.data.entities.StatusRota;
import java.lang.Class;
import java.lang.Exception;
import java.lang.IllegalArgumentException;
import java.lang.Integer;
import java.lang.Long;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.lang.SuppressWarnings;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.Callable;
import javax.annotation.processing.Generated;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlinx.coroutines.flow.Flow;

@Generated("androidx.room.RoomProcessor")
@SuppressWarnings({"unchecked", "deprecation"})
public final class RotaDao_Impl implements RotaDao {
  private final RoomDatabase __db;

  private final EntityInsertionAdapter<Rota> __insertionAdapterOfRota;

  private final EntityDeletionOrUpdateAdapter<Rota> __deletionAdapterOfRota;

  private final EntityDeletionOrUpdateAdapter<Rota> __updateAdapterOfRota;

  private final SharedSQLiteStatement __preparedStmtOfDesativarRota;

  private final SharedSQLiteStatement __preparedStmtOfAtivarRota;

  private final SharedSQLiteStatement __preparedStmtOfAtualizarStatus;

  private final SharedSQLiteStatement __preparedStmtOfAtualizarCicloAcerto;

  private final SharedSQLiteStatement __preparedStmtOfIniciarCicloRota;

  private final SharedSQLiteStatement __preparedStmtOfFinalizarCicloRota;

  public RotaDao_Impl(@NonNull final RoomDatabase __db) {
    this.__db = __db;
    this.__insertionAdapterOfRota = new EntityInsertionAdapter<Rota>(__db) {
      @Override
      @NonNull
      protected String createQuery() {
        return "INSERT OR ABORT INTO `rotas` (`id`,`nome`,`descricao`,`colaborador_responsavel`,`cidades`,`ativa`,`cor`,`data_criacao`,`data_atualizacao`,`status_atual`,`ciclo_acerto_atual`,`ano_ciclo`,`data_inicio_ciclo`,`data_fim_ciclo`) VALUES (nullif(?, 0),?,?,?,?,?,?,?,?,?,?,?,?,?)";
      }

      @Override
      protected void bind(@NonNull final SupportSQLiteStatement statement,
          @NonNull final Rota entity) {
        statement.bindLong(1, entity.getId());
        if (entity.getNome() == null) {
          statement.bindNull(2);
        } else {
          statement.bindString(2, entity.getNome());
        }
        if (entity.getDescricao() == null) {
          statement.bindNull(3);
        } else {
          statement.bindString(3, entity.getDescricao());
        }
        if (entity.getColaboradorResponsavel() == null) {
          statement.bindNull(4);
        } else {
          statement.bindString(4, entity.getColaboradorResponsavel());
        }
        if (entity.getCidades() == null) {
          statement.bindNull(5);
        } else {
          statement.bindString(5, entity.getCidades());
        }
        final int _tmp = entity.getAtiva() ? 1 : 0;
        statement.bindLong(6, _tmp);
        if (entity.getCor() == null) {
          statement.bindNull(7);
        } else {
          statement.bindString(7, entity.getCor());
        }
        statement.bindLong(8, entity.getDataCriacao());
        statement.bindLong(9, entity.getDataAtualizacao());
        statement.bindString(10, __StatusRota_enumToString(entity.getStatusAtual()));
        statement.bindLong(11, entity.getCicloAcertoAtual());
        statement.bindLong(12, entity.getAnoCiclo());
        if (entity.getDataInicioCiclo() == null) {
          statement.bindNull(13);
        } else {
          statement.bindLong(13, entity.getDataInicioCiclo());
        }
        if (entity.getDataFimCiclo() == null) {
          statement.bindNull(14);
        } else {
          statement.bindLong(14, entity.getDataFimCiclo());
        }
      }
    };
    this.__deletionAdapterOfRota = new EntityDeletionOrUpdateAdapter<Rota>(__db) {
      @Override
      @NonNull
      protected String createQuery() {
        return "DELETE FROM `rotas` WHERE `id` = ?";
      }

      @Override
      protected void bind(@NonNull final SupportSQLiteStatement statement,
          @NonNull final Rota entity) {
        statement.bindLong(1, entity.getId());
      }
    };
    this.__updateAdapterOfRota = new EntityDeletionOrUpdateAdapter<Rota>(__db) {
      @Override
      @NonNull
      protected String createQuery() {
        return "UPDATE OR ABORT `rotas` SET `id` = ?,`nome` = ?,`descricao` = ?,`colaborador_responsavel` = ?,`cidades` = ?,`ativa` = ?,`cor` = ?,`data_criacao` = ?,`data_atualizacao` = ?,`status_atual` = ?,`ciclo_acerto_atual` = ?,`ano_ciclo` = ?,`data_inicio_ciclo` = ?,`data_fim_ciclo` = ? WHERE `id` = ?";
      }

      @Override
      protected void bind(@NonNull final SupportSQLiteStatement statement,
          @NonNull final Rota entity) {
        statement.bindLong(1, entity.getId());
        if (entity.getNome() == null) {
          statement.bindNull(2);
        } else {
          statement.bindString(2, entity.getNome());
        }
        if (entity.getDescricao() == null) {
          statement.bindNull(3);
        } else {
          statement.bindString(3, entity.getDescricao());
        }
        if (entity.getColaboradorResponsavel() == null) {
          statement.bindNull(4);
        } else {
          statement.bindString(4, entity.getColaboradorResponsavel());
        }
        if (entity.getCidades() == null) {
          statement.bindNull(5);
        } else {
          statement.bindString(5, entity.getCidades());
        }
        final int _tmp = entity.getAtiva() ? 1 : 0;
        statement.bindLong(6, _tmp);
        if (entity.getCor() == null) {
          statement.bindNull(7);
        } else {
          statement.bindString(7, entity.getCor());
        }
        statement.bindLong(8, entity.getDataCriacao());
        statement.bindLong(9, entity.getDataAtualizacao());
        statement.bindString(10, __StatusRota_enumToString(entity.getStatusAtual()));
        statement.bindLong(11, entity.getCicloAcertoAtual());
        statement.bindLong(12, entity.getAnoCiclo());
        if (entity.getDataInicioCiclo() == null) {
          statement.bindNull(13);
        } else {
          statement.bindLong(13, entity.getDataInicioCiclo());
        }
        if (entity.getDataFimCiclo() == null) {
          statement.bindNull(14);
        } else {
          statement.bindLong(14, entity.getDataFimCiclo());
        }
        statement.bindLong(15, entity.getId());
      }
    };
    this.__preparedStmtOfDesativarRota = new SharedSQLiteStatement(__db) {
      @Override
      @NonNull
      public String createQuery() {
        final String _query = "UPDATE rotas SET ativa = 0, data_atualizacao = ? WHERE id = ?";
        return _query;
      }
    };
    this.__preparedStmtOfAtivarRota = new SharedSQLiteStatement(__db) {
      @Override
      @NonNull
      public String createQuery() {
        final String _query = "UPDATE rotas SET ativa = 1, data_atualizacao = ? WHERE id = ?";
        return _query;
      }
    };
    this.__preparedStmtOfAtualizarStatus = new SharedSQLiteStatement(__db) {
      @Override
      @NonNull
      public String createQuery() {
        final String _query = "UPDATE rotas SET status_atual = ?, data_atualizacao = ? WHERE id = ?";
        return _query;
      }
    };
    this.__preparedStmtOfAtualizarCicloAcerto = new SharedSQLiteStatement(__db) {
      @Override
      @NonNull
      public String createQuery() {
        final String _query = "UPDATE rotas SET ciclo_acerto_atual = ?, data_atualizacao = ? WHERE id = ?";
        return _query;
      }
    };
    this.__preparedStmtOfIniciarCicloRota = new SharedSQLiteStatement(__db) {
      @Override
      @NonNull
      public String createQuery() {
        final String _query = "UPDATE rotas SET status_atual = 'EM_ANDAMENTO', ciclo_acerto_atual = ?, data_inicio_ciclo = ?, data_atualizacao = ? WHERE id = ?";
        return _query;
      }
    };
    this.__preparedStmtOfFinalizarCicloRota = new SharedSQLiteStatement(__db) {
      @Override
      @NonNull
      public String createQuery() {
        final String _query = "UPDATE rotas SET status_atual = 'FINALIZADA', data_fim_ciclo = ?, data_atualizacao = ? WHERE id = ?";
        return _query;
      }
    };
  }

  @Override
  public Object insertRota(final Rota rota, final Continuation<? super Long> arg1) {
    return CoroutinesRoom.execute(__db, true, new Callable<Long>() {
      @Override
      @NonNull
      public Long call() throws Exception {
        __db.beginTransaction();
        try {
          final Long _result = __insertionAdapterOfRota.insertAndReturnId(rota);
          __db.setTransactionSuccessful();
          return _result;
        } finally {
          __db.endTransaction();
        }
      }
    }, arg1);
  }

  @Override
  public Object insertRotas(final List<Rota> rotas, final Continuation<? super List<Long>> arg1) {
    return CoroutinesRoom.execute(__db, true, new Callable<List<Long>>() {
      @Override
      @NonNull
      public List<Long> call() throws Exception {
        __db.beginTransaction();
        try {
          final List<Long> _result = __insertionAdapterOfRota.insertAndReturnIdsList(rotas);
          __db.setTransactionSuccessful();
          return _result;
        } finally {
          __db.endTransaction();
        }
      }
    }, arg1);
  }

  @Override
  public Object deleteRota(final Rota rota, final Continuation<? super Unit> arg1) {
    return CoroutinesRoom.execute(__db, true, new Callable<Unit>() {
      @Override
      @NonNull
      public Unit call() throws Exception {
        __db.beginTransaction();
        try {
          __deletionAdapterOfRota.handle(rota);
          __db.setTransactionSuccessful();
          return Unit.INSTANCE;
        } finally {
          __db.endTransaction();
        }
      }
    }, arg1);
  }

  @Override
  public Object updateRota(final Rota rota, final Continuation<? super Unit> arg1) {
    return CoroutinesRoom.execute(__db, true, new Callable<Unit>() {
      @Override
      @NonNull
      public Unit call() throws Exception {
        __db.beginTransaction();
        try {
          __updateAdapterOfRota.handle(rota);
          __db.setTransactionSuccessful();
          return Unit.INSTANCE;
        } finally {
          __db.endTransaction();
        }
      }
    }, arg1);
  }

  @Override
  public Object updateRotas(final List<Rota> rotas, final Continuation<? super Unit> arg1) {
    return CoroutinesRoom.execute(__db, true, new Callable<Unit>() {
      @Override
      @NonNull
      public Unit call() throws Exception {
        __db.beginTransaction();
        try {
          __updateAdapterOfRota.handleMultiple(rotas);
          __db.setTransactionSuccessful();
          return Unit.INSTANCE;
        } finally {
          __db.endTransaction();
        }
      }
    }, arg1);
  }

  @Override
  public Object desativarRota(final long rotaId, final long timestamp,
      final Continuation<? super Unit> arg2) {
    return CoroutinesRoom.execute(__db, true, new Callable<Unit>() {
      @Override
      @NonNull
      public Unit call() throws Exception {
        final SupportSQLiteStatement _stmt = __preparedStmtOfDesativarRota.acquire();
        int _argIndex = 1;
        _stmt.bindLong(_argIndex, timestamp);
        _argIndex = 2;
        _stmt.bindLong(_argIndex, rotaId);
        try {
          __db.beginTransaction();
          try {
            _stmt.executeUpdateDelete();
            __db.setTransactionSuccessful();
            return Unit.INSTANCE;
          } finally {
            __db.endTransaction();
          }
        } finally {
          __preparedStmtOfDesativarRota.release(_stmt);
        }
      }
    }, arg2);
  }

  @Override
  public Object ativarRota(final long rotaId, final long timestamp,
      final Continuation<? super Unit> arg2) {
    return CoroutinesRoom.execute(__db, true, new Callable<Unit>() {
      @Override
      @NonNull
      public Unit call() throws Exception {
        final SupportSQLiteStatement _stmt = __preparedStmtOfAtivarRota.acquire();
        int _argIndex = 1;
        _stmt.bindLong(_argIndex, timestamp);
        _argIndex = 2;
        _stmt.bindLong(_argIndex, rotaId);
        try {
          __db.beginTransaction();
          try {
            _stmt.executeUpdateDelete();
            __db.setTransactionSuccessful();
            return Unit.INSTANCE;
          } finally {
            __db.endTransaction();
          }
        } finally {
          __preparedStmtOfAtivarRota.release(_stmt);
        }
      }
    }, arg2);
  }

  @Override
  public Object atualizarStatus(final long rotaId, final String status, final long timestamp,
      final Continuation<? super Unit> arg3) {
    return CoroutinesRoom.execute(__db, true, new Callable<Unit>() {
      @Override
      @NonNull
      public Unit call() throws Exception {
        final SupportSQLiteStatement _stmt = __preparedStmtOfAtualizarStatus.acquire();
        int _argIndex = 1;
        if (status == null) {
          _stmt.bindNull(_argIndex);
        } else {
          _stmt.bindString(_argIndex, status);
        }
        _argIndex = 2;
        _stmt.bindLong(_argIndex, timestamp);
        _argIndex = 3;
        _stmt.bindLong(_argIndex, rotaId);
        try {
          __db.beginTransaction();
          try {
            _stmt.executeUpdateDelete();
            __db.setTransactionSuccessful();
            return Unit.INSTANCE;
          } finally {
            __db.endTransaction();
          }
        } finally {
          __preparedStmtOfAtualizarStatus.release(_stmt);
        }
      }
    }, arg3);
  }

  @Override
  public Object atualizarCicloAcerto(final long rotaId, final int ciclo, final long timestamp,
      final Continuation<? super Unit> arg3) {
    return CoroutinesRoom.execute(__db, true, new Callable<Unit>() {
      @Override
      @NonNull
      public Unit call() throws Exception {
        final SupportSQLiteStatement _stmt = __preparedStmtOfAtualizarCicloAcerto.acquire();
        int _argIndex = 1;
        _stmt.bindLong(_argIndex, ciclo);
        _argIndex = 2;
        _stmt.bindLong(_argIndex, timestamp);
        _argIndex = 3;
        _stmt.bindLong(_argIndex, rotaId);
        try {
          __db.beginTransaction();
          try {
            _stmt.executeUpdateDelete();
            __db.setTransactionSuccessful();
            return Unit.INSTANCE;
          } finally {
            __db.endTransaction();
          }
        } finally {
          __preparedStmtOfAtualizarCicloAcerto.release(_stmt);
        }
      }
    }, arg3);
  }

  @Override
  public Object iniciarCicloRota(final long rotaId, final int ciclo, final long dataInicio,
      final long timestamp, final Continuation<? super Unit> arg4) {
    return CoroutinesRoom.execute(__db, true, new Callable<Unit>() {
      @Override
      @NonNull
      public Unit call() throws Exception {
        final SupportSQLiteStatement _stmt = __preparedStmtOfIniciarCicloRota.acquire();
        int _argIndex = 1;
        _stmt.bindLong(_argIndex, ciclo);
        _argIndex = 2;
        _stmt.bindLong(_argIndex, dataInicio);
        _argIndex = 3;
        _stmt.bindLong(_argIndex, timestamp);
        _argIndex = 4;
        _stmt.bindLong(_argIndex, rotaId);
        try {
          __db.beginTransaction();
          try {
            _stmt.executeUpdateDelete();
            __db.setTransactionSuccessful();
            return Unit.INSTANCE;
          } finally {
            __db.endTransaction();
          }
        } finally {
          __preparedStmtOfIniciarCicloRota.release(_stmt);
        }
      }
    }, arg4);
  }

  @Override
  public Object finalizarCicloRota(final long rotaId, final long dataFim, final long timestamp,
      final Continuation<? super Unit> arg3) {
    return CoroutinesRoom.execute(__db, true, new Callable<Unit>() {
      @Override
      @NonNull
      public Unit call() throws Exception {
        final SupportSQLiteStatement _stmt = __preparedStmtOfFinalizarCicloRota.acquire();
        int _argIndex = 1;
        _stmt.bindLong(_argIndex, dataFim);
        _argIndex = 2;
        _stmt.bindLong(_argIndex, timestamp);
        _argIndex = 3;
        _stmt.bindLong(_argIndex, rotaId);
        try {
          __db.beginTransaction();
          try {
            _stmt.executeUpdateDelete();
            __db.setTransactionSuccessful();
            return Unit.INSTANCE;
          } finally {
            __db.endTransaction();
          }
        } finally {
          __preparedStmtOfFinalizarCicloRota.release(_stmt);
        }
      }
    }, arg3);
  }

  @Override
  public Flow<List<Rota>> getAllRotasAtivas() {
    final String _sql = "SELECT * FROM rotas WHERE ativa = 1 ORDER BY nome ASC";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 0);
    return CoroutinesRoom.createFlow(__db, false, new String[] {"rotas"}, new Callable<List<Rota>>() {
      @Override
      @NonNull
      public List<Rota> call() throws Exception {
        final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
        try {
          final int _cursorIndexOfId = CursorUtil.getColumnIndexOrThrow(_cursor, "id");
          final int _cursorIndexOfNome = CursorUtil.getColumnIndexOrThrow(_cursor, "nome");
          final int _cursorIndexOfDescricao = CursorUtil.getColumnIndexOrThrow(_cursor, "descricao");
          final int _cursorIndexOfColaboradorResponsavel = CursorUtil.getColumnIndexOrThrow(_cursor, "colaborador_responsavel");
          final int _cursorIndexOfCidades = CursorUtil.getColumnIndexOrThrow(_cursor, "cidades");
          final int _cursorIndexOfAtiva = CursorUtil.getColumnIndexOrThrow(_cursor, "ativa");
          final int _cursorIndexOfCor = CursorUtil.getColumnIndexOrThrow(_cursor, "cor");
          final int _cursorIndexOfDataCriacao = CursorUtil.getColumnIndexOrThrow(_cursor, "data_criacao");
          final int _cursorIndexOfDataAtualizacao = CursorUtil.getColumnIndexOrThrow(_cursor, "data_atualizacao");
          final int _cursorIndexOfStatusAtual = CursorUtil.getColumnIndexOrThrow(_cursor, "status_atual");
          final int _cursorIndexOfCicloAcertoAtual = CursorUtil.getColumnIndexOrThrow(_cursor, "ciclo_acerto_atual");
          final int _cursorIndexOfAnoCiclo = CursorUtil.getColumnIndexOrThrow(_cursor, "ano_ciclo");
          final int _cursorIndexOfDataInicioCiclo = CursorUtil.getColumnIndexOrThrow(_cursor, "data_inicio_ciclo");
          final int _cursorIndexOfDataFimCiclo = CursorUtil.getColumnIndexOrThrow(_cursor, "data_fim_ciclo");
          final List<Rota> _result = new ArrayList<Rota>(_cursor.getCount());
          while (_cursor.moveToNext()) {
            final Rota _item;
            final long _tmpId;
            _tmpId = _cursor.getLong(_cursorIndexOfId);
            final String _tmpNome;
            if (_cursor.isNull(_cursorIndexOfNome)) {
              _tmpNome = null;
            } else {
              _tmpNome = _cursor.getString(_cursorIndexOfNome);
            }
            final String _tmpDescricao;
            if (_cursor.isNull(_cursorIndexOfDescricao)) {
              _tmpDescricao = null;
            } else {
              _tmpDescricao = _cursor.getString(_cursorIndexOfDescricao);
            }
            final String _tmpColaboradorResponsavel;
            if (_cursor.isNull(_cursorIndexOfColaboradorResponsavel)) {
              _tmpColaboradorResponsavel = null;
            } else {
              _tmpColaboradorResponsavel = _cursor.getString(_cursorIndexOfColaboradorResponsavel);
            }
            final String _tmpCidades;
            if (_cursor.isNull(_cursorIndexOfCidades)) {
              _tmpCidades = null;
            } else {
              _tmpCidades = _cursor.getString(_cursorIndexOfCidades);
            }
            final boolean _tmpAtiva;
            final int _tmp;
            _tmp = _cursor.getInt(_cursorIndexOfAtiva);
            _tmpAtiva = _tmp != 0;
            final String _tmpCor;
            if (_cursor.isNull(_cursorIndexOfCor)) {
              _tmpCor = null;
            } else {
              _tmpCor = _cursor.getString(_cursorIndexOfCor);
            }
            final long _tmpDataCriacao;
            _tmpDataCriacao = _cursor.getLong(_cursorIndexOfDataCriacao);
            final long _tmpDataAtualizacao;
            _tmpDataAtualizacao = _cursor.getLong(_cursorIndexOfDataAtualizacao);
            final StatusRota _tmpStatusAtual;
            _tmpStatusAtual = __StatusRota_stringToEnum(_cursor.getString(_cursorIndexOfStatusAtual));
            final int _tmpCicloAcertoAtual;
            _tmpCicloAcertoAtual = _cursor.getInt(_cursorIndexOfCicloAcertoAtual);
            final int _tmpAnoCiclo;
            _tmpAnoCiclo = _cursor.getInt(_cursorIndexOfAnoCiclo);
            final Long _tmpDataInicioCiclo;
            if (_cursor.isNull(_cursorIndexOfDataInicioCiclo)) {
              _tmpDataInicioCiclo = null;
            } else {
              _tmpDataInicioCiclo = _cursor.getLong(_cursorIndexOfDataInicioCiclo);
            }
            final Long _tmpDataFimCiclo;
            if (_cursor.isNull(_cursorIndexOfDataFimCiclo)) {
              _tmpDataFimCiclo = null;
            } else {
              _tmpDataFimCiclo = _cursor.getLong(_cursorIndexOfDataFimCiclo);
            }
            _item = new Rota(_tmpId,_tmpNome,_tmpDescricao,_tmpColaboradorResponsavel,_tmpCidades,_tmpAtiva,_tmpCor,_tmpDataCriacao,_tmpDataAtualizacao,_tmpStatusAtual,_tmpCicloAcertoAtual,_tmpAnoCiclo,_tmpDataInicioCiclo,_tmpDataFimCiclo);
            _result.add(_item);
          }
          return _result;
        } finally {
          _cursor.close();
        }
      }

      @Override
      protected void finalize() {
        _statement.release();
      }
    });
  }

  @Override
  public Flow<List<Rota>> getAllRotas() {
    final String _sql = "SELECT * FROM rotas ORDER BY nome ASC";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 0);
    return CoroutinesRoom.createFlow(__db, false, new String[] {"rotas"}, new Callable<List<Rota>>() {
      @Override
      @NonNull
      public List<Rota> call() throws Exception {
        final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
        try {
          final int _cursorIndexOfId = CursorUtil.getColumnIndexOrThrow(_cursor, "id");
          final int _cursorIndexOfNome = CursorUtil.getColumnIndexOrThrow(_cursor, "nome");
          final int _cursorIndexOfDescricao = CursorUtil.getColumnIndexOrThrow(_cursor, "descricao");
          final int _cursorIndexOfColaboradorResponsavel = CursorUtil.getColumnIndexOrThrow(_cursor, "colaborador_responsavel");
          final int _cursorIndexOfCidades = CursorUtil.getColumnIndexOrThrow(_cursor, "cidades");
          final int _cursorIndexOfAtiva = CursorUtil.getColumnIndexOrThrow(_cursor, "ativa");
          final int _cursorIndexOfCor = CursorUtil.getColumnIndexOrThrow(_cursor, "cor");
          final int _cursorIndexOfDataCriacao = CursorUtil.getColumnIndexOrThrow(_cursor, "data_criacao");
          final int _cursorIndexOfDataAtualizacao = CursorUtil.getColumnIndexOrThrow(_cursor, "data_atualizacao");
          final int _cursorIndexOfStatusAtual = CursorUtil.getColumnIndexOrThrow(_cursor, "status_atual");
          final int _cursorIndexOfCicloAcertoAtual = CursorUtil.getColumnIndexOrThrow(_cursor, "ciclo_acerto_atual");
          final int _cursorIndexOfAnoCiclo = CursorUtil.getColumnIndexOrThrow(_cursor, "ano_ciclo");
          final int _cursorIndexOfDataInicioCiclo = CursorUtil.getColumnIndexOrThrow(_cursor, "data_inicio_ciclo");
          final int _cursorIndexOfDataFimCiclo = CursorUtil.getColumnIndexOrThrow(_cursor, "data_fim_ciclo");
          final List<Rota> _result = new ArrayList<Rota>(_cursor.getCount());
          while (_cursor.moveToNext()) {
            final Rota _item;
            final long _tmpId;
            _tmpId = _cursor.getLong(_cursorIndexOfId);
            final String _tmpNome;
            if (_cursor.isNull(_cursorIndexOfNome)) {
              _tmpNome = null;
            } else {
              _tmpNome = _cursor.getString(_cursorIndexOfNome);
            }
            final String _tmpDescricao;
            if (_cursor.isNull(_cursorIndexOfDescricao)) {
              _tmpDescricao = null;
            } else {
              _tmpDescricao = _cursor.getString(_cursorIndexOfDescricao);
            }
            final String _tmpColaboradorResponsavel;
            if (_cursor.isNull(_cursorIndexOfColaboradorResponsavel)) {
              _tmpColaboradorResponsavel = null;
            } else {
              _tmpColaboradorResponsavel = _cursor.getString(_cursorIndexOfColaboradorResponsavel);
            }
            final String _tmpCidades;
            if (_cursor.isNull(_cursorIndexOfCidades)) {
              _tmpCidades = null;
            } else {
              _tmpCidades = _cursor.getString(_cursorIndexOfCidades);
            }
            final boolean _tmpAtiva;
            final int _tmp;
            _tmp = _cursor.getInt(_cursorIndexOfAtiva);
            _tmpAtiva = _tmp != 0;
            final String _tmpCor;
            if (_cursor.isNull(_cursorIndexOfCor)) {
              _tmpCor = null;
            } else {
              _tmpCor = _cursor.getString(_cursorIndexOfCor);
            }
            final long _tmpDataCriacao;
            _tmpDataCriacao = _cursor.getLong(_cursorIndexOfDataCriacao);
            final long _tmpDataAtualizacao;
            _tmpDataAtualizacao = _cursor.getLong(_cursorIndexOfDataAtualizacao);
            final StatusRota _tmpStatusAtual;
            _tmpStatusAtual = __StatusRota_stringToEnum(_cursor.getString(_cursorIndexOfStatusAtual));
            final int _tmpCicloAcertoAtual;
            _tmpCicloAcertoAtual = _cursor.getInt(_cursorIndexOfCicloAcertoAtual);
            final int _tmpAnoCiclo;
            _tmpAnoCiclo = _cursor.getInt(_cursorIndexOfAnoCiclo);
            final Long _tmpDataInicioCiclo;
            if (_cursor.isNull(_cursorIndexOfDataInicioCiclo)) {
              _tmpDataInicioCiclo = null;
            } else {
              _tmpDataInicioCiclo = _cursor.getLong(_cursorIndexOfDataInicioCiclo);
            }
            final Long _tmpDataFimCiclo;
            if (_cursor.isNull(_cursorIndexOfDataFimCiclo)) {
              _tmpDataFimCiclo = null;
            } else {
              _tmpDataFimCiclo = _cursor.getLong(_cursorIndexOfDataFimCiclo);
            }
            _item = new Rota(_tmpId,_tmpNome,_tmpDescricao,_tmpColaboradorResponsavel,_tmpCidades,_tmpAtiva,_tmpCor,_tmpDataCriacao,_tmpDataAtualizacao,_tmpStatusAtual,_tmpCicloAcertoAtual,_tmpAnoCiclo,_tmpDataInicioCiclo,_tmpDataFimCiclo);
            _result.add(_item);
          }
          return _result;
        } finally {
          _cursor.close();
        }
      }

      @Override
      protected void finalize() {
        _statement.release();
      }
    });
  }

  @Override
  public Object getRotaById(final long rotaId, final Continuation<? super Rota> arg1) {
    final String _sql = "SELECT * FROM rotas WHERE id = ?";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 1);
    int _argIndex = 1;
    _statement.bindLong(_argIndex, rotaId);
    final CancellationSignal _cancellationSignal = DBUtil.createCancellationSignal();
    return CoroutinesRoom.execute(__db, false, _cancellationSignal, new Callable<Rota>() {
      @Override
      @Nullable
      public Rota call() throws Exception {
        final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
        try {
          final int _cursorIndexOfId = CursorUtil.getColumnIndexOrThrow(_cursor, "id");
          final int _cursorIndexOfNome = CursorUtil.getColumnIndexOrThrow(_cursor, "nome");
          final int _cursorIndexOfDescricao = CursorUtil.getColumnIndexOrThrow(_cursor, "descricao");
          final int _cursorIndexOfColaboradorResponsavel = CursorUtil.getColumnIndexOrThrow(_cursor, "colaborador_responsavel");
          final int _cursorIndexOfCidades = CursorUtil.getColumnIndexOrThrow(_cursor, "cidades");
          final int _cursorIndexOfAtiva = CursorUtil.getColumnIndexOrThrow(_cursor, "ativa");
          final int _cursorIndexOfCor = CursorUtil.getColumnIndexOrThrow(_cursor, "cor");
          final int _cursorIndexOfDataCriacao = CursorUtil.getColumnIndexOrThrow(_cursor, "data_criacao");
          final int _cursorIndexOfDataAtualizacao = CursorUtil.getColumnIndexOrThrow(_cursor, "data_atualizacao");
          final int _cursorIndexOfStatusAtual = CursorUtil.getColumnIndexOrThrow(_cursor, "status_atual");
          final int _cursorIndexOfCicloAcertoAtual = CursorUtil.getColumnIndexOrThrow(_cursor, "ciclo_acerto_atual");
          final int _cursorIndexOfAnoCiclo = CursorUtil.getColumnIndexOrThrow(_cursor, "ano_ciclo");
          final int _cursorIndexOfDataInicioCiclo = CursorUtil.getColumnIndexOrThrow(_cursor, "data_inicio_ciclo");
          final int _cursorIndexOfDataFimCiclo = CursorUtil.getColumnIndexOrThrow(_cursor, "data_fim_ciclo");
          final Rota _result;
          if (_cursor.moveToFirst()) {
            final long _tmpId;
            _tmpId = _cursor.getLong(_cursorIndexOfId);
            final String _tmpNome;
            if (_cursor.isNull(_cursorIndexOfNome)) {
              _tmpNome = null;
            } else {
              _tmpNome = _cursor.getString(_cursorIndexOfNome);
            }
            final String _tmpDescricao;
            if (_cursor.isNull(_cursorIndexOfDescricao)) {
              _tmpDescricao = null;
            } else {
              _tmpDescricao = _cursor.getString(_cursorIndexOfDescricao);
            }
            final String _tmpColaboradorResponsavel;
            if (_cursor.isNull(_cursorIndexOfColaboradorResponsavel)) {
              _tmpColaboradorResponsavel = null;
            } else {
              _tmpColaboradorResponsavel = _cursor.getString(_cursorIndexOfColaboradorResponsavel);
            }
            final String _tmpCidades;
            if (_cursor.isNull(_cursorIndexOfCidades)) {
              _tmpCidades = null;
            } else {
              _tmpCidades = _cursor.getString(_cursorIndexOfCidades);
            }
            final boolean _tmpAtiva;
            final int _tmp;
            _tmp = _cursor.getInt(_cursorIndexOfAtiva);
            _tmpAtiva = _tmp != 0;
            final String _tmpCor;
            if (_cursor.isNull(_cursorIndexOfCor)) {
              _tmpCor = null;
            } else {
              _tmpCor = _cursor.getString(_cursorIndexOfCor);
            }
            final long _tmpDataCriacao;
            _tmpDataCriacao = _cursor.getLong(_cursorIndexOfDataCriacao);
            final long _tmpDataAtualizacao;
            _tmpDataAtualizacao = _cursor.getLong(_cursorIndexOfDataAtualizacao);
            final StatusRota _tmpStatusAtual;
            _tmpStatusAtual = __StatusRota_stringToEnum(_cursor.getString(_cursorIndexOfStatusAtual));
            final int _tmpCicloAcertoAtual;
            _tmpCicloAcertoAtual = _cursor.getInt(_cursorIndexOfCicloAcertoAtual);
            final int _tmpAnoCiclo;
            _tmpAnoCiclo = _cursor.getInt(_cursorIndexOfAnoCiclo);
            final Long _tmpDataInicioCiclo;
            if (_cursor.isNull(_cursorIndexOfDataInicioCiclo)) {
              _tmpDataInicioCiclo = null;
            } else {
              _tmpDataInicioCiclo = _cursor.getLong(_cursorIndexOfDataInicioCiclo);
            }
            final Long _tmpDataFimCiclo;
            if (_cursor.isNull(_cursorIndexOfDataFimCiclo)) {
              _tmpDataFimCiclo = null;
            } else {
              _tmpDataFimCiclo = _cursor.getLong(_cursorIndexOfDataFimCiclo);
            }
            _result = new Rota(_tmpId,_tmpNome,_tmpDescricao,_tmpColaboradorResponsavel,_tmpCidades,_tmpAtiva,_tmpCor,_tmpDataCriacao,_tmpDataAtualizacao,_tmpStatusAtual,_tmpCicloAcertoAtual,_tmpAnoCiclo,_tmpDataInicioCiclo,_tmpDataFimCiclo);
          } else {
            _result = null;
          }
          return _result;
        } finally {
          _cursor.close();
          _statement.release();
        }
      }
    }, arg1);
  }

  @Override
  public Flow<Rota> obterRotaPorId(final long rotaId) {
    final String _sql = "SELECT * FROM rotas WHERE id = ?";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 1);
    int _argIndex = 1;
    _statement.bindLong(_argIndex, rotaId);
    return CoroutinesRoom.createFlow(__db, false, new String[] {"rotas"}, new Callable<Rota>() {
      @Override
      @Nullable
      public Rota call() throws Exception {
        final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
        try {
          final int _cursorIndexOfId = CursorUtil.getColumnIndexOrThrow(_cursor, "id");
          final int _cursorIndexOfNome = CursorUtil.getColumnIndexOrThrow(_cursor, "nome");
          final int _cursorIndexOfDescricao = CursorUtil.getColumnIndexOrThrow(_cursor, "descricao");
          final int _cursorIndexOfColaboradorResponsavel = CursorUtil.getColumnIndexOrThrow(_cursor, "colaborador_responsavel");
          final int _cursorIndexOfCidades = CursorUtil.getColumnIndexOrThrow(_cursor, "cidades");
          final int _cursorIndexOfAtiva = CursorUtil.getColumnIndexOrThrow(_cursor, "ativa");
          final int _cursorIndexOfCor = CursorUtil.getColumnIndexOrThrow(_cursor, "cor");
          final int _cursorIndexOfDataCriacao = CursorUtil.getColumnIndexOrThrow(_cursor, "data_criacao");
          final int _cursorIndexOfDataAtualizacao = CursorUtil.getColumnIndexOrThrow(_cursor, "data_atualizacao");
          final int _cursorIndexOfStatusAtual = CursorUtil.getColumnIndexOrThrow(_cursor, "status_atual");
          final int _cursorIndexOfCicloAcertoAtual = CursorUtil.getColumnIndexOrThrow(_cursor, "ciclo_acerto_atual");
          final int _cursorIndexOfAnoCiclo = CursorUtil.getColumnIndexOrThrow(_cursor, "ano_ciclo");
          final int _cursorIndexOfDataInicioCiclo = CursorUtil.getColumnIndexOrThrow(_cursor, "data_inicio_ciclo");
          final int _cursorIndexOfDataFimCiclo = CursorUtil.getColumnIndexOrThrow(_cursor, "data_fim_ciclo");
          final Rota _result;
          if (_cursor.moveToFirst()) {
            final long _tmpId;
            _tmpId = _cursor.getLong(_cursorIndexOfId);
            final String _tmpNome;
            if (_cursor.isNull(_cursorIndexOfNome)) {
              _tmpNome = null;
            } else {
              _tmpNome = _cursor.getString(_cursorIndexOfNome);
            }
            final String _tmpDescricao;
            if (_cursor.isNull(_cursorIndexOfDescricao)) {
              _tmpDescricao = null;
            } else {
              _tmpDescricao = _cursor.getString(_cursorIndexOfDescricao);
            }
            final String _tmpColaboradorResponsavel;
            if (_cursor.isNull(_cursorIndexOfColaboradorResponsavel)) {
              _tmpColaboradorResponsavel = null;
            } else {
              _tmpColaboradorResponsavel = _cursor.getString(_cursorIndexOfColaboradorResponsavel);
            }
            final String _tmpCidades;
            if (_cursor.isNull(_cursorIndexOfCidades)) {
              _tmpCidades = null;
            } else {
              _tmpCidades = _cursor.getString(_cursorIndexOfCidades);
            }
            final boolean _tmpAtiva;
            final int _tmp;
            _tmp = _cursor.getInt(_cursorIndexOfAtiva);
            _tmpAtiva = _tmp != 0;
            final String _tmpCor;
            if (_cursor.isNull(_cursorIndexOfCor)) {
              _tmpCor = null;
            } else {
              _tmpCor = _cursor.getString(_cursorIndexOfCor);
            }
            final long _tmpDataCriacao;
            _tmpDataCriacao = _cursor.getLong(_cursorIndexOfDataCriacao);
            final long _tmpDataAtualizacao;
            _tmpDataAtualizacao = _cursor.getLong(_cursorIndexOfDataAtualizacao);
            final StatusRota _tmpStatusAtual;
            _tmpStatusAtual = __StatusRota_stringToEnum(_cursor.getString(_cursorIndexOfStatusAtual));
            final int _tmpCicloAcertoAtual;
            _tmpCicloAcertoAtual = _cursor.getInt(_cursorIndexOfCicloAcertoAtual);
            final int _tmpAnoCiclo;
            _tmpAnoCiclo = _cursor.getInt(_cursorIndexOfAnoCiclo);
            final Long _tmpDataInicioCiclo;
            if (_cursor.isNull(_cursorIndexOfDataInicioCiclo)) {
              _tmpDataInicioCiclo = null;
            } else {
              _tmpDataInicioCiclo = _cursor.getLong(_cursorIndexOfDataInicioCiclo);
            }
            final Long _tmpDataFimCiclo;
            if (_cursor.isNull(_cursorIndexOfDataFimCiclo)) {
              _tmpDataFimCiclo = null;
            } else {
              _tmpDataFimCiclo = _cursor.getLong(_cursorIndexOfDataFimCiclo);
            }
            _result = new Rota(_tmpId,_tmpNome,_tmpDescricao,_tmpColaboradorResponsavel,_tmpCidades,_tmpAtiva,_tmpCor,_tmpDataCriacao,_tmpDataAtualizacao,_tmpStatusAtual,_tmpCicloAcertoAtual,_tmpAnoCiclo,_tmpDataInicioCiclo,_tmpDataFimCiclo);
          } else {
            _result = null;
          }
          return _result;
        } finally {
          _cursor.close();
        }
      }

      @Override
      protected void finalize() {
        _statement.release();
      }
    });
  }

  @Override
  public Object getRotaByNome(final String nome, final Continuation<? super Rota> arg1) {
    final String _sql = "SELECT * FROM rotas WHERE nome = ? LIMIT 1";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 1);
    int _argIndex = 1;
    if (nome == null) {
      _statement.bindNull(_argIndex);
    } else {
      _statement.bindString(_argIndex, nome);
    }
    final CancellationSignal _cancellationSignal = DBUtil.createCancellationSignal();
    return CoroutinesRoom.execute(__db, false, _cancellationSignal, new Callable<Rota>() {
      @Override
      @Nullable
      public Rota call() throws Exception {
        final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
        try {
          final int _cursorIndexOfId = CursorUtil.getColumnIndexOrThrow(_cursor, "id");
          final int _cursorIndexOfNome = CursorUtil.getColumnIndexOrThrow(_cursor, "nome");
          final int _cursorIndexOfDescricao = CursorUtil.getColumnIndexOrThrow(_cursor, "descricao");
          final int _cursorIndexOfColaboradorResponsavel = CursorUtil.getColumnIndexOrThrow(_cursor, "colaborador_responsavel");
          final int _cursorIndexOfCidades = CursorUtil.getColumnIndexOrThrow(_cursor, "cidades");
          final int _cursorIndexOfAtiva = CursorUtil.getColumnIndexOrThrow(_cursor, "ativa");
          final int _cursorIndexOfCor = CursorUtil.getColumnIndexOrThrow(_cursor, "cor");
          final int _cursorIndexOfDataCriacao = CursorUtil.getColumnIndexOrThrow(_cursor, "data_criacao");
          final int _cursorIndexOfDataAtualizacao = CursorUtil.getColumnIndexOrThrow(_cursor, "data_atualizacao");
          final int _cursorIndexOfStatusAtual = CursorUtil.getColumnIndexOrThrow(_cursor, "status_atual");
          final int _cursorIndexOfCicloAcertoAtual = CursorUtil.getColumnIndexOrThrow(_cursor, "ciclo_acerto_atual");
          final int _cursorIndexOfAnoCiclo = CursorUtil.getColumnIndexOrThrow(_cursor, "ano_ciclo");
          final int _cursorIndexOfDataInicioCiclo = CursorUtil.getColumnIndexOrThrow(_cursor, "data_inicio_ciclo");
          final int _cursorIndexOfDataFimCiclo = CursorUtil.getColumnIndexOrThrow(_cursor, "data_fim_ciclo");
          final Rota _result;
          if (_cursor.moveToFirst()) {
            final long _tmpId;
            _tmpId = _cursor.getLong(_cursorIndexOfId);
            final String _tmpNome;
            if (_cursor.isNull(_cursorIndexOfNome)) {
              _tmpNome = null;
            } else {
              _tmpNome = _cursor.getString(_cursorIndexOfNome);
            }
            final String _tmpDescricao;
            if (_cursor.isNull(_cursorIndexOfDescricao)) {
              _tmpDescricao = null;
            } else {
              _tmpDescricao = _cursor.getString(_cursorIndexOfDescricao);
            }
            final String _tmpColaboradorResponsavel;
            if (_cursor.isNull(_cursorIndexOfColaboradorResponsavel)) {
              _tmpColaboradorResponsavel = null;
            } else {
              _tmpColaboradorResponsavel = _cursor.getString(_cursorIndexOfColaboradorResponsavel);
            }
            final String _tmpCidades;
            if (_cursor.isNull(_cursorIndexOfCidades)) {
              _tmpCidades = null;
            } else {
              _tmpCidades = _cursor.getString(_cursorIndexOfCidades);
            }
            final boolean _tmpAtiva;
            final int _tmp;
            _tmp = _cursor.getInt(_cursorIndexOfAtiva);
            _tmpAtiva = _tmp != 0;
            final String _tmpCor;
            if (_cursor.isNull(_cursorIndexOfCor)) {
              _tmpCor = null;
            } else {
              _tmpCor = _cursor.getString(_cursorIndexOfCor);
            }
            final long _tmpDataCriacao;
            _tmpDataCriacao = _cursor.getLong(_cursorIndexOfDataCriacao);
            final long _tmpDataAtualizacao;
            _tmpDataAtualizacao = _cursor.getLong(_cursorIndexOfDataAtualizacao);
            final StatusRota _tmpStatusAtual;
            _tmpStatusAtual = __StatusRota_stringToEnum(_cursor.getString(_cursorIndexOfStatusAtual));
            final int _tmpCicloAcertoAtual;
            _tmpCicloAcertoAtual = _cursor.getInt(_cursorIndexOfCicloAcertoAtual);
            final int _tmpAnoCiclo;
            _tmpAnoCiclo = _cursor.getInt(_cursorIndexOfAnoCiclo);
            final Long _tmpDataInicioCiclo;
            if (_cursor.isNull(_cursorIndexOfDataInicioCiclo)) {
              _tmpDataInicioCiclo = null;
            } else {
              _tmpDataInicioCiclo = _cursor.getLong(_cursorIndexOfDataInicioCiclo);
            }
            final Long _tmpDataFimCiclo;
            if (_cursor.isNull(_cursorIndexOfDataFimCiclo)) {
              _tmpDataFimCiclo = null;
            } else {
              _tmpDataFimCiclo = _cursor.getLong(_cursorIndexOfDataFimCiclo);
            }
            _result = new Rota(_tmpId,_tmpNome,_tmpDescricao,_tmpColaboradorResponsavel,_tmpCidades,_tmpAtiva,_tmpCor,_tmpDataCriacao,_tmpDataAtualizacao,_tmpStatusAtual,_tmpCicloAcertoAtual,_tmpAnoCiclo,_tmpDataInicioCiclo,_tmpDataFimCiclo);
          } else {
            _result = null;
          }
          return _result;
        } finally {
          _cursor.close();
          _statement.release();
        }
      }
    }, arg1);
  }

  @Override
  public Object existeRotaComNome(final String nome, final long excludeId,
      final Continuation<? super Integer> arg2) {
    final String _sql = "SELECT COUNT(*) FROM rotas WHERE nome = ? AND id != ?";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 2);
    int _argIndex = 1;
    if (nome == null) {
      _statement.bindNull(_argIndex);
    } else {
      _statement.bindString(_argIndex, nome);
    }
    _argIndex = 2;
    _statement.bindLong(_argIndex, excludeId);
    final CancellationSignal _cancellationSignal = DBUtil.createCancellationSignal();
    return CoroutinesRoom.execute(__db, false, _cancellationSignal, new Callable<Integer>() {
      @Override
      @NonNull
      public Integer call() throws Exception {
        final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
        try {
          final Integer _result;
          if (_cursor.moveToFirst()) {
            final Integer _tmp;
            if (_cursor.isNull(0)) {
              _tmp = null;
            } else {
              _tmp = _cursor.getInt(0);
            }
            _result = _tmp;
          } else {
            _result = null;
          }
          return _result;
        } finally {
          _cursor.close();
          _statement.release();
        }
      }
    }, arg2);
  }

  @Override
  public Object contarRotasAtivas(final Continuation<? super Integer> arg0) {
    final String _sql = "SELECT COUNT(*) FROM rotas WHERE ativa = 1";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 0);
    final CancellationSignal _cancellationSignal = DBUtil.createCancellationSignal();
    return CoroutinesRoom.execute(__db, false, _cancellationSignal, new Callable<Integer>() {
      @Override
      @NonNull
      public Integer call() throws Exception {
        final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
        try {
          final Integer _result;
          if (_cursor.moveToFirst()) {
            final Integer _tmp;
            if (_cursor.isNull(0)) {
              _tmp = null;
            } else {
              _tmp = _cursor.getInt(0);
            }
            _result = _tmp;
          } else {
            _result = null;
          }
          return _result;
        } finally {
          _cursor.close();
          _statement.release();
        }
      }
    }, arg0);
  }

  @NonNull
  public static List<Class<?>> getRequiredConverters() {
    return Collections.emptyList();
  }

  private String __StatusRota_enumToString(@NonNull final StatusRota _value) {
    switch (_value) {
      case EM_ANDAMENTO: return "EM_ANDAMENTO";
      case PAUSADA: return "PAUSADA";
      case FINALIZADA: return "FINALIZADA";
      case CONCLUIDA: return "CONCLUIDA";
      default: throw new IllegalArgumentException("Can't convert enum to string, unknown enum value: " + _value);
    }
  }

  private StatusRota __StatusRota_stringToEnum(@NonNull final String _value) {
    switch (_value) {
      case "EM_ANDAMENTO": return StatusRota.EM_ANDAMENTO;
      case "PAUSADA": return StatusRota.PAUSADA;
      case "FINALIZADA": return StatusRota.FINALIZADA;
      case "CONCLUIDA": return StatusRota.CONCLUIDA;
      default: throw new IllegalArgumentException("Can't convert value to enum, unknown value: " + _value);
    }
  }
}
