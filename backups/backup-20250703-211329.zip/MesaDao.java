package com.example.gestaobilhares.data.dao;

/**
 * DAO para operações de mesa no banco de dados
 * Inclui métodos para vincular/desvincular mesas a clientes
 */
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000:\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\t\n\u0000\n\u0002\u0010\b\n\u0002\b\f\n\u0002\u0018\u0002\n\u0002\u0010 \n\u0002\b\b\n\u0002\u0010\u0006\n\u0002\b\u0002\bg\u0018\u00002\u00020\u0001J\u0016\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0005H\u00a7@\u00a2\u0006\u0002\u0010\u0006J\u001e\u0010\u0007\u001a\u00020\u00032\u0006\u0010\b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u000bH\u00a7@\u00a2\u0006\u0002\u0010\fJ6\u0010\r\u001a\u00020\u00032\u0006\u0010\b\u001a\u00020\t2\u0006\u0010\u000e\u001a\u00020\u000b2\u0006\u0010\n\u001a\u00020\u000b2\u0006\u0010\u000f\u001a\u00020\u000b2\u0006\u0010\u0010\u001a\u00020\u000bH\u00a7@\u00a2\u0006\u0002\u0010\u0011J\u0016\u0010\u0012\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0005H\u00a7@\u00a2\u0006\u0002\u0010\u0006J\u0016\u0010\u0013\u001a\u00020\u00032\u0006\u0010\b\u001a\u00020\tH\u00a7@\u00a2\u0006\u0002\u0010\u0014J\u0016\u0010\u0015\u001a\u00020\t2\u0006\u0010\u0004\u001a\u00020\u0005H\u00a7@\u00a2\u0006\u0002\u0010\u0006J\u0018\u0010\u0016\u001a\u0004\u0018\u00010\u00052\u0006\u0010\b\u001a\u00020\tH\u00a7@\u00a2\u0006\u0002\u0010\u0014J\u0014\u0010\u0017\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00050\u00190\u0018H\'J\u001c\u0010\u001a\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00050\u00190\u00182\u0006\u0010\u001b\u001a\u00020\tH\'J\u001c\u0010\u001c\u001a\b\u0012\u0004\u0012\u00020\u00050\u00192\u0006\u0010\u001b\u001a\u00020\tH\u00a7@\u00a2\u0006\u0002\u0010\u0014J\u0016\u0010\u001d\u001a\u00020\u00032\u0006\u0010\b\u001a\u00020\tH\u00a7@\u00a2\u0006\u0002\u0010\u0014J\u001e\u0010\u001e\u001a\u00020\u00032\u0006\u0010\b\u001a\u00020\t2\u0006\u0010\u001b\u001a\u00020\tH\u00a7@\u00a2\u0006\u0002\u0010\u001fJ&\u0010 \u001a\u00020\u00032\u0006\u0010\b\u001a\u00020\t2\u0006\u0010\u001b\u001a\u00020\t2\u0006\u0010!\u001a\u00020\"H\u00a7@\u00a2\u0006\u0002\u0010#\u00a8\u0006$"}, d2 = {"Lcom/example/gestaobilhares/data/dao/MesaDao;", "", "atualizar", "", "mesa", "Lcom/example/gestaobilhares/data/entities/Mesa;", "(Lcom/example/gestaobilhares/data/entities/Mesa;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "atualizarRelogioFinal", "mesaId", "", "relogioFinal", "", "(JILkotlin/coroutines/Continuation;)Ljava/lang/Object;", "atualizarRelogioMesa", "relogioInicial", "fichasInicial", "fichasFinal", "(JIIIILkotlin/coroutines/Continuation;)Ljava/lang/Object;", "deletar", "desvincularMesa", "(JLkotlin/coroutines/Continuation;)Ljava/lang/Object;", "inserir", "obterMesaPorId", "obterMesasDisponiveis", "Lkotlinx/coroutines/flow/Flow;", "", "obterMesasPorCliente", "clienteId", "obterMesasPorClienteDireto", "retirarMesa", "vincularMesa", "(JJLkotlin/coroutines/Continuation;)Ljava/lang/Object;", "vincularMesaComValorFixo", "valorFixo", "", "(JJDLkotlin/coroutines/Continuation;)Ljava/lang/Object;", "app_debug"})
@androidx.room.Dao()
public abstract interface MesaDao {
    
    @androidx.room.Insert(onConflict = 1)
    @org.jetbrains.annotations.Nullable()
    public abstract java.lang.Object inserir(@org.jetbrains.annotations.NotNull()
    com.example.gestaobilhares.data.entities.Mesa mesa, @org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super java.lang.Long> $completion);
    
    @androidx.room.Update()
    @org.jetbrains.annotations.Nullable()
    public abstract java.lang.Object atualizar(@org.jetbrains.annotations.NotNull()
    com.example.gestaobilhares.data.entities.Mesa mesa, @org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super kotlin.Unit> $completion);
    
    @androidx.room.Delete()
    @org.jetbrains.annotations.Nullable()
    public abstract java.lang.Object deletar(@org.jetbrains.annotations.NotNull()
    com.example.gestaobilhares.data.entities.Mesa mesa, @org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super kotlin.Unit> $completion);
    
    @androidx.room.Query(value = "SELECT * FROM mesas WHERE cliente_id = :clienteId AND ativa = 1 ORDER BY numero ASC")
    @org.jetbrains.annotations.NotNull()
    public abstract kotlinx.coroutines.flow.Flow<java.util.List<com.example.gestaobilhares.data.entities.Mesa>> obterMesasPorCliente(long clienteId);
    
    @androidx.room.Query(value = "\n        SELECT * FROM mesas \n        WHERE (ativa = 1 AND cliente_id IS NULL) \n        ORDER BY numero ASC\n    ")
    @org.jetbrains.annotations.NotNull()
    public abstract kotlinx.coroutines.flow.Flow<java.util.List<com.example.gestaobilhares.data.entities.Mesa>> obterMesasDisponiveis();
    
    @androidx.room.Query(value = "UPDATE mesas SET cliente_id = NULL, ativa = 1 WHERE id = :mesaId")
    @org.jetbrains.annotations.Nullable()
    public abstract java.lang.Object desvincularMesa(long mesaId, @org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super kotlin.Unit> $completion);
    
    @androidx.room.Query(value = "UPDATE mesas SET cliente_id = :clienteId, ativa = 1 WHERE id = :mesaId")
    @org.jetbrains.annotations.Nullable()
    public abstract java.lang.Object vincularMesa(long mesaId, long clienteId, @org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super kotlin.Unit> $completion);
    
    @androidx.room.Query(value = "UPDATE mesas SET cliente_id = :clienteId, ativa = 1, valor_fixo = :valorFixo WHERE id = :mesaId")
    @org.jetbrains.annotations.Nullable()
    public abstract java.lang.Object vincularMesaComValorFixo(long mesaId, long clienteId, double valorFixo, @org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super kotlin.Unit> $completion);
    
    @androidx.room.Query(value = "\n        UPDATE mesas \n        SET cliente_id = NULL, \n            ativa = 1,\n            relogio_inicial = relogio_final,\n            fichas_inicial = fichas_final\n        WHERE id = :mesaId\n    ")
    @org.jetbrains.annotations.Nullable()
    public abstract java.lang.Object retirarMesa(long mesaId, @org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super kotlin.Unit> $completion);
    
    @androidx.room.Query(value = "\n        UPDATE mesas \n        SET relogio_inicial = :relogioInicial,\n            relogio_final = :relogioFinal,\n            fichas_inicial = :fichasInicial,\n            fichas_final = :fichasFinal\n        WHERE id = :mesaId\n    ")
    @org.jetbrains.annotations.Nullable()
    public abstract java.lang.Object atualizarRelogioMesa(long mesaId, int relogioInicial, int relogioFinal, int fichasInicial, int fichasFinal, @org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super kotlin.Unit> $completion);
    
    @androidx.room.Query(value = "UPDATE mesas SET relogio_final = :relogioFinal WHERE id = :mesaId")
    @org.jetbrains.annotations.Nullable()
    public abstract java.lang.Object atualizarRelogioFinal(long mesaId, int relogioFinal, @org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super kotlin.Unit> $completion);
    
    @androidx.room.Query(value = "SELECT * FROM mesas WHERE id = :mesaId")
    @org.jetbrains.annotations.Nullable()
    public abstract java.lang.Object obterMesaPorId(long mesaId, @org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super com.example.gestaobilhares.data.entities.Mesa> $completion);
    
    @androidx.room.Query(value = "SELECT * FROM mesas WHERE cliente_id = :clienteId AND ativa = 1 ORDER BY numero ASC")
    @org.jetbrains.annotations.Nullable()
    public abstract java.lang.Object obterMesasPorClienteDireto(long clienteId, @org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super java.util.List<com.example.gestaobilhares.data.entities.Mesa>> $completion);
}