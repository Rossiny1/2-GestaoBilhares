package com.example.gestaobilhares.data.repository;

/**
 * Repository para gerenciar despesas.
 * Centraliza o acesso aos dados de despesas, seja do banco local ou dados mock.
 *
 * @property despesaDao DAO para operações no banco de dados
 */
@javax.inject.Singleton()
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000T\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\t\n\u0002\b\u0002\n\u0002\u0010\u0006\n\u0002\b\u0006\b\u0007\u0018\u00002\u00020\u0001B\u000f\b\u0007\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0002\u0010\u0004J\u0016\u0010\u0007\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\nH\u0086@\u00a2\u0006\u0002\u0010\u000bJ\u001a\u0010\f\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u000f0\u000e0\r2\u0006\u0010\u0010\u001a\u00020\u0011J\"\u0010\u0012\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u000f0\u000e0\r2\u0006\u0010\u0013\u001a\u00020\u00142\u0006\u0010\u0015\u001a\u00020\u0014J\u001a\u0010\u0016\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\n0\u000e0\r2\u0006\u0010\u0017\u001a\u00020\u0018J\u0012\u0010\u0019\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u000f0\u000e0\rJ\u0016\u0010\u001a\u001a\u00020\u001b2\u0006\u0010\u0017\u001a\u00020\u0018H\u0086@\u00a2\u0006\u0002\u0010\u001cJ\u0016\u0010\u001d\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\nH\u0086@\u00a2\u0006\u0002\u0010\u000bJ\u0016\u0010\u001e\u001a\u00020\u00182\u0006\u0010\t\u001a\u00020\nH\u0086@\u00a2\u0006\u0002\u0010\u000bJ\u000e\u0010\u001f\u001a\b\u0012\u0004\u0012\u00020\u000f0\u000eH\u0002J\u0016\u0010 \u001a\b\u0012\u0004\u0012\u00020\n0\u000e2\u0006\u0010\u0017\u001a\u00020\u0018H\u0002R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0006X\u0082D\u00a2\u0006\u0002\n\u0000\u00a8\u0006!"}, d2 = {"Lcom/example/gestaobilhares/data/repository/DespesaRepository;", "", "despesaDao", "Lcom/example/gestaobilhares/data/dao/DespesaDao;", "(Lcom/example/gestaobilhares/data/dao/DespesaDao;)V", "usarDadosMock", "", "atualizar", "", "despesa", "Lcom/example/gestaobilhares/data/entities/Despesa;", "(Lcom/example/gestaobilhares/data/entities/Despesa;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "buscarPorCategoria", "Lkotlinx/coroutines/flow/Flow;", "", "Lcom/example/gestaobilhares/data/entities/DespesaResumo;", "categoria", "", "buscarPorPeriodo", "dataInicio", "Ljava/time/LocalDateTime;", "dataFim", "buscarPorRota", "rotaId", "", "buscarTodasComRota", "calcularTotalPorRota", "", "(JLkotlin/coroutines/Continuation;)Ljava/lang/Object;", "deletar", "inserir", "obterDespesasMock", "obterDespesasMockPorRota", "app_debug"})
public final class DespesaRepository {
    @org.jetbrains.annotations.NotNull()
    private final com.example.gestaobilhares.data.dao.DespesaDao despesaDao = null;
    private final boolean usarDadosMock = true;
    
    @javax.inject.Inject()
    public DespesaRepository(@org.jetbrains.annotations.NotNull()
    com.example.gestaobilhares.data.dao.DespesaDao despesaDao) {
        super();
    }
    
    /**
     * Busca todas as despesas com informações das rotas.
     * @return Flow com lista de DespesaResumo
     */
    @org.jetbrains.annotations.NotNull()
    public final kotlinx.coroutines.flow.Flow<java.util.List<com.example.gestaobilhares.data.entities.DespesaResumo>> buscarTodasComRota() {
        return null;
    }
    
    /**
     * Busca despesas de uma rota específica.
     * @param rotaId ID da rota
     * @return Flow com lista de despesas da rota
     */
    @org.jetbrains.annotations.NotNull()
    public final kotlinx.coroutines.flow.Flow<java.util.List<com.example.gestaobilhares.data.entities.Despesa>> buscarPorRota(long rotaId) {
        return null;
    }
    
    /**
     * Busca despesas por período.
     * @param dataInicio Data de início
     * @param dataFim Data de fim
     * @return Flow com lista de DespesaResumo no período
     */
    @org.jetbrains.annotations.NotNull()
    public final kotlinx.coroutines.flow.Flow<java.util.List<com.example.gestaobilhares.data.entities.DespesaResumo>> buscarPorPeriodo(@org.jetbrains.annotations.NotNull()
    java.time.LocalDateTime dataInicio, @org.jetbrains.annotations.NotNull()
    java.time.LocalDateTime dataFim) {
        return null;
    }
    
    /**
     * Busca despesas por categoria.
     * @param categoria Categoria das despesas
     * @return Flow com lista de DespesaResumo da categoria
     */
    @org.jetbrains.annotations.NotNull()
    public final kotlinx.coroutines.flow.Flow<java.util.List<com.example.gestaobilhares.data.entities.DespesaResumo>> buscarPorCategoria(@org.jetbrains.annotations.NotNull()
    java.lang.String categoria) {
        return null;
    }
    
    /**
     * Insere uma nova despesa.
     * @param despesa Despesa a ser inserida
     * @return ID da despesa inserida
     */
    @org.jetbrains.annotations.Nullable()
    public final java.lang.Object inserir(@org.jetbrains.annotations.NotNull()
    com.example.gestaobilhares.data.entities.Despesa despesa, @org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super java.lang.Long> $completion) {
        return null;
    }
    
    /**
     * Atualiza uma despesa existente.
     * @param despesa Despesa com dados atualizados
     */
    @org.jetbrains.annotations.Nullable()
    public final java.lang.Object atualizar(@org.jetbrains.annotations.NotNull()
    com.example.gestaobilhares.data.entities.Despesa despesa, @org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super kotlin.Unit> $completion) {
        return null;
    }
    
    /**
     * Deleta uma despesa.
     * @param despesa Despesa a ser deletada
     */
    @org.jetbrains.annotations.Nullable()
    public final java.lang.Object deletar(@org.jetbrains.annotations.NotNull()
    com.example.gestaobilhares.data.entities.Despesa despesa, @org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super kotlin.Unit> $completion) {
        return null;
    }
    
    /**
     * Calcula total de despesas de uma rota.
     * @param rotaId ID da rota
     * @return Total das despesas da rota
     */
    @org.jetbrains.annotations.Nullable()
    public final java.lang.Object calcularTotalPorRota(long rotaId, @org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super java.lang.Double> $completion) {
        return null;
    }
    
    /**
     * Dados mock para desenvolvimento e testes.
     * Remove quando integrar com dados reais.
     */
    private final java.util.List<com.example.gestaobilhares.data.entities.DespesaResumo> obterDespesasMock() {
        return null;
    }
    
    /**
     * Filtra despesas mock por rota.
     */
    private final java.util.List<com.example.gestaobilhares.data.entities.Despesa> obterDespesasMockPorRota(long rotaId) {
        return null;
    }
}