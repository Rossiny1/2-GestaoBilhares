package com.example.gestaobilhares.data.entities;

/**
 * Entidade que representa um Colaborador no banco de dados.
 * Colaboradores são usuários do sistema com diferentes níveis de acesso.
 */
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u00006\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u001f\n\u0002\u0010\b\n\u0002\b\u0002\b\u0087\b\u0018\u00002\u00020\u0001Bm\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0005\u0012\n\b\u0002\u0010\u0007\u001a\u0004\u0018\u00010\u0005\u0012\n\b\u0002\u0010\b\u001a\u0004\u0018\u00010\u0005\u0012\b\b\u0002\u0010\t\u001a\u00020\n\u0012\b\b\u0002\u0010\u000b\u001a\u00020\f\u0012\n\b\u0002\u0010\r\u001a\u0004\u0018\u00010\u0005\u0012\b\b\u0002\u0010\u000e\u001a\u00020\u000f\u0012\n\b\u0002\u0010\u0010\u001a\u0004\u0018\u00010\u000f\u00a2\u0006\u0002\u0010\u0011J\t\u0010!\u001a\u00020\u0003H\u00c6\u0003J\u000b\u0010\"\u001a\u0004\u0018\u00010\u000fH\u00c6\u0003J\t\u0010#\u001a\u00020\u0005H\u00c6\u0003J\t\u0010$\u001a\u00020\u0005H\u00c6\u0003J\u000b\u0010%\u001a\u0004\u0018\u00010\u0005H\u00c6\u0003J\u000b\u0010&\u001a\u0004\u0018\u00010\u0005H\u00c6\u0003J\t\u0010\'\u001a\u00020\nH\u00c6\u0003J\t\u0010(\u001a\u00020\fH\u00c6\u0003J\u000b\u0010)\u001a\u0004\u0018\u00010\u0005H\u00c6\u0003J\t\u0010*\u001a\u00020\u000fH\u00c6\u0003Ju\u0010+\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u00052\n\b\u0002\u0010\u0007\u001a\u0004\u0018\u00010\u00052\n\b\u0002\u0010\b\u001a\u0004\u0018\u00010\u00052\b\b\u0002\u0010\t\u001a\u00020\n2\b\b\u0002\u0010\u000b\u001a\u00020\f2\n\b\u0002\u0010\r\u001a\u0004\u0018\u00010\u00052\b\b\u0002\u0010\u000e\u001a\u00020\u000f2\n\b\u0002\u0010\u0010\u001a\u0004\u0018\u00010\u000fH\u00c6\u0001J\u0013\u0010,\u001a\u00020\f2\b\u0010-\u001a\u0004\u0018\u00010\u0001H\u00d6\u0003J\t\u0010.\u001a\u00020/H\u00d6\u0001J\t\u00100\u001a\u00020\u0005H\u00d6\u0001R\u0016\u0010\u000b\u001a\u00020\f8\u0006X\u0087\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\u0013R\u0018\u0010\b\u001a\u0004\u0018\u00010\u00058\u0006X\u0087\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0014\u0010\u0015R\u0016\u0010\u000e\u001a\u00020\u000f8\u0006X\u0087\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0016\u0010\u0017R\u0018\u0010\u0010\u001a\u0004\u0018\u00010\u000f8\u0006X\u0087\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0018\u0010\u0017R\u0016\u0010\u0006\u001a\u00020\u00058\u0006X\u0087\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0019\u0010\u0015R\u0018\u0010\r\u001a\u0004\u0018\u00010\u00058\u0006X\u0087\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001a\u0010\u0015R\u0016\u0010\u0002\u001a\u00020\u00038\u0006X\u0087\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001b\u0010\u001cR\u0016\u0010\t\u001a\u00020\n8\u0006X\u0087\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001d\u0010\u001eR\u0016\u0010\u0004\u001a\u00020\u00058\u0006X\u0087\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001f\u0010\u0015R\u0018\u0010\u0007\u001a\u0004\u0018\u00010\u00058\u0006X\u0087\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b \u0010\u0015\u00a8\u00061"}, d2 = {"Lcom/example/gestaobilhares/data/entities/Colaborador;", "", "id", "", "nome", "", "email", "telefone", "cpf", "nivelAcesso", "Lcom/example/gestaobilhares/data/entities/NivelAcesso;", "ativo", "", "firebaseUid", "dataCadastro", "Ljava/util/Date;", "dataUltimoAcesso", "(JLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/example/gestaobilhares/data/entities/NivelAcesso;ZLjava/lang/String;Ljava/util/Date;Ljava/util/Date;)V", "getAtivo", "()Z", "getCpf", "()Ljava/lang/String;", "getDataCadastro", "()Ljava/util/Date;", "getDataUltimoAcesso", "getEmail", "getFirebaseUid", "getId", "()J", "getNivelAcesso", "()Lcom/example/gestaobilhares/data/entities/NivelAcesso;", "getNome", "getTelefone", "component1", "component10", "component2", "component3", "component4", "component5", "component6", "component7", "component8", "component9", "copy", "equals", "other", "hashCode", "", "toString", "app_debug"})
@androidx.room.Entity(tableName = "colaboradores")
public final class Colaborador {
    @androidx.room.PrimaryKey(autoGenerate = true)
    private final long id = 0L;
    @androidx.room.ColumnInfo(name = "nome")
    @org.jetbrains.annotations.NotNull()
    private final java.lang.String nome = null;
    @androidx.room.ColumnInfo(name = "email")
    @org.jetbrains.annotations.NotNull()
    private final java.lang.String email = null;
    @androidx.room.ColumnInfo(name = "telefone")
    @org.jetbrains.annotations.Nullable()
    private final java.lang.String telefone = null;
    @androidx.room.ColumnInfo(name = "cpf")
    @org.jetbrains.annotations.Nullable()
    private final java.lang.String cpf = null;
    @androidx.room.ColumnInfo(name = "nivel_acesso")
    @org.jetbrains.annotations.NotNull()
    private final com.example.gestaobilhares.data.entities.NivelAcesso nivelAcesso = null;
    @androidx.room.ColumnInfo(name = "ativo")
    private final boolean ativo = false;
    @androidx.room.ColumnInfo(name = "firebase_uid")
    @org.jetbrains.annotations.Nullable()
    private final java.lang.String firebaseUid = null;
    @androidx.room.ColumnInfo(name = "data_cadastro")
    @org.jetbrains.annotations.NotNull()
    private final java.util.Date dataCadastro = null;
    @androidx.room.ColumnInfo(name = "data_ultimo_acesso")
    @org.jetbrains.annotations.Nullable()
    private final java.util.Date dataUltimoAcesso = null;
    
    public Colaborador(long id, @org.jetbrains.annotations.NotNull()
    java.lang.String nome, @org.jetbrains.annotations.NotNull()
    java.lang.String email, @org.jetbrains.annotations.Nullable()
    java.lang.String telefone, @org.jetbrains.annotations.Nullable()
    java.lang.String cpf, @org.jetbrains.annotations.NotNull()
    com.example.gestaobilhares.data.entities.NivelAcesso nivelAcesso, boolean ativo, @org.jetbrains.annotations.Nullable()
    java.lang.String firebaseUid, @org.jetbrains.annotations.NotNull()
    java.util.Date dataCadastro, @org.jetbrains.annotations.Nullable()
    java.util.Date dataUltimoAcesso) {
        super();
    }
    
    public final long getId() {
        return 0L;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.lang.String getNome() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.lang.String getEmail() {
        return null;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.lang.String getTelefone() {
        return null;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.lang.String getCpf() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.example.gestaobilhares.data.entities.NivelAcesso getNivelAcesso() {
        return null;
    }
    
    public final boolean getAtivo() {
        return false;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.lang.String getFirebaseUid() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.util.Date getDataCadastro() {
        return null;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.util.Date getDataUltimoAcesso() {
        return null;
    }
    
    public final long component1() {
        return 0L;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.util.Date component10() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.lang.String component2() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.lang.String component3() {
        return null;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.lang.String component4() {
        return null;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.lang.String component5() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.example.gestaobilhares.data.entities.NivelAcesso component6() {
        return null;
    }
    
    public final boolean component7() {
        return false;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.lang.String component8() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.util.Date component9() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.example.gestaobilhares.data.entities.Colaborador copy(long id, @org.jetbrains.annotations.NotNull()
    java.lang.String nome, @org.jetbrains.annotations.NotNull()
    java.lang.String email, @org.jetbrains.annotations.Nullable()
    java.lang.String telefone, @org.jetbrains.annotations.Nullable()
    java.lang.String cpf, @org.jetbrains.annotations.NotNull()
    com.example.gestaobilhares.data.entities.NivelAcesso nivelAcesso, boolean ativo, @org.jetbrains.annotations.Nullable()
    java.lang.String firebaseUid, @org.jetbrains.annotations.NotNull()
    java.util.Date dataCadastro, @org.jetbrains.annotations.Nullable()
    java.util.Date dataUltimoAcesso) {
        return null;
    }
    
    @java.lang.Override()
    public boolean equals(@org.jetbrains.annotations.Nullable()
    java.lang.Object other) {
        return false;
    }
    
    @java.lang.Override()
    public int hashCode() {
        return 0;
    }
    
    @java.lang.Override()
    @org.jetbrains.annotations.NotNull()
    public java.lang.String toString() {
        return null;
    }
}