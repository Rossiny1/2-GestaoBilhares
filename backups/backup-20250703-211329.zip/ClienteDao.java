package com.example.gestaobilhares.data.dao;

/**
 * DAO para operações de cliente no banco de dados
 */
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u00002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\t\n\u0000\n\u0002\u0010\u0006\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\u0010 \n\u0002\b\u0006\bg\u0018\u00002\u00020\u0001J\u0016\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0005H\u00a7@\u00a2\u0006\u0002\u0010\u0006J\u001e\u0010\u0007\u001a\u00020\u00032\u0006\u0010\b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u000bH\u00a7@\u00a2\u0006\u0002\u0010\fJ\u0016\u0010\r\u001a\u00020\u000b2\u0006\u0010\b\u001a\u00020\tH\u00a7@\u00a2\u0006\u0002\u0010\u000eJ\u0016\u0010\u000f\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0005H\u00a7@\u00a2\u0006\u0002\u0010\u0006J\u0016\u0010\u0010\u001a\u00020\t2\u0006\u0010\u0004\u001a\u00020\u0005H\u00a7@\u00a2\u0006\u0002\u0010\u0006J\u0018\u0010\u0011\u001a\u0004\u0018\u00010\u00052\u0006\u0010\b\u001a\u00020\tH\u00a7@\u00a2\u0006\u0002\u0010\u000eJ\u001c\u0010\u0012\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00050\u00140\u00132\u0006\u0010\u0015\u001a\u00020\tH\'J\u0016\u0010\u0016\u001a\u00020\u000b2\u0006\u0010\b\u001a\u00020\tH\u00a7@\u00a2\u0006\u0002\u0010\u000eJ\u0018\u0010\u0017\u001a\u0004\u0018\u00010\u00052\u0006\u0010\u0018\u001a\u00020\tH\u00a7@\u00a2\u0006\u0002\u0010\u000eJ\u0014\u0010\u0019\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00050\u00140\u0013H\'\u00a8\u0006\u001a"}, d2 = {"Lcom/example/gestaobilhares/data/dao/ClienteDao;", "", "atualizar", "", "cliente", "Lcom/example/gestaobilhares/data/entities/Cliente;", "(Lcom/example/gestaobilhares/data/entities/Cliente;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "atualizarDebitoAtual", "clienteId", "", "novoDebito", "", "(JDLkotlin/coroutines/Continuation;)Ljava/lang/Object;", "calcularDebitoAtualEmTempoReal", "(JLkotlin/coroutines/Continuation;)Ljava/lang/Object;", "deletar", "inserir", "obterClienteComDebitoAtual", "obterClientesPorRota", "Lkotlinx/coroutines/flow/Flow;", "", "rotaId", "obterDebitoAtual", "obterPorId", "id", "obterTodos", "app_debug"})
@androidx.room.Dao()
public abstract interface ClienteDao {
    
    @androidx.room.Query(value = "SELECT * FROM clientes WHERE rota_id = :rotaId ORDER BY nome ASC")
    @org.jetbrains.annotations.NotNull()
    public abstract kotlinx.coroutines.flow.Flow<java.util.List<com.example.gestaobilhares.data.entities.Cliente>> obterClientesPorRota(long rotaId);
    
    @androidx.room.Insert()
    @org.jetbrains.annotations.Nullable()
    public abstract java.lang.Object inserir(@org.jetbrains.annotations.NotNull()
    com.example.gestaobilhares.data.entities.Cliente cliente, @org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super java.lang.Long> $completion);
    
    @androidx.room.Update()
    @org.jetbrains.annotations.Nullable()
    public abstract java.lang.Object atualizar(@org.jetbrains.annotations.NotNull()
    com.example.gestaobilhares.data.entities.Cliente cliente, @org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super kotlin.Unit> $completion);
    
    @androidx.room.Delete()
    @org.jetbrains.annotations.Nullable()
    public abstract java.lang.Object deletar(@org.jetbrains.annotations.NotNull()
    com.example.gestaobilhares.data.entities.Cliente cliente, @org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super kotlin.Unit> $completion);
    
    @androidx.room.Query(value = "SELECT * FROM clientes WHERE id = :id")
    @org.jetbrains.annotations.Nullable()
    public abstract java.lang.Object obterPorId(long id, @org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super com.example.gestaobilhares.data.entities.Cliente> $completion);
    
    @androidx.room.Query(value = "SELECT * FROM clientes ORDER BY nome ASC")
    @org.jetbrains.annotations.NotNull()
    public abstract kotlinx.coroutines.flow.Flow<java.util.List<com.example.gestaobilhares.data.entities.Cliente>> obterTodos();
    
    @androidx.room.Query(value = "SELECT debito_atual FROM clientes WHERE id = :clienteId")
    @org.jetbrains.annotations.Nullable()
    public abstract java.lang.Object obterDebitoAtual(long clienteId, @org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super java.lang.Double> $completion);
    
    @androidx.room.Query(value = "UPDATE clientes SET debito_atual = :novoDebito WHERE id = :clienteId")
    @org.jetbrains.annotations.Nullable()
    public abstract java.lang.Object atualizarDebitoAtual(long clienteId, double novoDebito, @org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super kotlin.Unit> $completion);
    
    /**
     * ✅ CORRIGIDO: Calcula o débito atual em tempo real baseado no último acerto
     * Esta query calcula o débito atual diretamente no banco, garantindo consistência
     * CORREÇÃO: Buscar o debito_atual (não debito_anterior) do último acerto
     */
    @androidx.room.Query(value = "\n        SELECT COALESCE(\n            (SELECT debito_atual \n             FROM acertos \n             WHERE cliente_id = :clienteId \n             ORDER BY data_acerto DESC \n             LIMIT 1), \n            0.0\n        ) as debito_atual_calculado\n    ")
    @org.jetbrains.annotations.Nullable()
    public abstract java.lang.Object calcularDebitoAtualEmTempoReal(long clienteId, @org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super java.lang.Double> $completion);
    
    @androidx.room.Query(value = "\n        SELECT c.*, \n               COALESCE(ultimo_acerto.debito_atual, 0.0) as debito_atual_calculado\n        FROM clientes c\n        LEFT JOIN (\n            SELECT cliente_id, debito_atual, data_acerto\n            FROM acertos \n            WHERE cliente_id = :clienteId \n            ORDER BY data_acerto DESC \n            LIMIT 1\n        ) ultimo_acerto ON c.id = ultimo_acerto.cliente_id\n        WHERE c.id = :clienteId\n    ")
    @org.jetbrains.annotations.Nullable()
    public abstract java.lang.Object obterClienteComDebitoAtual(long clienteId, @org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super com.example.gestaobilhares.data.entities.Cliente> $completion);
}