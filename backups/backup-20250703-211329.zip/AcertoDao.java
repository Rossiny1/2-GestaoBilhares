package com.example.gestaobilhares.data.dao;

/**
 * DAO para operações de Acerto no banco de dados
 */
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u00002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\t\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010 \n\u0002\b\t\bg\u0018\u00002\u00020\u0001J\u0016\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0005H\u00a7@\u00a2\u0006\u0002\u0010\u0006J\u0018\u0010\u0007\u001a\u0004\u0018\u00010\b2\u0006\u0010\t\u001a\u00020\nH\u00a7@\u00a2\u0006\u0002\u0010\u000bJ\u001c\u0010\f\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00050\u000e0\r2\u0006\u0010\t\u001a\u00020\nH\'J\u0018\u0010\u000f\u001a\u0004\u0018\u00010\u00052\u0006\u0010\u0010\u001a\u00020\nH\u00a7@\u00a2\u0006\u0002\u0010\u000bJ\u0018\u0010\u0011\u001a\u0004\u0018\u00010\u00052\u0006\u0010\t\u001a\u00020\nH\u00a7@\u00a2\u0006\u0002\u0010\u000bJ\u0018\u0010\u0012\u001a\u0004\u0018\u00010\u00052\u0006\u0010\u0013\u001a\u00020\nH\u00a7@\u00a2\u0006\u0002\u0010\u000bJ\u0016\u0010\u0014\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0005H\u00a7@\u00a2\u0006\u0002\u0010\u0006J\u0016\u0010\u0015\u001a\u00020\n2\u0006\u0010\u0004\u001a\u00020\u0005H\u00a7@\u00a2\u0006\u0002\u0010\u0006J\u0014\u0010\u0016\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00050\u000e0\rH\'\u00a8\u0006\u0017"}, d2 = {"Lcom/example/gestaobilhares/data/dao/AcertoDao;", "", "atualizar", "", "acerto", "Lcom/example/gestaobilhares/data/entities/Acerto;", "(Lcom/example/gestaobilhares/data/entities/Acerto;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "buscarObservacaoUltimoAcerto", "", "clienteId", "", "(JLkotlin/coroutines/Continuation;)Ljava/lang/Object;", "buscarPorCliente", "Lkotlinx/coroutines/flow/Flow;", "", "buscarPorId", "id", "buscarUltimoAcertoPorCliente", "buscarUltimoAcertoPorMesa", "mesaId", "deletar", "inserir", "listarTodos", "app_debug"})
@androidx.room.Dao()
public abstract interface AcertoDao {
    
    @androidx.room.Insert(onConflict = 1)
    @org.jetbrains.annotations.Nullable()
    public abstract java.lang.Object inserir(@org.jetbrains.annotations.NotNull()
    com.example.gestaobilhares.data.entities.Acerto acerto, @org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super java.lang.Long> $completion);
    
    @androidx.room.Query(value = "SELECT * FROM acertos WHERE cliente_id = :clienteId ORDER BY data_acerto DESC")
    @org.jetbrains.annotations.NotNull()
    public abstract kotlinx.coroutines.flow.Flow<java.util.List<com.example.gestaobilhares.data.entities.Acerto>> buscarPorCliente(long clienteId);
    
    @androidx.room.Query(value = "SELECT * FROM acertos ORDER BY data_acerto DESC")
    @org.jetbrains.annotations.NotNull()
    public abstract kotlinx.coroutines.flow.Flow<java.util.List<com.example.gestaobilhares.data.entities.Acerto>> listarTodos();
    
    @androidx.room.Query(value = "SELECT * FROM acertos WHERE id = :id")
    @org.jetbrains.annotations.Nullable()
    public abstract java.lang.Object buscarPorId(long id, @org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super com.example.gestaobilhares.data.entities.Acerto> $completion);
    
    @androidx.room.Query(value = "SELECT * FROM acertos WHERE cliente_id = :clienteId ORDER BY data_acerto DESC LIMIT 1")
    @org.jetbrains.annotations.Nullable()
    public abstract java.lang.Object buscarUltimoAcertoPorCliente(long clienteId, @org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super com.example.gestaobilhares.data.entities.Acerto> $completion);
    
    @androidx.room.Query(value = "SELECT * FROM acertos WHERE id IN (SELECT acerto_id FROM acerto_mesas WHERE mesa_id = :mesaId) ORDER BY data_acerto DESC LIMIT 1")
    @org.jetbrains.annotations.Nullable()
    public abstract java.lang.Object buscarUltimoAcertoPorMesa(long mesaId, @org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super com.example.gestaobilhares.data.entities.Acerto> $completion);
    
    @androidx.room.Query(value = "SELECT observacoes FROM acertos WHERE cliente_id = :clienteId ORDER BY data_acerto DESC LIMIT 1")
    @org.jetbrains.annotations.Nullable()
    public abstract java.lang.Object buscarObservacaoUltimoAcerto(long clienteId, @org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super java.lang.String> $completion);
    
    @androidx.room.Update()
    @org.jetbrains.annotations.Nullable()
    public abstract java.lang.Object atualizar(@org.jetbrains.annotations.NotNull()
    com.example.gestaobilhares.data.entities.Acerto acerto, @org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super kotlin.Unit> $completion);
    
    @androidx.room.Delete()
    @org.jetbrains.annotations.Nullable()
    public abstract java.lang.Object deletar(@org.jetbrains.annotations.NotNull()
    com.example.gestaobilhares.data.entities.Acerto acerto, @org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super kotlin.Unit> $completion);
}