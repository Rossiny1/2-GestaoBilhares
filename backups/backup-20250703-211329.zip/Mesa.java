package com.example.gestaobilhares.data.entities;

/**
 * Entidade que representa uma Mesa de sinuca no banco de dados.
 * Mesas pertencem a clientes e têm contadores de fichas.
 */
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000^\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0004\n\u0002\u0010\u0006\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b0\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0087\b\u0018\u00002\u00020\u0001B\u009d\u0001\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\n\b\u0002\u0010\u0006\u001a\u0004\u0018\u00010\u0003\u0012\b\b\u0002\u0010\u0007\u001a\u00020\b\u0012\b\b\u0002\u0010\t\u001a\u00020\b\u0012\b\b\u0002\u0010\n\u001a\u00020\b\u0012\b\b\u0002\u0010\u000b\u001a\u00020\b\u0012\b\b\u0002\u0010\f\u001a\u00020\r\u0012\b\b\u0002\u0010\u000e\u001a\u00020\u000f\u0012\b\b\u0002\u0010\u0010\u001a\u00020\u0011\u0012\b\b\u0002\u0010\u0012\u001a\u00020\u0013\u0012\b\b\u0002\u0010\u0014\u001a\u00020\u0015\u0012\n\b\u0002\u0010\u0016\u001a\u0004\u0018\u00010\u0005\u0012\b\b\u0002\u0010\u0017\u001a\u00020\u0018\u0012\b\b\u0002\u0010\u0019\u001a\u00020\u0018\u00a2\u0006\u0002\u0010\u001aJ\t\u00105\u001a\u00020\u0003H\u00c6\u0003J\t\u00106\u001a\u00020\u0011H\u00c6\u0003J\t\u00107\u001a\u00020\u0013H\u00c6\u0003J\t\u00108\u001a\u00020\u0015H\u00c6\u0003J\u000b\u00109\u001a\u0004\u0018\u00010\u0005H\u00c6\u0003J\t\u0010:\u001a\u00020\u0018H\u00c6\u0003J\t\u0010;\u001a\u00020\u0018H\u00c6\u0003J\t\u0010<\u001a\u00020\u0005H\u00c6\u0003J\u0010\u0010=\u001a\u0004\u0018\u00010\u0003H\u00c6\u0003\u00a2\u0006\u0002\u0010\u001eJ\t\u0010>\u001a\u00020\bH\u00c6\u0003J\t\u0010?\u001a\u00020\bH\u00c6\u0003J\t\u0010@\u001a\u00020\bH\u00c6\u0003J\t\u0010A\u001a\u00020\bH\u00c6\u0003J\t\u0010B\u001a\u00020\rH\u00c6\u0003J\t\u0010C\u001a\u00020\u000fH\u00c6\u0003J\u00a8\u0001\u0010D\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\n\b\u0002\u0010\u0006\u001a\u0004\u0018\u00010\u00032\b\b\u0002\u0010\u0007\u001a\u00020\b2\b\b\u0002\u0010\t\u001a\u00020\b2\b\b\u0002\u0010\n\u001a\u00020\b2\b\b\u0002\u0010\u000b\u001a\u00020\b2\b\b\u0002\u0010\f\u001a\u00020\r2\b\b\u0002\u0010\u000e\u001a\u00020\u000f2\b\b\u0002\u0010\u0010\u001a\u00020\u00112\b\b\u0002\u0010\u0012\u001a\u00020\u00132\b\b\u0002\u0010\u0014\u001a\u00020\u00152\n\b\u0002\u0010\u0016\u001a\u0004\u0018\u00010\u00052\b\b\u0002\u0010\u0017\u001a\u00020\u00182\b\b\u0002\u0010\u0019\u001a\u00020\u0018H\u00c6\u0001\u00a2\u0006\u0002\u0010EJ\t\u0010F\u001a\u00020\bH\u00d6\u0001J\u0013\u0010G\u001a\u00020\u00152\b\u0010H\u001a\u0004\u0018\u00010IH\u00d6\u0003J\t\u0010J\u001a\u00020\bH\u00d6\u0001J\t\u0010K\u001a\u00020\u0005H\u00d6\u0001J\u0019\u0010L\u001a\u00020M2\u0006\u0010N\u001a\u00020O2\u0006\u0010P\u001a\u00020\bH\u00d6\u0001R\u0016\u0010\u0014\u001a\u00020\u00158\u0006X\u0087\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001b\u0010\u001cR\u001a\u0010\u0006\u001a\u0004\u0018\u00010\u00038\u0006X\u0087\u0004\u00a2\u0006\n\n\u0002\u0010\u001f\u001a\u0004\b\u001d\u0010\u001eR\u0016\u0010\u0017\u001a\u00020\u00188\u0006X\u0087\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b \u0010!R\u0016\u0010\u0019\u001a\u00020\u00188\u0006X\u0087\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\"\u0010!R\u0016\u0010\u0012\u001a\u00020\u00138\u0006X\u0087\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b#\u0010$R\u0016\u0010\t\u001a\u00020\b8\u0006X\u0087\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b%\u0010&R\u0016\u0010\u0007\u001a\u00020\b8\u0006X\u0087\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\'\u0010&R\u0016\u0010\u0002\u001a\u00020\u00038\u0006X\u0087\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b(\u0010)R\u0016\u0010\u0004\u001a\u00020\u00058\u0006X\u0087\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b*\u0010+R\u0018\u0010\u0016\u001a\u0004\u0018\u00010\u00058\u0006X\u0087\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b,\u0010+R\u0016\u0010\u000b\u001a\u00020\b8\u0006X\u0087\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b-\u0010&R\u0016\u0010\n\u001a\u00020\b8\u0006X\u0087\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b.\u0010&R\u0016\u0010\u0010\u001a\u00020\u00118\u0006X\u0087\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b/\u00100R\u0016\u0010\u000e\u001a\u00020\u000f8\u0006X\u0087\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b1\u00102R\u0016\u0010\f\u001a\u00020\r8\u0006X\u0087\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b3\u00104\u00a8\u0006Q"}, d2 = {"Lcom/example/gestaobilhares/data/entities/Mesa;", "Landroid/os/Parcelable;", "id", "", "numero", "", "clienteId", "fichasInicial", "", "fichasFinal", "relogioInicial", "relogioFinal", "valorFixo", "", "tipoMesa", "Lcom/example/gestaobilhares/data/entities/TipoMesa;", "tamanho", "Lcom/example/gestaobilhares/data/entities/TamanhoMesa;", "estadoConservacao", "Lcom/example/gestaobilhares/data/entities/EstadoConservacao;", "ativa", "", "observacoes", "dataInstalacao", "Ljava/util/Date;", "dataUltimaLeitura", "(JLjava/lang/String;Ljava/lang/Long;IIIIDLcom/example/gestaobilhares/data/entities/TipoMesa;Lcom/example/gestaobilhares/data/entities/TamanhoMesa;Lcom/example/gestaobilhares/data/entities/EstadoConservacao;ZLjava/lang/String;Ljava/util/Date;Ljava/util/Date;)V", "getAtiva", "()Z", "getClienteId", "()Ljava/lang/Long;", "Ljava/lang/Long;", "getDataInstalacao", "()Ljava/util/Date;", "getDataUltimaLeitura", "getEstadoConservacao", "()Lcom/example/gestaobilhares/data/entities/EstadoConservacao;", "getFichasFinal", "()I", "getFichasInicial", "getId", "()J", "getNumero", "()Ljava/lang/String;", "getObservacoes", "getRelogioFinal", "getRelogioInicial", "getTamanho", "()Lcom/example/gestaobilhares/data/entities/TamanhoMesa;", "getTipoMesa", "()Lcom/example/gestaobilhares/data/entities/TipoMesa;", "getValorFixo", "()D", "component1", "component10", "component11", "component12", "component13", "component14", "component15", "component2", "component3", "component4", "component5", "component6", "component7", "component8", "component9", "copy", "(JLjava/lang/String;Ljava/lang/Long;IIIIDLcom/example/gestaobilhares/data/entities/TipoMesa;Lcom/example/gestaobilhares/data/entities/TamanhoMesa;Lcom/example/gestaobilhares/data/entities/EstadoConservacao;ZLjava/lang/String;Ljava/util/Date;Ljava/util/Date;)Lcom/example/gestaobilhares/data/entities/Mesa;", "describeContents", "equals", "other", "", "hashCode", "toString", "writeToParcel", "", "parcel", "Landroid/os/Parcel;", "flags", "app_debug"})
@kotlinx.parcelize.Parcelize()
@androidx.room.Entity(tableName = "mesas", foreignKeys = {@androidx.room.ForeignKey(entity = com.example.gestaobilhares.data.entities.Cliente.class, parentColumns = {"id"}, childColumns = {"cliente_id"}, onDelete = 5)}, indices = {@androidx.room.Index(value = {"cliente_id"})})
public final class Mesa implements android.os.Parcelable {
    @androidx.room.PrimaryKey(autoGenerate = true)
    private final long id = 0L;
    @androidx.room.ColumnInfo(name = "numero")
    @org.jetbrains.annotations.NotNull()
    private final java.lang.String numero = null;
    @androidx.room.ColumnInfo(name = "cliente_id")
    @org.jetbrains.annotations.Nullable()
    private final java.lang.Long clienteId = null;
    @androidx.room.ColumnInfo(name = "fichas_inicial")
    private final int fichasInicial = 0;
    @androidx.room.ColumnInfo(name = "fichas_final")
    private final int fichasFinal = 0;
    @androidx.room.ColumnInfo(name = "relogio_inicial")
    private final int relogioInicial = 0;
    @androidx.room.ColumnInfo(name = "relogio_final")
    private final int relogioFinal = 0;
    @androidx.room.ColumnInfo(name = "valor_fixo")
    private final double valorFixo = 0.0;
    @androidx.room.ColumnInfo(name = "tipo_mesa")
    @org.jetbrains.annotations.NotNull()
    private final com.example.gestaobilhares.data.entities.TipoMesa tipoMesa = null;
    @androidx.room.ColumnInfo(name = "tamanho")
    @org.jetbrains.annotations.NotNull()
    private final com.example.gestaobilhares.data.entities.TamanhoMesa tamanho = null;
    @androidx.room.ColumnInfo(name = "estado_conservacao")
    @org.jetbrains.annotations.NotNull()
    private final com.example.gestaobilhares.data.entities.EstadoConservacao estadoConservacao = null;
    @androidx.room.ColumnInfo(name = "ativa")
    private final boolean ativa = false;
    @androidx.room.ColumnInfo(name = "observacoes")
    @org.jetbrains.annotations.Nullable()
    private final java.lang.String observacoes = null;
    @androidx.room.ColumnInfo(name = "data_instalacao")
    @org.jetbrains.annotations.NotNull()
    private final java.util.Date dataInstalacao = null;
    @androidx.room.ColumnInfo(name = "data_ultima_leitura")
    @org.jetbrains.annotations.NotNull()
    private final java.util.Date dataUltimaLeitura = null;
    
    public Mesa(long id, @org.jetbrains.annotations.NotNull()
    java.lang.String numero, @org.jetbrains.annotations.Nullable()
    java.lang.Long clienteId, int fichasInicial, int fichasFinal, int relogioInicial, int relogioFinal, double valorFixo, @org.jetbrains.annotations.NotNull()
    com.example.gestaobilhares.data.entities.TipoMesa tipoMesa, @org.jetbrains.annotations.NotNull()
    com.example.gestaobilhares.data.entities.TamanhoMesa tamanho, @org.jetbrains.annotations.NotNull()
    com.example.gestaobilhares.data.entities.EstadoConservacao estadoConservacao, boolean ativa, @org.jetbrains.annotations.Nullable()
    java.lang.String observacoes, @org.jetbrains.annotations.NotNull()
    java.util.Date dataInstalacao, @org.jetbrains.annotations.NotNull()
    java.util.Date dataUltimaLeitura) {
        super();
    }
    
    public final long getId() {
        return 0L;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.lang.String getNumero() {
        return null;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.lang.Long getClienteId() {
        return null;
    }
    
    public final int getFichasInicial() {
        return 0;
    }
    
    public final int getFichasFinal() {
        return 0;
    }
    
    public final int getRelogioInicial() {
        return 0;
    }
    
    public final int getRelogioFinal() {
        return 0;
    }
    
    public final double getValorFixo() {
        return 0.0;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.example.gestaobilhares.data.entities.TipoMesa getTipoMesa() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.example.gestaobilhares.data.entities.TamanhoMesa getTamanho() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.example.gestaobilhares.data.entities.EstadoConservacao getEstadoConservacao() {
        return null;
    }
    
    public final boolean getAtiva() {
        return false;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.lang.String getObservacoes() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.util.Date getDataInstalacao() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.util.Date getDataUltimaLeitura() {
        return null;
    }
    
    public final long component1() {
        return 0L;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.example.gestaobilhares.data.entities.TamanhoMesa component10() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.example.gestaobilhares.data.entities.EstadoConservacao component11() {
        return null;
    }
    
    public final boolean component12() {
        return false;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.lang.String component13() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.util.Date component14() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.util.Date component15() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.lang.String component2() {
        return null;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.lang.Long component3() {
        return null;
    }
    
    public final int component4() {
        return 0;
    }
    
    public final int component5() {
        return 0;
    }
    
    public final int component6() {
        return 0;
    }
    
    public final int component7() {
        return 0;
    }
    
    public final double component8() {
        return 0.0;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.example.gestaobilhares.data.entities.TipoMesa component9() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.example.gestaobilhares.data.entities.Mesa copy(long id, @org.jetbrains.annotations.NotNull()
    java.lang.String numero, @org.jetbrains.annotations.Nullable()
    java.lang.Long clienteId, int fichasInicial, int fichasFinal, int relogioInicial, int relogioFinal, double valorFixo, @org.jetbrains.annotations.NotNull()
    com.example.gestaobilhares.data.entities.TipoMesa tipoMesa, @org.jetbrains.annotations.NotNull()
    com.example.gestaobilhares.data.entities.TamanhoMesa tamanho, @org.jetbrains.annotations.NotNull()
    com.example.gestaobilhares.data.entities.EstadoConservacao estadoConservacao, boolean ativa, @org.jetbrains.annotations.Nullable()
    java.lang.String observacoes, @org.jetbrains.annotations.NotNull()
    java.util.Date dataInstalacao, @org.jetbrains.annotations.NotNull()
    java.util.Date dataUltimaLeitura) {
        return null;
    }
    
    @java.lang.Override()
    public int describeContents() {
        return 0;
    }
    
    @java.lang.Override()
    public boolean equals(@org.jetbrains.annotations.Nullable()
    java.lang.Object other) {
        return false;
    }
    
    @java.lang.Override()
    public int hashCode() {
        return 0;
    }
    
    @java.lang.Override()
    @org.jetbrains.annotations.NotNull()
    public java.lang.String toString() {
        return null;
    }
    
    @java.lang.Override()
    public void writeToParcel(@org.jetbrains.annotations.NotNull()
    android.os.Parcel parcel, int flags) {
    }
}