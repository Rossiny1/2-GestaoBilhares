package com.example.gestaobilhares.data.database;

/**
 * Classe com conversores de tipos para o Room Database.
 * Converte tipos não suportados nativamente pelo Room.
 */
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000X\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\t\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010$\n\u0002\u0010\u0006\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\t\u0018\u00002\u00020\u0001B\u0005\u00a2\u0006\u0002\u0010\u0002J\u0019\u0010\u0003\u001a\u0004\u0018\u00010\u00042\b\u0010\u0005\u001a\u0004\u0018\u00010\u0006H\u0007\u00a2\u0006\u0002\u0010\u0007J\u0010\u0010\b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u000bH\u0007J\u0010\u0010\f\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\rH\u0007J\u0014\u0010\u000e\u001a\u0004\u0018\u00010\t2\b\u0010\n\u001a\u0004\u0018\u00010\u000fH\u0007J\u0010\u0010\u0010\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u0011H\u0007J \u0010\u0012\u001a\u0004\u0018\u00010\t2\u0014\u0010\n\u001a\u0010\u0012\u0004\u0012\u00020\t\u0012\u0004\u0012\u00020\u0014\u0018\u00010\u0013H\u0007J\u0010\u0010\u0015\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u0016H\u0007J\u0010\u0010\u0017\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u0018H\u0007J\u0019\u0010\u0019\u001a\u0004\u0018\u00010\u00062\b\u0010\n\u001a\u0004\u0018\u00010\u0004H\u0007\u00a2\u0006\u0002\u0010\u001aJ\u0010\u0010\u001b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u001cH\u0007J\u0010\u0010\u001d\u001a\u00020\u000b2\u0006\u0010\n\u001a\u00020\tH\u0007J\u0010\u0010\u001e\u001a\u00020\r2\u0006\u0010\n\u001a\u00020\tH\u0007J\u0014\u0010\u001f\u001a\u0004\u0018\u00010\u000f2\b\u0010\n\u001a\u0004\u0018\u00010\tH\u0007J\u0010\u0010 \u001a\u00020\u00112\u0006\u0010\n\u001a\u00020\tH\u0007J \u0010!\u001a\u0010\u0012\u0004\u0012\u00020\t\u0012\u0004\u0012\u00020\u0014\u0018\u00010\u00132\b\u0010\n\u001a\u0004\u0018\u00010\tH\u0007J\u0010\u0010\"\u001a\u00020\u00162\u0006\u0010\n\u001a\u00020\tH\u0007J\u0010\u0010#\u001a\u00020\u00182\u0006\u0010\n\u001a\u00020\tH\u0007J\u0010\u0010$\u001a\u00020\u001c2\u0006\u0010\n\u001a\u00020\tH\u0007\u00a8\u0006%"}, d2 = {"Lcom/example/gestaobilhares/data/database/Converters;", "", "()V", "dateToTimestamp", "", "date", "Ljava/util/Date;", "(Ljava/util/Date;)Ljava/lang/Long;", "fromCategoriaDespesa", "", "value", "Lcom/example/gestaobilhares/data/entities/CategoriaDespesa;", "fromEstadoConservacao", "Lcom/example/gestaobilhares/data/entities/EstadoConservacao;", "fromLocalDateTime", "Ljava/time/LocalDateTime;", "fromNivelAcesso", "Lcom/example/gestaobilhares/data/entities/NivelAcesso;", "fromPagamentoMap", "", "", "fromStatusAcerto", "Lcom/example/gestaobilhares/data/entities/StatusAcerto;", "fromTamanhoMesa", "Lcom/example/gestaobilhares/data/entities/TamanhoMesa;", "fromTimestamp", "(Ljava/lang/Long;)Ljava/util/Date;", "fromTipoMesa", "Lcom/example/gestaobilhares/data/entities/TipoMesa;", "toCategoriaDespesa", "toEstadoConservacao", "toLocalDateTime", "toNivelAcesso", "toPagamentoMap", "toStatusAcerto", "toTamanhoMesa", "toTipoMesa", "app_debug"})
public final class Converters {
    
    public Converters() {
        super();
    }
    
    /**
     * Conversores para Date
     */
    @androidx.room.TypeConverter()
    @org.jetbrains.annotations.Nullable()
    public final java.util.Date fromTimestamp(@org.jetbrains.annotations.Nullable()
    java.lang.Long value) {
        return null;
    }
    
    @androidx.room.TypeConverter()
    @org.jetbrains.annotations.Nullable()
    public final java.lang.Long dateToTimestamp(@org.jetbrains.annotations.Nullable()
    java.util.Date date) {
        return null;
    }
    
    /**
     * Conversores para TipoMesa enum
     */
    @androidx.room.TypeConverter()
    @org.jetbrains.annotations.NotNull()
    public final java.lang.String fromTipoMesa(@org.jetbrains.annotations.NotNull()
    com.example.gestaobilhares.data.entities.TipoMesa value) {
        return null;
    }
    
    @androidx.room.TypeConverter()
    @org.jetbrains.annotations.NotNull()
    public final com.example.gestaobilhares.data.entities.TipoMesa toTipoMesa(@org.jetbrains.annotations.NotNull()
    java.lang.String value) {
        return null;
    }
    
    /**
     * Conversores para TamanhoMesa enum
     */
    @androidx.room.TypeConverter()
    @org.jetbrains.annotations.NotNull()
    public final java.lang.String fromTamanhoMesa(@org.jetbrains.annotations.NotNull()
    com.example.gestaobilhares.data.entities.TamanhoMesa value) {
        return null;
    }
    
    @androidx.room.TypeConverter()
    @org.jetbrains.annotations.NotNull()
    public final com.example.gestaobilhares.data.entities.TamanhoMesa toTamanhoMesa(@org.jetbrains.annotations.NotNull()
    java.lang.String value) {
        return null;
    }
    
    /**
     * Conversores para EstadoConservacao enum
     */
    @androidx.room.TypeConverter()
    @org.jetbrains.annotations.NotNull()
    public final java.lang.String fromEstadoConservacao(@org.jetbrains.annotations.NotNull()
    com.example.gestaobilhares.data.entities.EstadoConservacao value) {
        return null;
    }
    
    @androidx.room.TypeConverter()
    @org.jetbrains.annotations.NotNull()
    public final com.example.gestaobilhares.data.entities.EstadoConservacao toEstadoConservacao(@org.jetbrains.annotations.NotNull()
    java.lang.String value) {
        return null;
    }
    
    /**
     * Conversores para NivelAcesso enum
     */
    @androidx.room.TypeConverter()
    @org.jetbrains.annotations.NotNull()
    public final java.lang.String fromNivelAcesso(@org.jetbrains.annotations.NotNull()
    com.example.gestaobilhares.data.entities.NivelAcesso value) {
        return null;
    }
    
    @androidx.room.TypeConverter()
    @org.jetbrains.annotations.NotNull()
    public final com.example.gestaobilhares.data.entities.NivelAcesso toNivelAcesso(@org.jetbrains.annotations.NotNull()
    java.lang.String value) {
        return null;
    }
    
    /**
     * Conversores para StatusAcerto enum
     */
    @androidx.room.TypeConverter()
    @org.jetbrains.annotations.NotNull()
    public final java.lang.String fromStatusAcerto(@org.jetbrains.annotations.NotNull()
    com.example.gestaobilhares.data.entities.StatusAcerto value) {
        return null;
    }
    
    @androidx.room.TypeConverter()
    @org.jetbrains.annotations.NotNull()
    public final com.example.gestaobilhares.data.entities.StatusAcerto toStatusAcerto(@org.jetbrains.annotations.NotNull()
    java.lang.String value) {
        return null;
    }
    
    /**
     * Conversores para CategoriaDespesa enum
     */
    @androidx.room.TypeConverter()
    @org.jetbrains.annotations.NotNull()
    public final java.lang.String fromCategoriaDespesa(@org.jetbrains.annotations.NotNull()
    com.example.gestaobilhares.data.entities.CategoriaDespesa value) {
        return null;
    }
    
    @androidx.room.TypeConverter()
    @org.jetbrains.annotations.NotNull()
    public final com.example.gestaobilhares.data.entities.CategoriaDespesa toCategoriaDespesa(@org.jetbrains.annotations.NotNull()
    java.lang.String value) {
        return null;
    }
    
    /**
     * Conversores para LocalDateTime
     */
    @androidx.room.TypeConverter()
    @org.jetbrains.annotations.Nullable()
    public final java.lang.String fromLocalDateTime(@org.jetbrains.annotations.Nullable()
    java.time.LocalDateTime value) {
        return null;
    }
    
    @androidx.room.TypeConverter()
    @org.jetbrains.annotations.Nullable()
    public final java.time.LocalDateTime toLocalDateTime(@org.jetbrains.annotations.Nullable()
    java.lang.String value) {
        return null;
    }
    
    @androidx.room.TypeConverter()
    @org.jetbrains.annotations.Nullable()
    public final java.lang.String fromPagamentoMap(@org.jetbrains.annotations.Nullable()
    java.util.Map<java.lang.String, java.lang.Double> value) {
        return null;
    }
    
    @androidx.room.TypeConverter()
    @org.jetbrains.annotations.Nullable()
    public final java.util.Map<java.lang.String, java.lang.Double> toPagamentoMap(@org.jetbrains.annotations.Nullable()
    java.lang.String value) {
        return null;
    }
}