package com.example.gestaobilhares.ui.clients;

/**
 * ViewModel para ClientListFragment
 * FASE 3: Implementação com controle de status da rota
 */
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000b\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0010\t\n\u0002\b\u0005\n\u0002\u0010\u0002\n\u0002\b\r\u0018\u00002\u00020\u0001B\u0015\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\u0002\u0010\u0006J\u000e\u0010&\u001a\u00020\'2\u0006\u0010(\u001a\u00020\u0010J\u0010\u0010)\u001a\u00020\'2\u0006\u0010*\u001a\u00020\u0014H\u0002J\b\u0010+\u001a\u00020\tH\u0002J\u000e\u0010,\u001a\u00020\'2\u0006\u0010 \u001a\u00020!J\u000e\u0010-\u001a\u00020\'2\u0006\u0010 \u001a\u00020!J\u0010\u0010.\u001a\u00020\'2\u0006\u0010*\u001a\u00020\u0014H\u0002J\u0006\u0010/\u001a\u00020\'J\u0006\u00100\u001a\u00020\'J\u0006\u00101\u001a\u00020\'J\u0006\u00102\u001a\u00020\u0012J\u0006\u00103\u001a\u00020\u0012R\u0014\u0010\u0007\u001a\b\u0012\u0004\u0012\u00020\t0\bX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u001a\u0010\n\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\f0\u000b0\bX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0016\u0010\r\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u000e0\bX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u0010\u000f\u001a\b\u0012\u0004\u0012\u00020\u00100\bX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u0010\u0011\u001a\b\u0012\u0004\u0012\u00020\u00120\bX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0016\u0010\u0013\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00140\bX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u0010\u0015\u001a\b\u0012\u0004\u0012\u00020\u00160\bX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0017\u0010\u0017\u001a\b\u0012\u0004\u0012\u00020\t0\u0018\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0019\u0010\u001aR\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u001d\u0010\u001b\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\f0\u000b0\u0018\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001c\u0010\u001aR\u0019\u0010\u001d\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u000e0\u0018\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001e\u0010\u001aR\u0017\u0010\u001f\u001a\b\u0012\u0004\u0012\u00020\u00120\u0018\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001f\u0010\u001aR\u000e\u0010 \u001a\u00020!X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0019\u0010\"\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00140\u0018\u00a2\u0006\b\n\u0000\u001a\u0004\b#\u0010\u001aR\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0017\u0010$\u001a\b\u0012\u0004\u0012\u00020\u00160\u0018\u00a2\u0006\b\n\u0000\u001a\u0004\b%\u0010\u001a\u00a8\u00064"}, d2 = {"Lcom/example/gestaobilhares/ui/clients/ClientListViewModel;", "Landroidx/lifecycle/ViewModel;", "clienteRepository", "Lcom/example/gestaobilhares/data/repositories/ClienteRepository;", "rotaRepository", "Lcom/example/gestaobilhares/data/repository/RotaRepository;", "(Lcom/example/gestaobilhares/data/repositories/ClienteRepository;Lcom/example/gestaobilhares/data/repository/RotaRepository;)V", "_cicloAcerto", "Lkotlinx/coroutines/flow/MutableStateFlow;", "", "_clientesTodos", "", "Lcom/example/gestaobilhares/data/entities/Cliente;", "_errorMessage", "", "_filtroAtual", "Lcom/example/gestaobilhares/ui/clients/FiltroCliente;", "_isLoading", "", "_rotaInfo", "Lcom/example/gestaobilhares/data/entities/Rota;", "_statusRota", "Lcom/example/gestaobilhares/data/entities/StatusRota;", "cicloAcerto", "Lkotlinx/coroutines/flow/StateFlow;", "getCicloAcerto", "()Lkotlinx/coroutines/flow/StateFlow;", "clientes", "getClientes", "errorMessage", "getErrorMessage", "isLoading", "rotaId", "", "rotaInfo", "getRotaInfo", "statusRota", "getStatusRota", "aplicarFiltro", "", "filtro", "calcularCicloAcerto", "rota", "calcularProximoCiclo", "carregarClientes", "carregarRota", "carregarStatusRota", "finalizarRota", "iniciarRota", "limparErro", "podeAcessarCliente", "podeRealizarAcerto", "app_debug"})
public final class ClientListViewModel extends androidx.lifecycle.ViewModel {
    @org.jetbrains.annotations.NotNull()
    private final com.example.gestaobilhares.data.repositories.ClienteRepository clienteRepository = null;
    @org.jetbrains.annotations.NotNull()
    private final com.example.gestaobilhares.data.repository.RotaRepository rotaRepository = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlinx.coroutines.flow.MutableStateFlow<com.example.gestaobilhares.data.entities.Rota> _rotaInfo = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlinx.coroutines.flow.StateFlow<com.example.gestaobilhares.data.entities.Rota> rotaInfo = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlinx.coroutines.flow.MutableStateFlow<com.example.gestaobilhares.data.entities.StatusRota> _statusRota = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlinx.coroutines.flow.StateFlow<com.example.gestaobilhares.data.entities.StatusRota> statusRota = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlinx.coroutines.flow.MutableStateFlow<java.lang.Integer> _cicloAcerto = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlinx.coroutines.flow.StateFlow<java.lang.Integer> cicloAcerto = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlinx.coroutines.flow.MutableStateFlow<java.util.List<com.example.gestaobilhares.data.entities.Cliente>> _clientesTodos = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlinx.coroutines.flow.MutableStateFlow<com.example.gestaobilhares.ui.clients.FiltroCliente> _filtroAtual = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlinx.coroutines.flow.StateFlow<java.util.List<com.example.gestaobilhares.data.entities.Cliente>> clientes = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlinx.coroutines.flow.MutableStateFlow<java.lang.Boolean> _isLoading = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlinx.coroutines.flow.StateFlow<java.lang.Boolean> isLoading = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlinx.coroutines.flow.MutableStateFlow<java.lang.String> _errorMessage = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlinx.coroutines.flow.StateFlow<java.lang.String> errorMessage = null;
    private long rotaId = 0L;
    
    public ClientListViewModel(@org.jetbrains.annotations.NotNull()
    com.example.gestaobilhares.data.repositories.ClienteRepository clienteRepository, @org.jetbrains.annotations.NotNull()
    com.example.gestaobilhares.data.repository.RotaRepository rotaRepository) {
        super();
    }
    
    @org.jetbrains.annotations.NotNull()
    public final kotlinx.coroutines.flow.StateFlow<com.example.gestaobilhares.data.entities.Rota> getRotaInfo() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final kotlinx.coroutines.flow.StateFlow<com.example.gestaobilhares.data.entities.StatusRota> getStatusRota() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final kotlinx.coroutines.flow.StateFlow<java.lang.Integer> getCicloAcerto() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final kotlinx.coroutines.flow.StateFlow<java.util.List<com.example.gestaobilhares.data.entities.Cliente>> getClientes() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final kotlinx.coroutines.flow.StateFlow<java.lang.Boolean> isLoading() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final kotlinx.coroutines.flow.StateFlow<java.lang.String> getErrorMessage() {
        return null;
    }
    
    /**
     * Carrega informações da rota
     */
    public final void carregarRota(long rotaId) {
    }
    
    /**
     * Carrega clientes da rota
     */
    public final void carregarClientes(long rotaId) {
    }
    
    /**
     * Aplica filtro à lista de clientes
     */
    public final void aplicarFiltro(@org.jetbrains.annotations.NotNull()
    com.example.gestaobilhares.ui.clients.FiltroCliente filtro) {
    }
    
    /**
     * Inicia a rota criando um novo ciclo de acerto
     */
    public final void iniciarRota() {
    }
    
    /**
     * Finaliza a rota atual
     */
    public final void finalizarRota() {
    }
    
    /**
     * Verifica se pode acessar detalhes do cliente (rota deve estar em andamento)
     */
    public final boolean podeAcessarCliente() {
        return false;
    }
    
    /**
     * Verifica se pode fazer acerto (rota deve estar em andamento)
     */
    public final boolean podeRealizarAcerto() {
        return false;
    }
    
    /**
     * Calcula o ciclo de acerto baseado no ano atual e histórico da rota
     */
    private final void calcularCicloAcerto(com.example.gestaobilhares.data.entities.Rota rota) {
    }
    
    /**
     * Calcula o próximo ciclo de acerto
     */
    private final int calcularProximoCiclo() {
        return 0;
    }
    
    /**
     * Carrega o status atual da rota
     */
    private final void carregarStatusRota(com.example.gestaobilhares.data.entities.Rota rota) {
    }
    
    /**
     * Limpa mensagens de erro
     */
    public final void limparErro() {
    }
}