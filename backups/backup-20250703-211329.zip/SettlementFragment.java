package com.example.gestaobilhares.ui.settlement;

/**
 * Fragment para registrar novos acertos
 * FASE 4A - Implementação crítica do core business
 */
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u0082\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010%\n\u0002\u0010\u000e\n\u0002\u0010\u0006\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010\t\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0011\n\u0002\b\u0006\u0018\u00002\u00020\u0001B\u0005\u00a2\u0006\u0002\u0010\u0002J\b\u0010\u0019\u001a\u00020\u001aH\u0002J\u0016\u0010\u001b\u001a\u00020\u001a2\u0006\u0010\u001c\u001a\u00020\u001dH\u0082@\u00a2\u0006\u0002\u0010\u001eJ\b\u0010\u001f\u001a\u00020\u001aH\u0002J\b\u0010 \u001a\u00020\u001aH\u0002J\b\u0010!\u001a\u00020\u001aH\u0002J\u0010\u0010\"\u001a\u00020\u001a2\u0006\u0010#\u001a\u00020$H\u0002J\b\u0010%\u001a\u00020\u001aH\u0002J$\u0010&\u001a\u00020\'2\u0006\u0010(\u001a\u00020)2\b\u0010*\u001a\u0004\u0018\u00010+2\b\u0010,\u001a\u0004\u0018\u00010-H\u0016J\b\u0010.\u001a\u00020\u001aH\u0016J\u001a\u0010/\u001a\u00020\u001a2\u0006\u00100\u001a\u00020\'2\b\u0010,\u001a\u0004\u0018\u00010-H\u0016J\b\u00101\u001a\u00020\u001aH\u0002J\b\u00102\u001a\u00020\u001aH\u0002J\b\u00103\u001a\u00020\u001aH\u0002J\u0016\u00104\u001a\u00020\u001a2\f\u00105\u001a\b\u0012\u0004\u0012\u00020706H\u0002J\u001b\u00108\u001a\u00020\u001a2\f\u00109\u001a\b\u0012\u0004\u0012\u00020\u00150:H\u0002\u00a2\u0006\u0002\u0010;J\u0016\u0010<\u001a\u00020\u001a2\f\u0010=\u001a\b\u0012\u0004\u0012\u00020\u001506H\u0002J\b\u0010>\u001a\u00020\u001aH\u0002J\b\u0010?\u001a\u00020\u001aH\u0002R\u0010\u0010\u0003\u001a\u0004\u0018\u00010\u0004X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u001b\u0010\u0005\u001a\u00020\u00068BX\u0082\u0084\u0002\u00a2\u0006\f\n\u0004\b\t\u0010\n\u001a\u0004\b\u0007\u0010\bR\u0014\u0010\u000b\u001a\u00020\u00048BX\u0082\u0004\u00a2\u0006\u0006\u001a\u0004\b\f\u0010\rR\u0016\u0010\u000e\u001a\n \u0010*\u0004\u0018\u00010\u000f0\u000fX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0011\u001a\u00020\u0012X\u0082.\u00a2\u0006\u0002\n\u0000R\u001a\u0010\u0013\u001a\u000e\u0012\u0004\u0012\u00020\u0015\u0012\u0004\u0012\u00020\u00160\u0014X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0017\u001a\u00020\u0018X\u0082.\u00a2\u0006\u0002\n\u0000\u00a8\u0006@"}, d2 = {"Lcom/example/gestaobilhares/ui/settlement/SettlementFragment;", "Landroidx/fragment/app/Fragment;", "()V", "_binding", "Lcom/example/gestaobilhares/databinding/FragmentSettlementBinding;", "args", "Lcom/example/gestaobilhares/ui/settlement/SettlementFragmentArgs;", "getArgs", "()Lcom/example/gestaobilhares/ui/settlement/SettlementFragmentArgs;", "args$delegate", "Landroidx/navigation/NavArgsLazy;", "binding", "getBinding", "()Lcom/example/gestaobilhares/databinding/FragmentSettlementBinding;", "formatter", "Ljava/text/NumberFormat;", "kotlin.jvm.PlatformType", "mesasAcertoAdapter", "Lcom/example/gestaobilhares/ui/settlement/MesasAcertoAdapter;", "paymentValues", "", "", "", "viewModel", "Lcom/example/gestaobilhares/ui/settlement/SettlementViewModel;", "carregarDadosClienteESincronizar", "", "carregarMesasFallback", "cliente", "Lcom/example/gestaobilhares/data/entities/Cliente;", "(Lcom/example/gestaobilhares/data/entities/Cliente;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "configurarUIBasica", "forceUpdateCalculations", "mostrarAlertaRotaNaoIniciada", "mostrarDialogoResumoComAcerto", "acertoId", "", "observeViewModel", "onCreateView", "Landroid/view/View;", "inflater", "Landroid/view/LayoutInflater;", "container", "Landroid/view/ViewGroup;", "savedInstanceState", "Landroid/os/Bundle;", "onDestroyView", "onViewCreated", "view", "salvarAcertoComCamposExtras", "setupCalculationListeners", "setupPaymentMethod", "setupRecyclerViewComDados", "mesasDTO", "", "Lcom/example/gestaobilhares/ui/settlement/MesaDTO;", "showPaymentMethodsDialog", "paymentMethods", "", "([Ljava/lang/String;)V", "showPaymentValuesDialog", "selected", "updateCalculations", "verificarPermissaoAcerto", "app_debug"})
public final class SettlementFragment extends androidx.fragment.app.Fragment {
    @org.jetbrains.annotations.Nullable()
    private com.example.gestaobilhares.databinding.FragmentSettlementBinding _binding;
    private com.example.gestaobilhares.ui.settlement.SettlementViewModel viewModel;
    @org.jetbrains.annotations.NotNull()
    private final androidx.navigation.NavArgsLazy args$delegate = null;
    private final java.text.NumberFormat formatter = null;
    private com.example.gestaobilhares.ui.settlement.MesasAcertoAdapter mesasAcertoAdapter;
    @org.jetbrains.annotations.NotNull()
    private java.util.Map<java.lang.String, java.lang.Double> paymentValues;
    
    public SettlementFragment() {
        super();
    }
    
    private final com.example.gestaobilhares.databinding.FragmentSettlementBinding getBinding() {
        return null;
    }
    
    private final com.example.gestaobilhares.ui.settlement.SettlementFragmentArgs getArgs() {
        return null;
    }
    
    @java.lang.Override()
    @org.jetbrains.annotations.NotNull()
    public android.view.View onCreateView(@org.jetbrains.annotations.NotNull()
    android.view.LayoutInflater inflater, @org.jetbrains.annotations.Nullable()
    android.view.ViewGroup container, @org.jetbrains.annotations.Nullable()
    android.os.Bundle savedInstanceState) {
        return null;
    }
    
    @java.lang.Override()
    public void onViewCreated(@org.jetbrains.annotations.NotNull()
    android.view.View view, @org.jetbrains.annotations.Nullable()
    android.os.Bundle savedInstanceState) {
    }
    
    private final void verificarPermissaoAcerto() {
    }
    
    private final void mostrarAlertaRotaNaoIniciada() {
    }
    
    private final void carregarDadosClienteESincronizar() {
    }
    
    /**
     * ✅ FUNÇÃO FALLBACK: Carrega mesas quando o Flow falha
     */
    private final java.lang.Object carregarMesasFallback(com.example.gestaobilhares.data.entities.Cliente cliente, kotlin.coroutines.Continuation<? super kotlin.Unit> $completion) {
        return null;
    }
    
    private final void configurarUIBasica() {
    }
    
    private final void setupRecyclerViewComDados(java.util.List<com.example.gestaobilhares.ui.settlement.MesaDTO> mesasDTO) {
    }
    
    private final void setupCalculationListeners() {
    }
    
    private final void updateCalculations() {
    }
    
    /**
     * Força a atualização dos cálculos com validação extra
     */
    private final void forceUpdateCalculations() {
    }
    
    private final void setupPaymentMethod() {
    }
    
    private final void showPaymentMethodsDialog(java.lang.String[] paymentMethods) {
    }
    
    private final void showPaymentValuesDialog(java.util.List<java.lang.String> selected) {
    }
    
    private final void salvarAcertoComCamposExtras() {
    }
    
    private final void observeViewModel() {
    }
    
    private final void mostrarDialogoResumoComAcerto(long acertoId) {
    }
    
    @java.lang.Override()
    public void onDestroyView() {
    }
}