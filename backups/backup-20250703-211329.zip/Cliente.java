package com.example.gestaobilhares.data.entities;

/**
 * Entidade que representa um Cliente no banco de dados.
 * Clientes são estabelecimentos que alugam mesas de sinuca.
 */
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u00008\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0010\u000e\n\u0002\b\n\n\u0002\u0010\u0006\n\u0002\b\u0005\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b3\n\u0002\u0010\b\n\u0002\b\u0002\b\u0087\b\u0018\u00002\u00020\u0001B\u00dd\u0001\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\n\b\u0002\u0010\u0006\u001a\u0004\u0018\u00010\u0005\u0012\n\b\u0002\u0010\u0007\u001a\u0004\u0018\u00010\u0005\u0012\n\b\u0002\u0010\b\u001a\u0004\u0018\u00010\u0005\u0012\n\b\u0002\u0010\t\u001a\u0004\u0018\u00010\u0005\u0012\n\b\u0002\u0010\n\u001a\u0004\u0018\u00010\u0005\u0012\n\b\u0002\u0010\u000b\u001a\u0004\u0018\u00010\u0005\u0012\n\b\u0002\u0010\f\u001a\u0004\u0018\u00010\u0005\u0012\n\b\u0002\u0010\r\u001a\u0004\u0018\u00010\u0005\u0012\u0006\u0010\u000e\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u000f\u001a\u00020\u0010\u0012\b\b\u0002\u0010\u0011\u001a\u00020\u0010\u0012\n\b\u0002\u0010\u0012\u001a\u0004\u0018\u00010\u0005\u0012\b\b\u0002\u0010\u0013\u001a\u00020\u0010\u0012\b\b\u0002\u0010\u0014\u001a\u00020\u0010\u0012\b\b\u0002\u0010\u0015\u001a\u00020\u0016\u0012\n\b\u0002\u0010\u0017\u001a\u0004\u0018\u00010\u0005\u0012\b\b\u0002\u0010\u0018\u001a\u00020\u0019\u0012\b\b\u0002\u0010\u001a\u001a\u00020\u0019\u00a2\u0006\u0002\u0010\u001bJ\t\u00105\u001a\u00020\u0003H\u00c6\u0003J\u000b\u00106\u001a\u0004\u0018\u00010\u0005H\u00c6\u0003J\t\u00107\u001a\u00020\u0003H\u00c6\u0003J\t\u00108\u001a\u00020\u0010H\u00c6\u0003J\t\u00109\u001a\u00020\u0010H\u00c6\u0003J\u000b\u0010:\u001a\u0004\u0018\u00010\u0005H\u00c6\u0003J\t\u0010;\u001a\u00020\u0010H\u00c6\u0003J\t\u0010<\u001a\u00020\u0010H\u00c6\u0003J\t\u0010=\u001a\u00020\u0016H\u00c6\u0003J\u000b\u0010>\u001a\u0004\u0018\u00010\u0005H\u00c6\u0003J\t\u0010?\u001a\u00020\u0019H\u00c6\u0003J\t\u0010@\u001a\u00020\u0005H\u00c6\u0003J\t\u0010A\u001a\u00020\u0019H\u00c6\u0003J\u000b\u0010B\u001a\u0004\u0018\u00010\u0005H\u00c6\u0003J\u000b\u0010C\u001a\u0004\u0018\u00010\u0005H\u00c6\u0003J\u000b\u0010D\u001a\u0004\u0018\u00010\u0005H\u00c6\u0003J\u000b\u0010E\u001a\u0004\u0018\u00010\u0005H\u00c6\u0003J\u000b\u0010F\u001a\u0004\u0018\u00010\u0005H\u00c6\u0003J\u000b\u0010G\u001a\u0004\u0018\u00010\u0005H\u00c6\u0003J\u000b\u0010H\u001a\u0004\u0018\u00010\u0005H\u00c6\u0003J\u00e5\u0001\u0010I\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\n\b\u0002\u0010\u0006\u001a\u0004\u0018\u00010\u00052\n\b\u0002\u0010\u0007\u001a\u0004\u0018\u00010\u00052\n\b\u0002\u0010\b\u001a\u0004\u0018\u00010\u00052\n\b\u0002\u0010\t\u001a\u0004\u0018\u00010\u00052\n\b\u0002\u0010\n\u001a\u0004\u0018\u00010\u00052\n\b\u0002\u0010\u000b\u001a\u0004\u0018\u00010\u00052\n\b\u0002\u0010\f\u001a\u0004\u0018\u00010\u00052\n\b\u0002\u0010\r\u001a\u0004\u0018\u00010\u00052\b\b\u0002\u0010\u000e\u001a\u00020\u00032\b\b\u0002\u0010\u000f\u001a\u00020\u00102\b\b\u0002\u0010\u0011\u001a\u00020\u00102\n\b\u0002\u0010\u0012\u001a\u0004\u0018\u00010\u00052\b\b\u0002\u0010\u0013\u001a\u00020\u00102\b\b\u0002\u0010\u0014\u001a\u00020\u00102\b\b\u0002\u0010\u0015\u001a\u00020\u00162\n\b\u0002\u0010\u0017\u001a\u0004\u0018\u00010\u00052\b\b\u0002\u0010\u0018\u001a\u00020\u00192\b\b\u0002\u0010\u001a\u001a\u00020\u0019H\u00c6\u0001J\u0013\u0010J\u001a\u00020\u00162\b\u0010K\u001a\u0004\u0018\u00010\u0001H\u00d6\u0003J\t\u0010L\u001a\u00020MH\u00d6\u0001J\t\u0010N\u001a\u00020\u0005H\u00d6\u0001R\u0016\u0010\u0015\u001a\u00020\u00168\u0006X\u0087\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001c\u0010\u001dR\u0018\u0010\r\u001a\u0004\u0018\u00010\u00058\u0006X\u0087\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001e\u0010\u001fR\u0018\u0010\u000b\u001a\u0004\u0018\u00010\u00058\u0006X\u0087\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b \u0010\u001fR\u0018\u0010\u0007\u001a\u0004\u0018\u00010\u00058\u0006X\u0087\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b!\u0010\u001fR\u0016\u0010\u0011\u001a\u00020\u00108\u0006X\u0087\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\"\u0010#R\u0016\u0010\u0018\u001a\u00020\u00198\u0006X\u0087\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b$\u0010%R\u0016\u0010\u001a\u001a\u00020\u00198\u0006X\u0087\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b&\u0010%R\u0016\u0010\u0013\u001a\u00020\u00108\u0006X\u0087\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\'\u0010#R\u0016\u0010\u0014\u001a\u00020\u00108\u0006X\u0087\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b(\u0010#R\u0018\u0010\t\u001a\u0004\u0018\u00010\u00058\u0006X\u0087\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b)\u0010\u001fR\u0018\u0010\n\u001a\u0004\u0018\u00010\u00058\u0006X\u0087\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b*\u0010\u001fR\u0018\u0010\f\u001a\u0004\u0018\u00010\u00058\u0006X\u0087\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b+\u0010\u001fR\u0016\u0010\u0002\u001a\u00020\u00038\u0006X\u0087\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b,\u0010-R\u0016\u0010\u0004\u001a\u00020\u00058\u0006X\u0087\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b.\u0010\u001fR\u0018\u0010\u0006\u001a\u0004\u0018\u00010\u00058\u0006X\u0087\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b/\u0010\u001fR\u0018\u0010\u0012\u001a\u0004\u0018\u00010\u00058\u0006X\u0087\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b0\u0010\u001fR\u0018\u0010\u0017\u001a\u0004\u0018\u00010\u00058\u0006X\u0087\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b1\u0010\u001fR\u0016\u0010\u000e\u001a\u00020\u00038\u0006X\u0087\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b2\u0010-R\u0018\u0010\b\u001a\u0004\u0018\u00010\u00058\u0006X\u0087\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b3\u0010\u001fR\u0016\u0010\u000f\u001a\u00020\u00108\u0006X\u0087\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b4\u0010#\u00a8\u0006O"}, d2 = {"Lcom/example/gestaobilhares/data/entities/Cliente;", "", "id", "", "nome", "", "nomeFantasia", "cnpj", "telefone", "email", "endereco", "cidade", "estado", "cep", "rotaId", "valorFicha", "", "comissaoFicha", "numeroContrato", "debitoAnterior", "debitoAtual", "ativo", "", "observacoes", "dataCadastro", "Ljava/util/Date;", "dataUltimaAtualizacao", "(JLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;JDDLjava/lang/String;DDZLjava/lang/String;Ljava/util/Date;Ljava/util/Date;)V", "getAtivo", "()Z", "getCep", "()Ljava/lang/String;", "getCidade", "getCnpj", "getComissaoFicha", "()D", "getDataCadastro", "()Ljava/util/Date;", "getDataUltimaAtualizacao", "getDebitoAnterior", "getDebitoAtual", "getEmail", "getEndereco", "getEstado", "getId", "()J", "getNome", "getNomeFantasia", "getNumeroContrato", "getObservacoes", "getRotaId", "getTelefone", "getValorFicha", "component1", "component10", "component11", "component12", "component13", "component14", "component15", "component16", "component17", "component18", "component19", "component2", "component20", "component3", "component4", "component5", "component6", "component7", "component8", "component9", "copy", "equals", "other", "hashCode", "", "toString", "app_debug"})
@androidx.room.Entity(tableName = "clientes", foreignKeys = {@androidx.room.ForeignKey(entity = com.example.gestaobilhares.data.entities.Rota.class, parentColumns = {"id"}, childColumns = {"rota_id"}, onDelete = 5)}, indices = {@androidx.room.Index(value = {"rota_id"})})
public final class Cliente {
    @androidx.room.PrimaryKey(autoGenerate = true)
    private final long id = 0L;
    @androidx.room.ColumnInfo(name = "nome")
    @org.jetbrains.annotations.NotNull()
    private final java.lang.String nome = null;
    @androidx.room.ColumnInfo(name = "nome_fantasia")
    @org.jetbrains.annotations.Nullable()
    private final java.lang.String nomeFantasia = null;
    @androidx.room.ColumnInfo(name = "cnpj")
    @org.jetbrains.annotations.Nullable()
    private final java.lang.String cnpj = null;
    @androidx.room.ColumnInfo(name = "telefone")
    @org.jetbrains.annotations.Nullable()
    private final java.lang.String telefone = null;
    @androidx.room.ColumnInfo(name = "email")
    @org.jetbrains.annotations.Nullable()
    private final java.lang.String email = null;
    @androidx.room.ColumnInfo(name = "endereco")
    @org.jetbrains.annotations.Nullable()
    private final java.lang.String endereco = null;
    @androidx.room.ColumnInfo(name = "cidade")
    @org.jetbrains.annotations.Nullable()
    private final java.lang.String cidade = null;
    @androidx.room.ColumnInfo(name = "estado")
    @org.jetbrains.annotations.Nullable()
    private final java.lang.String estado = null;
    @androidx.room.ColumnInfo(name = "cep")
    @org.jetbrains.annotations.Nullable()
    private final java.lang.String cep = null;
    @androidx.room.ColumnInfo(name = "rota_id")
    private final long rotaId = 0L;
    @androidx.room.ColumnInfo(name = "valor_ficha")
    private final double valorFicha = 0.0;
    @androidx.room.ColumnInfo(name = "comissao_ficha")
    private final double comissaoFicha = 0.0;
    @androidx.room.ColumnInfo(name = "numero_contrato")
    @org.jetbrains.annotations.Nullable()
    private final java.lang.String numeroContrato = null;
    @androidx.room.ColumnInfo(name = "debito_anterior")
    private final double debitoAnterior = 0.0;
    @androidx.room.ColumnInfo(name = "debito_atual")
    private final double debitoAtual = 0.0;
    @androidx.room.ColumnInfo(name = "ativo")
    private final boolean ativo = false;
    @androidx.room.ColumnInfo(name = "observacoes")
    @org.jetbrains.annotations.Nullable()
    private final java.lang.String observacoes = null;
    @androidx.room.ColumnInfo(name = "data_cadastro")
    @org.jetbrains.annotations.NotNull()
    private final java.util.Date dataCadastro = null;
    @androidx.room.ColumnInfo(name = "data_ultima_atualizacao")
    @org.jetbrains.annotations.NotNull()
    private final java.util.Date dataUltimaAtualizacao = null;
    
    public Cliente(long id, @org.jetbrains.annotations.NotNull()
    java.lang.String nome, @org.jetbrains.annotations.Nullable()
    java.lang.String nomeFantasia, @org.jetbrains.annotations.Nullable()
    java.lang.String cnpj, @org.jetbrains.annotations.Nullable()
    java.lang.String telefone, @org.jetbrains.annotations.Nullable()
    java.lang.String email, @org.jetbrains.annotations.Nullable()
    java.lang.String endereco, @org.jetbrains.annotations.Nullable()
    java.lang.String cidade, @org.jetbrains.annotations.Nullable()
    java.lang.String estado, @org.jetbrains.annotations.Nullable()
    java.lang.String cep, long rotaId, double valorFicha, double comissaoFicha, @org.jetbrains.annotations.Nullable()
    java.lang.String numeroContrato, double debitoAnterior, double debitoAtual, boolean ativo, @org.jetbrains.annotations.Nullable()
    java.lang.String observacoes, @org.jetbrains.annotations.NotNull()
    java.util.Date dataCadastro, @org.jetbrains.annotations.NotNull()
    java.util.Date dataUltimaAtualizacao) {
        super();
    }
    
    public final long getId() {
        return 0L;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.lang.String getNome() {
        return null;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.lang.String getNomeFantasia() {
        return null;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.lang.String getCnpj() {
        return null;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.lang.String getTelefone() {
        return null;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.lang.String getEmail() {
        return null;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.lang.String getEndereco() {
        return null;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.lang.String getCidade() {
        return null;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.lang.String getEstado() {
        return null;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.lang.String getCep() {
        return null;
    }
    
    public final long getRotaId() {
        return 0L;
    }
    
    public final double getValorFicha() {
        return 0.0;
    }
    
    public final double getComissaoFicha() {
        return 0.0;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.lang.String getNumeroContrato() {
        return null;
    }
    
    public final double getDebitoAnterior() {
        return 0.0;
    }
    
    public final double getDebitoAtual() {
        return 0.0;
    }
    
    public final boolean getAtivo() {
        return false;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.lang.String getObservacoes() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.util.Date getDataCadastro() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.util.Date getDataUltimaAtualizacao() {
        return null;
    }
    
    public final long component1() {
        return 0L;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.lang.String component10() {
        return null;
    }
    
    public final long component11() {
        return 0L;
    }
    
    public final double component12() {
        return 0.0;
    }
    
    public final double component13() {
        return 0.0;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.lang.String component14() {
        return null;
    }
    
    public final double component15() {
        return 0.0;
    }
    
    public final double component16() {
        return 0.0;
    }
    
    public final boolean component17() {
        return false;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.lang.String component18() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.util.Date component19() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.lang.String component2() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.util.Date component20() {
        return null;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.lang.String component3() {
        return null;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.lang.String component4() {
        return null;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.lang.String component5() {
        return null;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.lang.String component6() {
        return null;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.lang.String component7() {
        return null;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.lang.String component8() {
        return null;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.lang.String component9() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.example.gestaobilhares.data.entities.Cliente copy(long id, @org.jetbrains.annotations.NotNull()
    java.lang.String nome, @org.jetbrains.annotations.Nullable()
    java.lang.String nomeFantasia, @org.jetbrains.annotations.Nullable()
    java.lang.String cnpj, @org.jetbrains.annotations.Nullable()
    java.lang.String telefone, @org.jetbrains.annotations.Nullable()
    java.lang.String email, @org.jetbrains.annotations.Nullable()
    java.lang.String endereco, @org.jetbrains.annotations.Nullable()
    java.lang.String cidade, @org.jetbrains.annotations.Nullable()
    java.lang.String estado, @org.jetbrains.annotations.Nullable()
    java.lang.String cep, long rotaId, double valorFicha, double comissaoFicha, @org.jetbrains.annotations.Nullable()
    java.lang.String numeroContrato, double debitoAnterior, double debitoAtual, boolean ativo, @org.jetbrains.annotations.Nullable()
    java.lang.String observacoes, @org.jetbrains.annotations.NotNull()
    java.util.Date dataCadastro, @org.jetbrains.annotations.NotNull()
    java.util.Date dataUltimaAtualizacao) {
        return null;
    }
    
    @java.lang.Override()
    public boolean equals(@org.jetbrains.annotations.Nullable()
    java.lang.Object other) {
        return false;
    }
    
    @java.lang.Override()
    public int hashCode() {
        return 0;
    }
    
    @java.lang.Override()
    @org.jetbrains.annotations.NotNull()
    public java.lang.String toString() {
        return null;
    }
}