package com.example.gestaobilhares.data.repository;

@javax.inject.Singleton()
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000:\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010 \n\u0000\n\u0002\u0010\t\n\u0002\b\u0005\n\u0002\u0010\b\n\u0002\b\b\b\u0007\u0018\u00002\u00020\u0001B\u000f\b\u0007\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0002\u0010\u0004J\u0016\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\bH\u0086@\u00a2\u0006\u0002\u0010\tJ\u001a\u0010\n\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\b0\f0\u000b2\u0006\u0010\r\u001a\u00020\u000eJ\u001c\u0010\u000f\u001a\b\u0012\u0004\u0012\u00020\b0\f2\u0006\u0010\r\u001a\u00020\u000eH\u0086@\u00a2\u0006\u0002\u0010\u0010J\u001a\u0010\u0011\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\b0\f0\u000b2\u0006\u0010\u0012\u001a\u00020\u000eJ\u0018\u0010\u0013\u001a\u0004\u0018\u00010\u00142\u0006\u0010\u0012\u001a\u00020\u000eH\u0086@\u00a2\u0006\u0002\u0010\u0010J\u0018\u0010\u0015\u001a\u0004\u0018\u00010\b2\u0006\u0010\u0012\u001a\u00020\u000eH\u0086@\u00a2\u0006\u0002\u0010\u0010J\u0016\u0010\u0016\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\bH\u0086@\u00a2\u0006\u0002\u0010\tJ\u0016\u0010\u0017\u001a\u00020\u00062\u0006\u0010\r\u001a\u00020\u000eH\u0086@\u00a2\u0006\u0002\u0010\u0010J\u0016\u0010\u0018\u001a\u00020\u000e2\u0006\u0010\u0007\u001a\u00020\bH\u0086@\u00a2\u0006\u0002\u0010\tJ\u001c\u0010\u0019\u001a\u00020\u00062\f\u0010\u001a\u001a\b\u0012\u0004\u0012\u00020\b0\fH\u0086@\u00a2\u0006\u0002\u0010\u001bR\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u001c"}, d2 = {"Lcom/example/gestaobilhares/data/repository/AcertoMesaRepository;", "", "acertoMesaDao", "Lcom/example/gestaobilhares/data/dao/AcertoMesaDao;", "(Lcom/example/gestaobilhares/data/dao/AcertoMesaDao;)V", "atualizar", "", "acertoMesa", "Lcom/example/gestaobilhares/data/entities/AcertoMesa;", "(Lcom/example/gestaobilhares/data/entities/AcertoMesa;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "buscarPorAcerto", "Lkotlinx/coroutines/flow/Flow;", "", "acertoId", "", "buscarPorAcertoId", "(JLkotlin/coroutines/Continuation;)Ljava/lang/Object;", "buscarPorMesa", "mesaId", "buscarRelogioFinalUltimoAcerto", "", "buscarUltimoAcertoMesa", "deletar", "deletarPorAcerto", "inserir", "inserirLista", "acertoMesas", "(Ljava/util/List;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "app_debug"})
public final class AcertoMesaRepository {
    @org.jetbrains.annotations.NotNull()
    private final com.example.gestaobilhares.data.dao.AcertoMesaDao acertoMesaDao = null;
    
    @javax.inject.Inject()
    public AcertoMesaRepository(@org.jetbrains.annotations.NotNull()
    com.example.gestaobilhares.data.dao.AcertoMesaDao acertoMesaDao) {
        super();
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.lang.Object inserir(@org.jetbrains.annotations.NotNull()
    com.example.gestaobilhares.data.entities.AcertoMesa acertoMesa, @org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super java.lang.Long> $completion) {
        return null;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.lang.Object inserirLista(@org.jetbrains.annotations.NotNull()
    java.util.List<com.example.gestaobilhares.data.entities.AcertoMesa> acertoMesas, @org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super kotlin.Unit> $completion) {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final kotlinx.coroutines.flow.Flow<java.util.List<com.example.gestaobilhares.data.entities.AcertoMesa>> buscarPorAcerto(long acertoId) {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final kotlinx.coroutines.flow.Flow<java.util.List<com.example.gestaobilhares.data.entities.AcertoMesa>> buscarPorMesa(long mesaId) {
        return null;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.lang.Object buscarUltimoAcertoMesa(long mesaId, @org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super com.example.gestaobilhares.data.entities.AcertoMesa> $completion) {
        return null;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.lang.Object buscarPorAcertoId(long acertoId, @org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super java.util.List<com.example.gestaobilhares.data.entities.AcertoMesa>> $completion) {
        return null;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.lang.Object atualizar(@org.jetbrains.annotations.NotNull()
    com.example.gestaobilhares.data.entities.AcertoMesa acertoMesa, @org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super kotlin.Unit> $completion) {
        return null;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.lang.Object deletar(@org.jetbrains.annotations.NotNull()
    com.example.gestaobilhares.data.entities.AcertoMesa acertoMesa, @org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super kotlin.Unit> $completion) {
        return null;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.lang.Object deletarPorAcerto(long acertoId, @org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super kotlin.Unit> $completion) {
        return null;
    }
    
    /**
     * Busca o relógio final do último acerto de uma mesa específica
     * @param mesaId ID da mesa
     * @return Relógio final do último acerto, ou null se não houver acertos anteriores
     */
    @org.jetbrains.annotations.Nullable()
    public final java.lang.Object buscarRelogioFinalUltimoAcerto(long mesaId, @org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super java.lang.Integer> $completion) {
        return null;
    }
}