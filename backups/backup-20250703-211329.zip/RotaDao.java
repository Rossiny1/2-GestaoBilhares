package com.example.gestaobilhares.data.dao;

/**
 * DAO (Data Access Object) para operações com a entidade Rota.
 * Define todas as operações de banco de dados relacionadas às rotas.
 */
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000<\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\t\n\u0002\b\u0004\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0018\u0002\n\u0002\u0010 \n\u0002\b\u0010\bg\u0018\u00002\u00020\u0001J \u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u0005H\u00a7@\u00a2\u0006\u0002\u0010\u0007J(\u0010\b\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u00052\u0006\u0010\t\u001a\u00020\n2\b\b\u0002\u0010\u0006\u001a\u00020\u0005H\u00a7@\u00a2\u0006\u0002\u0010\u000bJ(\u0010\f\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u00052\u0006\u0010\r\u001a\u00020\u000e2\b\b\u0002\u0010\u0006\u001a\u00020\u0005H\u00a7@\u00a2\u0006\u0002\u0010\u000fJ\u000e\u0010\u0010\u001a\u00020\nH\u00a7@\u00a2\u0006\u0002\u0010\u0011J\u0016\u0010\u0012\u001a\u00020\u00032\u0006\u0010\u0013\u001a\u00020\u0014H\u00a7@\u00a2\u0006\u0002\u0010\u0015J \u0010\u0016\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u0005H\u00a7@\u00a2\u0006\u0002\u0010\u0007J \u0010\u0017\u001a\u00020\n2\u0006\u0010\u0018\u001a\u00020\u000e2\b\b\u0002\u0010\u0019\u001a\u00020\u0005H\u00a7@\u00a2\u0006\u0002\u0010\u001aJ(\u0010\u001b\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u001c\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u0005H\u00a7@\u00a2\u0006\u0002\u0010\u001dJ\u0014\u0010\u001e\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00140 0\u001fH\'J\u0014\u0010!\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00140 0\u001fH\'J\u0018\u0010\"\u001a\u0004\u0018\u00010\u00142\u0006\u0010\u0004\u001a\u00020\u0005H\u00a7@\u00a2\u0006\u0002\u0010#J\u0018\u0010$\u001a\u0004\u0018\u00010\u00142\u0006\u0010\u0018\u001a\u00020\u000eH\u00a7@\u00a2\u0006\u0002\u0010%J0\u0010&\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u00052\u0006\u0010\t\u001a\u00020\n2\u0006\u0010\'\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u0005H\u00a7@\u00a2\u0006\u0002\u0010(J\u0016\u0010)\u001a\u00020\u00052\u0006\u0010\u0013\u001a\u00020\u0014H\u00a7@\u00a2\u0006\u0002\u0010\u0015J\"\u0010*\u001a\b\u0012\u0004\u0012\u00020\u00050 2\f\u0010+\u001a\b\u0012\u0004\u0012\u00020\u00140 H\u00a7@\u00a2\u0006\u0002\u0010,J\u0018\u0010-\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00140\u001f2\u0006\u0010\u0004\u001a\u00020\u0005H\'J\u0016\u0010.\u001a\u00020\u00032\u0006\u0010\u0013\u001a\u00020\u0014H\u00a7@\u00a2\u0006\u0002\u0010\u0015J\u001c\u0010/\u001a\u00020\u00032\f\u0010+\u001a\b\u0012\u0004\u0012\u00020\u00140 H\u00a7@\u00a2\u0006\u0002\u0010,\u00a8\u00060"}, d2 = {"Lcom/example/gestaobilhares/data/dao/RotaDao;", "", "ativarRota", "", "rotaId", "", "timestamp", "(JJLkotlin/coroutines/Continuation;)Ljava/lang/Object;", "atualizarCicloAcerto", "ciclo", "", "(JIJLkotlin/coroutines/Continuation;)Ljava/lang/Object;", "atualizarStatus", "status", "", "(JLjava/lang/String;JLkotlin/coroutines/Continuation;)Ljava/lang/Object;", "contarRotasAtivas", "(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "deleteRota", "rota", "Lcom/example/gestaobilhares/data/entities/Rota;", "(Lcom/example/gestaobilhares/data/entities/Rota;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "desativarRota", "existeRotaComNome", "nome", "excludeId", "(Ljava/lang/String;JLkotlin/coroutines/Continuation;)Ljava/lang/Object;", "finalizarCicloRota", "dataFim", "(JJJLkotlin/coroutines/Continuation;)Ljava/lang/Object;", "getAllRotas", "Lkotlinx/coroutines/flow/Flow;", "", "getAllRotasAtivas", "getRotaById", "(JLkotlin/coroutines/Continuation;)Ljava/lang/Object;", "getRotaByNome", "(Ljava/lang/String;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "iniciarCicloRota", "dataInicio", "(JIJJLkotlin/coroutines/Continuation;)Ljava/lang/Object;", "insertRota", "insertRotas", "rotas", "(Ljava/util/List;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "obterRotaPorId", "updateRota", "updateRotas", "app_debug"})
@androidx.room.Dao()
public abstract interface RotaDao {
    
    /**
     * Obtém todas as rotas ativas ordenadas por nome.
     * Retorna um Flow para observar mudanças em tempo real.
     */
    @androidx.room.Query(value = "SELECT * FROM rotas WHERE ativa = 1 ORDER BY nome ASC")
    @org.jetbrains.annotations.NotNull()
    public abstract kotlinx.coroutines.flow.Flow<java.util.List<com.example.gestaobilhares.data.entities.Rota>> getAllRotasAtivas();
    
    /**
     * Obtém todas as rotas (ativas e inativas) ordenadas por nome.
     */
    @androidx.room.Query(value = "SELECT * FROM rotas ORDER BY nome ASC")
    @org.jetbrains.annotations.NotNull()
    public abstract kotlinx.coroutines.flow.Flow<java.util.List<com.example.gestaobilhares.data.entities.Rota>> getAllRotas();
    
    /**
     * Obtém uma rota específica por ID.
     */
    @androidx.room.Query(value = "SELECT * FROM rotas WHERE id = :rotaId")
    @org.jetbrains.annotations.Nullable()
    public abstract java.lang.Object getRotaById(long rotaId, @org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super com.example.gestaobilhares.data.entities.Rota> $completion);
    
    /**
     * Obtém uma rota específica por ID como Flow.
     */
    @androidx.room.Query(value = "SELECT * FROM rotas WHERE id = :rotaId")
    @org.jetbrains.annotations.NotNull()
    public abstract kotlinx.coroutines.flow.Flow<com.example.gestaobilhares.data.entities.Rota> obterRotaPorId(long rotaId);
    
    /**
     * Obtém uma rota por nome (útil para validação).
     */
    @androidx.room.Query(value = "SELECT * FROM rotas WHERE nome = :nome LIMIT 1")
    @org.jetbrains.annotations.Nullable()
    public abstract java.lang.Object getRotaByNome(@org.jetbrains.annotations.NotNull()
    java.lang.String nome, @org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super com.example.gestaobilhares.data.entities.Rota> $completion);
    
    /**
     * Insere uma nova rota no banco de dados.
     * @return O ID da rota inserida
     */
    @androidx.room.Insert(onConflict = 3)
    @org.jetbrains.annotations.Nullable()
    public abstract java.lang.Object insertRota(@org.jetbrains.annotations.NotNull()
    com.example.gestaobilhares.data.entities.Rota rota, @org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super java.lang.Long> $completion);
    
    /**
     * Insere múltiplas rotas de uma vez.
     */
    @androidx.room.Insert(onConflict = 3)
    @org.jetbrains.annotations.Nullable()
    public abstract java.lang.Object insertRotas(@org.jetbrains.annotations.NotNull()
    java.util.List<com.example.gestaobilhares.data.entities.Rota> rotas, @org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super java.util.List<java.lang.Long>> $completion);
    
    /**
     * Atualiza uma rota existente.
     */
    @androidx.room.Update()
    @org.jetbrains.annotations.Nullable()
    public abstract java.lang.Object updateRota(@org.jetbrains.annotations.NotNull()
    com.example.gestaobilhares.data.entities.Rota rota, @org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super kotlin.Unit> $completion);
    
    /**
     * Atualiza múltiplas rotas.
     */
    @androidx.room.Update()
    @org.jetbrains.annotations.Nullable()
    public abstract java.lang.Object updateRotas(@org.jetbrains.annotations.NotNull()
    java.util.List<com.example.gestaobilhares.data.entities.Rota> rotas, @org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super kotlin.Unit> $completion);
    
    /**
     * Deleta uma rota específica.
     */
    @androidx.room.Delete()
    @org.jetbrains.annotations.Nullable()
    public abstract java.lang.Object deleteRota(@org.jetbrains.annotations.NotNull()
    com.example.gestaobilhares.data.entities.Rota rota, @org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super kotlin.Unit> $completion);
    
    /**
     * Desativa uma rota (soft delete) ao invés de deletá-la.
     */
    @androidx.room.Query(value = "UPDATE rotas SET ativa = 0, data_atualizacao = :timestamp WHERE id = :rotaId")
    @org.jetbrains.annotations.Nullable()
    public abstract java.lang.Object desativarRota(long rotaId, long timestamp, @org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super kotlin.Unit> $completion);
    
    /**
     * Ativa uma rota novamente.
     */
    @androidx.room.Query(value = "UPDATE rotas SET ativa = 1, data_atualizacao = :timestamp WHERE id = :rotaId")
    @org.jetbrains.annotations.Nullable()
    public abstract java.lang.Object ativarRota(long rotaId, long timestamp, @org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super kotlin.Unit> $completion);
    
    /**
     * Atualiza o status da rota.
     */
    @androidx.room.Query(value = "UPDATE rotas SET status_atual = :status, data_atualizacao = :timestamp WHERE id = :rotaId")
    @org.jetbrains.annotations.Nullable()
    public abstract java.lang.Object atualizarStatus(long rotaId, @org.jetbrains.annotations.NotNull()
    java.lang.String status, long timestamp, @org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super kotlin.Unit> $completion);
    
    /**
     * Atualiza o ciclo de acerto da rota.
     */
    @androidx.room.Query(value = "UPDATE rotas SET ciclo_acerto_atual = :ciclo, data_atualizacao = :timestamp WHERE id = :rotaId")
    @org.jetbrains.annotations.Nullable()
    public abstract java.lang.Object atualizarCicloAcerto(long rotaId, int ciclo, long timestamp, @org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super kotlin.Unit> $completion);
    
    /**
     * Inicia um novo ciclo para a rota.
     */
    @androidx.room.Query(value = "UPDATE rotas SET status_atual = \'EM_ANDAMENTO\', ciclo_acerto_atual = :ciclo, data_inicio_ciclo = :dataInicio, data_atualizacao = :timestamp WHERE id = :rotaId")
    @org.jetbrains.annotations.Nullable()
    public abstract java.lang.Object iniciarCicloRota(long rotaId, int ciclo, long dataInicio, long timestamp, @org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super kotlin.Unit> $completion);
    
    /**
     * Finaliza o ciclo atual da rota.
     */
    @androidx.room.Query(value = "UPDATE rotas SET status_atual = \'FINALIZADA\', data_fim_ciclo = :dataFim, data_atualizacao = :timestamp WHERE id = :rotaId")
    @org.jetbrains.annotations.Nullable()
    public abstract java.lang.Object finalizarCicloRota(long rotaId, long dataFim, long timestamp, @org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super kotlin.Unit> $completion);
    
    /**
     * Verifica se existe uma rota com o nome especificado (para validação).
     */
    @androidx.room.Query(value = "SELECT COUNT(*) FROM rotas WHERE nome = :nome AND id != :excludeId")
    @org.jetbrains.annotations.Nullable()
    public abstract java.lang.Object existeRotaComNome(@org.jetbrains.annotations.NotNull()
    java.lang.String nome, long excludeId, @org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super java.lang.Integer> $completion);
    
    /**
     * Conta o total de rotas ativas.
     */
    @androidx.room.Query(value = "SELECT COUNT(*) FROM rotas WHERE ativa = 1")
    @org.jetbrains.annotations.Nullable()
    public abstract java.lang.Object contarRotasAtivas(@org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super java.lang.Integer> $completion);
    
    /**
     * DAO (Data Access Object) para operações com a entidade Rota.
     * Define todas as operações de banco de dados relacionadas às rotas.
     */
    @kotlin.Metadata(mv = {1, 9, 0}, k = 3, xi = 48)
    public static final class DefaultImpls {
    }
}