package com.example.gestaobilhares.ui.settlement;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000B\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0011\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0002\b\u000b\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\b\u0086\b\u0018\u0000 \u001d2\u00020\u0001:\u0001\u001dB\u001f\u0012\u000e\u0010\u0002\u001a\n\u0012\u0004\u0012\u00020\u0004\u0018\u00010\u0003\u0012\b\b\u0002\u0010\u0005\u001a\u00020\u0006\u00a2\u0006\u0002\u0010\u0007J\u0016\u0010\r\u001a\n\u0012\u0004\u0012\u00020\u0004\u0018\u00010\u0003H\u00c6\u0003\u00a2\u0006\u0002\u0010\u000bJ\t\u0010\u000e\u001a\u00020\u0006H\u00c6\u0003J*\u0010\u000f\u001a\u00020\u00002\u0010\b\u0002\u0010\u0002\u001a\n\u0012\u0004\u0012\u00020\u0004\u0018\u00010\u00032\b\b\u0002\u0010\u0005\u001a\u00020\u0006H\u00c6\u0001\u00a2\u0006\u0002\u0010\u0010J\u0013\u0010\u0011\u001a\u00020\u00122\b\u0010\u0013\u001a\u0004\u0018\u00010\u0014H\u00d6\u0003J\t\u0010\u0015\u001a\u00020\u0016H\u00d6\u0001J\u0006\u0010\u0017\u001a\u00020\u0018J\u0006\u0010\u0019\u001a\u00020\u001aJ\t\u0010\u001b\u001a\u00020\u001cH\u00d6\u0001R\u0011\u0010\u0005\u001a\u00020\u0006\u00a2\u0006\b\n\u0000\u001a\u0004\b\b\u0010\tR\u001b\u0010\u0002\u001a\n\u0012\u0004\u0012\u00020\u0004\u0018\u00010\u0003\u00a2\u0006\n\n\u0002\u0010\f\u001a\u0004\b\n\u0010\u000b\u00a8\u0006\u001e"}, d2 = {"Lcom/example/gestaobilhares/ui/settlement/SettlementFragmentArgs;", "Landroidx/navigation/NavArgs;", "mesasCliente", "", "Lcom/example/gestaobilhares/ui/settlement/MesaDTO;", "clienteId", "", "([Lcom/example/gestaobilhares/ui/settlement/MesaDTO;J)V", "getClienteId", "()J", "getMesasCliente", "()[Lcom/example/gestaobilhares/ui/settlement/MesaDTO;", "[Lcom/example/gestaobilhares/ui/settlement/MesaDTO;", "component1", "component2", "copy", "([Lcom/example/gestaobilhares/ui/settlement/MesaDTO;J)Lcom/example/gestaobilhares/ui/settlement/SettlementFragmentArgs;", "equals", "", "other", "", "hashCode", "", "toBundle", "Landroid/os/Bundle;", "toSavedStateHandle", "Landroidx/lifecycle/SavedStateHandle;", "toString", "", "Companion", "app_debug"})
public final class SettlementFragmentArgs implements androidx.navigation.NavArgs {
    @org.jetbrains.annotations.Nullable()
    private final com.example.gestaobilhares.ui.settlement.MesaDTO[] mesasCliente = null;
    private final long clienteId = 0L;
    @org.jetbrains.annotations.NotNull()
    public static final com.example.gestaobilhares.ui.settlement.SettlementFragmentArgs.Companion Companion = null;
    
    public SettlementFragmentArgs(@org.jetbrains.annotations.Nullable()
    com.example.gestaobilhares.ui.settlement.MesaDTO[] mesasCliente, long clienteId) {
        super();
    }
    
    @org.jetbrains.annotations.Nullable()
    public final com.example.gestaobilhares.ui.settlement.MesaDTO[] getMesasCliente() {
        return null;
    }
    
    public final long getClienteId() {
        return 0L;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final android.os.Bundle toBundle() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final androidx.lifecycle.SavedStateHandle toSavedStateHandle() {
        return null;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final com.example.gestaobilhares.ui.settlement.MesaDTO[] component1() {
        return null;
    }
    
    public final long component2() {
        return 0L;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.example.gestaobilhares.ui.settlement.SettlementFragmentArgs copy(@org.jetbrains.annotations.Nullable()
    com.example.gestaobilhares.ui.settlement.MesaDTO[] mesasCliente, long clienteId) {
        return null;
    }
    
    @java.lang.Override()
    public boolean equals(@org.jetbrains.annotations.Nullable()
    java.lang.Object other) {
        return false;
    }
    
    @kotlin.jvm.JvmStatic()
    @kotlin.Suppress(names = {"UNCHECKED_CAST", "DEPRECATION"})
    @org.jetbrains.annotations.NotNull()
    public static final com.example.gestaobilhares.ui.settlement.SettlementFragmentArgs fromBundle(@org.jetbrains.annotations.NotNull()
    android.os.Bundle bundle) {
        return null;
    }
    
    @kotlin.jvm.JvmStatic()
    @org.jetbrains.annotations.NotNull()
    public static final com.example.gestaobilhares.ui.settlement.SettlementFragmentArgs fromSavedStateHandle(@org.jetbrains.annotations.NotNull()
    androidx.lifecycle.SavedStateHandle savedStateHandle) {
        return null;
    }
    
    @java.lang.Override()
    public int hashCode() {
        return 0;
    }
    
    @java.lang.Override()
    @org.jetbrains.annotations.NotNull()
    public java.lang.String toString() {
        return null;
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002J\u0010\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u0006H\u0007J\u0010\u0010\u0007\u001a\u00020\u00042\u0006\u0010\b\u001a\u00020\tH\u0007\u00a8\u0006\n"}, d2 = {"Lcom/example/gestaobilhares/ui/settlement/SettlementFragmentArgs$Companion;", "", "()V", "fromBundle", "Lcom/example/gestaobilhares/ui/settlement/SettlementFragmentArgs;", "bundle", "Landroid/os/Bundle;", "fromSavedStateHandle", "savedStateHandle", "Landroidx/lifecycle/SavedStateHandle;", "app_debug"})
    public static final class Companion {
        
        private Companion() {
            super();
        }
        
        @kotlin.jvm.JvmStatic()
        @kotlin.Suppress(names = {"UNCHECKED_CAST", "DEPRECATION"})
        @org.jetbrains.annotations.NotNull()
        public final com.example.gestaobilhares.ui.settlement.SettlementFragmentArgs fromBundle(@org.jetbrains.annotations.NotNull()
        android.os.Bundle bundle) {
            return null;
        }
        
        @kotlin.jvm.JvmStatic()
        @org.jetbrains.annotations.NotNull()
        public final com.example.gestaobilhares.ui.settlement.SettlementFragmentArgs fromSavedStateHandle(@org.jetbrains.annotations.NotNull()
        androidx.lifecycle.SavedStateHandle savedStateHandle) {
            return null;
        }
    }
}