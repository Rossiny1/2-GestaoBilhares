package com.example.gestaobilhares.data.dao;

/**
 * DAO (Data Access Object) para operações de banco de dados com Despesas.
 * Fornece métodos para CRUD e consultas específicas relacionadas a despesas.
 */
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000N\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\t\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0010\u0006\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u0004\bg\u0018\u00002\u00020\u0001J\u0016\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0005H\u00a7@\u00a2\u0006\u0002\u0010\u0006J\u001c\u0010\u0007\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\n0\t0\b2\u0006\u0010\u000b\u001a\u00020\fH\'J\u0018\u0010\r\u001a\u0004\u0018\u00010\u00052\u0006\u0010\u000e\u001a\u00020\u000fH\u00a7@\u00a2\u0006\u0002\u0010\u0010J$\u0010\u0011\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\n0\t0\b2\u0006\u0010\u0012\u001a\u00020\u00132\u0006\u0010\u0014\u001a\u00020\u0013H\'J\u001c\u0010\u0015\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00050\t0\b2\u0006\u0010\u0016\u001a\u00020\u000fH\'J,\u0010\u0017\u001a\b\u0012\u0004\u0012\u00020\u00050\t2\u0006\u0010\u0016\u001a\u00020\u000f2\u0006\u0010\u0012\u001a\u00020\u00132\u0006\u0010\u0014\u001a\u00020\u0013H\u00a7@\u00a2\u0006\u0002\u0010\u0018J\u0014\u0010\u0019\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\n0\t0\bH\'J\u000e\u0010\u001a\u001a\u00020\u001bH\u00a7@\u00a2\u0006\u0002\u0010\u001cJ\u0016\u0010\u001d\u001a\u00020\u001b2\u0006\u0010\u0016\u001a\u00020\u000fH\u00a7@\u00a2\u0006\u0002\u0010\u0010J\u0016\u0010\u001e\u001a\u00020\u001f2\u0006\u0010\u0016\u001a\u00020\u000fH\u00a7@\u00a2\u0006\u0002\u0010\u0010J\u0016\u0010 \u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0005H\u00a7@\u00a2\u0006\u0002\u0010\u0006J\u0016\u0010!\u001a\u00020\u00032\u0006\u0010\u0016\u001a\u00020\u000fH\u00a7@\u00a2\u0006\u0002\u0010\u0010J\u0016\u0010\"\u001a\u00020\u000f2\u0006\u0010\u0004\u001a\u00020\u0005H\u00a7@\u00a2\u0006\u0002\u0010\u0006\u00a8\u0006#"}, d2 = {"Lcom/example/gestaobilhares/data/dao/DespesaDao;", "", "atualizar", "", "despesa", "Lcom/example/gestaobilhares/data/entities/Despesa;", "(Lcom/example/gestaobilhares/data/entities/Despesa;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "buscarPorCategoria", "Lkotlinx/coroutines/flow/Flow;", "", "Lcom/example/gestaobilhares/data/entities/DespesaResumo;", "categoria", "", "buscarPorId", "id", "", "(JLkotlin/coroutines/Continuation;)Ljava/lang/Object;", "buscarPorPeriodo", "dataInicio", "Ljava/time/LocalDateTime;", "dataFim", "buscarPorRota", "rotaId", "buscarPorRotaEPeriodo", "(JLjava/time/LocalDateTime;Ljava/time/LocalDateTime;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "buscarTodasComRota", "calcularTotalGeral", "", "(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "calcularTotalPorRota", "contarPorRota", "", "deletar", "deletarPorRota", "inserir", "app_debug"})
@androidx.room.Dao()
public abstract interface DespesaDao {
    
    /**
     * Insere uma nova despesa no banco de dados.
     * @param despesa A despesa a ser inserida
     * @return O ID da despesa inserida
     */
    @androidx.room.Insert()
    @org.jetbrains.annotations.Nullable()
    public abstract java.lang.Object inserir(@org.jetbrains.annotations.NotNull()
    com.example.gestaobilhares.data.entities.Despesa despesa, @org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super java.lang.Long> $completion);
    
    /**
     * Atualiza uma despesa existente.
     * @param despesa A despesa com os dados atualizados
     */
    @androidx.room.Update()
    @org.jetbrains.annotations.Nullable()
    public abstract java.lang.Object atualizar(@org.jetbrains.annotations.NotNull()
    com.example.gestaobilhares.data.entities.Despesa despesa, @org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super kotlin.Unit> $completion);
    
    /**
     * Deleta uma despesa do banco de dados.
     * @param despesa A despesa a ser deletada
     */
    @androidx.room.Delete()
    @org.jetbrains.annotations.Nullable()
    public abstract java.lang.Object deletar(@org.jetbrains.annotations.NotNull()
    com.example.gestaobilhares.data.entities.Despesa despesa, @org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super kotlin.Unit> $completion);
    
    /**
     * Busca uma despesa pelo ID.
     * @param id O ID da despesa
     * @return A despesa encontrada ou null
     */
    @androidx.room.Query(value = "SELECT * FROM despesas WHERE id = :id")
    @org.jetbrains.annotations.Nullable()
    public abstract java.lang.Object buscarPorId(long id, @org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super com.example.gestaobilhares.data.entities.Despesa> $completion);
    
    /**
     * Busca todas as despesas de uma rota específica.
     * @param rotaId ID da rota
     * @return Flow com lista de despesas da rota
     */
    @androidx.room.Query(value = "SELECT * FROM despesas WHERE rotaId = :rotaId ORDER BY dataHora DESC")
    @org.jetbrains.annotations.NotNull()
    public abstract kotlinx.coroutines.flow.Flow<java.util.List<com.example.gestaobilhares.data.entities.Despesa>> buscarPorRota(long rotaId);
    
    /**
     * Busca todas as despesas com informações da rota (join).
     * @return Flow com lista de DespesaResumo
     */
    @androidx.room.Query(value = "\n        SELECT d.*, r.nome as nomeRota \n        FROM despesas d \n        INNER JOIN rotas r ON d.rotaId = r.id \n        ORDER BY d.dataHora DESC\n    ")
    @org.jetbrains.annotations.NotNull()
    public abstract kotlinx.coroutines.flow.Flow<java.util.List<com.example.gestaobilhares.data.entities.DespesaResumo>> buscarTodasComRota();
    
    /**
     * Busca despesas por período de datas.
     * @param dataInicio Data de início do período
     * @param dataFim Data de fim do período
     * @return Flow com lista de despesas no período
     */
    @androidx.room.Query(value = "\n        SELECT d.*, r.nome as nomeRota \n        FROM despesas d \n        INNER JOIN rotas r ON d.rotaId = r.id \n        WHERE d.dataHora BETWEEN :dataInicio AND :dataFim \n        ORDER BY d.dataHora DESC\n    ")
    @org.jetbrains.annotations.NotNull()
    public abstract kotlinx.coroutines.flow.Flow<java.util.List<com.example.gestaobilhares.data.entities.DespesaResumo>> buscarPorPeriodo(@org.jetbrains.annotations.NotNull()
    java.time.LocalDateTime dataInicio, @org.jetbrains.annotations.NotNull()
    java.time.LocalDateTime dataFim);
    
    /**
     * Busca despesas por categoria.
     * @param categoria A categoria das despesas
     * @return Flow com lista de despesas da categoria
     */
    @androidx.room.Query(value = "\n        SELECT d.*, r.nome as nomeRota \n        FROM despesas d \n        INNER JOIN rotas r ON d.rotaId = r.id \n        WHERE d.categoria = :categoria \n        ORDER BY d.dataHora DESC\n    ")
    @org.jetbrains.annotations.NotNull()
    public abstract kotlinx.coroutines.flow.Flow<java.util.List<com.example.gestaobilhares.data.entities.DespesaResumo>> buscarPorCategoria(@org.jetbrains.annotations.NotNull()
    java.lang.String categoria);
    
    /**
     * Calcula o total de despesas de uma rota.
     * @param rotaId ID da rota
     * @return O valor total das despesas da rota
     */
    @androidx.room.Query(value = "SELECT COALESCE(SUM(valor), 0.0) FROM despesas WHERE rotaId = :rotaId")
    @org.jetbrains.annotations.Nullable()
    public abstract java.lang.Object calcularTotalPorRota(long rotaId, @org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super java.lang.Double> $completion);
    
    /**
     * Calcula o total geral de despesas.
     * @return O valor total de todas as despesas
     */
    @androidx.room.Query(value = "SELECT COALESCE(SUM(valor), 0.0) FROM despesas")
    @org.jetbrains.annotations.Nullable()
    public abstract java.lang.Object calcularTotalGeral(@org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super java.lang.Double> $completion);
    
    /**
     * Conta a quantidade de despesas de uma rota.
     * @param rotaId ID da rota
     * @return A quantidade de despesas da rota
     */
    @androidx.room.Query(value = "SELECT COUNT(*) FROM despesas WHERE rotaId = :rotaId")
    @org.jetbrains.annotations.Nullable()
    public abstract java.lang.Object contarPorRota(long rotaId, @org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super java.lang.Integer> $completion);
    
    /**
     * Busca despesas por rota e período (para relatórios).
     * @param rotaId ID da rota
     * @param dataInicio Data de início do período
     * @param dataFim Data de fim do período
     * @return Lista de despesas da rota no período
     */
    @androidx.room.Query(value = "\n        SELECT * FROM despesas \n        WHERE rotaId = :rotaId AND dataHora BETWEEN :dataInicio AND :dataFim \n        ORDER BY dataHora DESC\n    ")
    @org.jetbrains.annotations.Nullable()
    public abstract java.lang.Object buscarPorRotaEPeriodo(long rotaId, @org.jetbrains.annotations.NotNull()
    java.time.LocalDateTime dataInicio, @org.jetbrains.annotations.NotNull()
    java.time.LocalDateTime dataFim, @org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super java.util.List<com.example.gestaobilhares.data.entities.Despesa>> $completion);
    
    /**
     * Deleta todas as despesas de uma rota (usado quando rota é deletada).
     * @param rotaId ID da rota
     */
    @androidx.room.Query(value = "DELETE FROM despesas WHERE rotaId = :rotaId")
    @org.jetbrains.annotations.Nullable()
    public abstract java.lang.Object deletarPorRota(long rotaId, @org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super kotlin.Unit> $completion);
}