package com.example.gestaobilhares.ui.clients;

/**
 * ✅ NOVO: Status para verificação de retirada de mesa
 */
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\u0004\b\u0086\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002j\u0002\b\u0003j\u0002\b\u0004\u00a8\u0006\u0005"}, d2 = {"Lcom/example/gestaobilhares/ui/clients/RetiradaStatus;", "", "(Ljava/lang/String;I)V", "PODE_RETIRAR", "PRECISA_ACERTO", "app_debug"})
public enum RetiradaStatus {
    /*public static final*/ PODE_RETIRAR /* = new PODE_RETIRAR() */,
    /*public static final*/ PRECISA_ACERTO /* = new PRECISA_ACERTO() */;
    
    RetiradaStatus() {
    }
    
    @org.jetbrains.annotations.NotNull()
    public static kotlin.enums.EnumEntries<com.example.gestaobilhares.ui.clients.RetiradaStatus> getEntries() {
        return null;
    }
}