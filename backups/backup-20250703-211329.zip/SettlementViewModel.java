package com.example.gestaobilhares.ui.settlement;

/**
 * ViewModel para SettlementFragment
 * FASE 4A - Implementação básica para desbloqueio
 */
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u0088\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\u0006\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\t\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0011\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010$\n\u0002\b\u0004\u0018\u00002\u00020\u0001:\u0001EB%\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\b\u001a\u00020\t\u00a2\u0006\u0002\u0010\nJ\u0018\u0010*\u001a\u0004\u0018\u00010\u00132\u0006\u0010+\u001a\u00020\u001aH\u0086@\u00a2\u0006\u0002\u0010,J\u000e\u0010-\u001a\u00020.2\u0006\u0010/\u001a\u00020\u001aJ\u001c\u00100\u001a\b\u0012\u0004\u0012\u0002010\u00122\u0006\u0010+\u001a\u00020\u001aH\u0086@\u00a2\u0006\u0002\u0010,J$\u00102\u001a\u00020.2\u0006\u0010/\u001a\u00020\u001a2\u0014\u00103\u001a\u0010\u0012\u0006\u0012\u0004\u0018\u000105\u0012\u0004\u0012\u00020.04J\u000e\u00106\u001a\u00020.2\u0006\u0010/\u001a\u00020\u001aJ\u001c\u00107\u001a\b\u0012\u0004\u0012\u00020\u00170\u00122\u0006\u0010/\u001a\u00020\u001aH\u0086@\u00a2\u0006\u0002\u0010,J\u0006\u00108\u001a\u00020.J\u000e\u00109\u001a\u00020.2\u0006\u0010/\u001a\u00020\u001aJ\u000e\u0010:\u001a\u00020.2\u0006\u0010/\u001a\u00020\u001aJ\"\u0010;\u001a\b\u0012\u0004\u0012\u00020\u00170\u00122\f\u0010&\u001a\b\u0012\u0004\u0012\u00020\u00170\u0012H\u0086@\u00a2\u0006\u0002\u0010<J\u0006\u0010=\u001a\u00020.J4\u0010>\u001a\u00020.2\u0006\u0010/\u001a\u00020\u001a2\u0006\u0010?\u001a\u00020@2\u0012\u0010A\u001a\u000e\u0012\u0004\u0012\u00020\r\u0012\u0004\u0012\u00020\u00100B2\b\b\u0002\u0010C\u001a\u00020\u0010J\u000e\u0010D\u001a\u00020.2\u0006\u0010%\u001a\u00020\u0015R\u0014\u0010\u000b\u001a\b\u0012\u0004\u0012\u00020\r0\fX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u0010\u000e\u001a\b\u0012\u0004\u0012\u00020\r0\fX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u0010\u000f\u001a\b\u0012\u0004\u0012\u00020\u00100\fX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u001a\u0010\u0011\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00130\u00120\fX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u0010\u0014\u001a\b\u0012\u0004\u0012\u00020\u00150\fX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u001a\u0010\u0016\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00170\u00120\fX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u001c\u0010\u0018\u001a\u0010\u0012\f\u0012\n\u0012\u0004\u0012\u00020\u001a\u0018\u00010\u00190\fX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\tX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0017\u0010\u001b\u001a\b\u0012\u0004\u0012\u00020\r0\u001c\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001d\u0010\u001eR\u0017\u0010\u001f\u001a\b\u0012\u0004\u0012\u00020\r0\u001c\u00a2\u0006\b\n\u0000\u001a\u0004\b \u0010\u001eR\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0017\u0010!\u001a\b\u0012\u0004\u0012\u00020\u00100\u001c\u00a2\u0006\b\n\u0000\u001a\u0004\b\"\u0010\u001eR\u001d\u0010#\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00130\u00120\u001c\u00a2\u0006\b\n\u0000\u001a\u0004\b$\u0010\u001eR\u0017\u0010%\u001a\b\u0012\u0004\u0012\u00020\u00150\u001c\u00a2\u0006\b\n\u0000\u001a\u0004\b%\u0010\u001eR\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u001d\u0010&\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00170\u00120\u001c\u00a2\u0006\b\n\u0000\u001a\u0004\b\'\u0010\u001eR\u001f\u0010(\u001a\u0010\u0012\f\u0012\n\u0012\u0004\u0012\u00020\u001a\u0018\u00010\u00190\u001c\u00a2\u0006\b\n\u0000\u001a\u0004\b)\u0010\u001e\u00a8\u0006F"}, d2 = {"Lcom/example/gestaobilhares/ui/settlement/SettlementViewModel;", "Landroidx/lifecycle/ViewModel;", "mesaRepository", "Lcom/example/gestaobilhares/data/repository/MesaRepository;", "clienteRepository", "Lcom/example/gestaobilhares/data/repositories/ClienteRepository;", "acertoRepository", "Lcom/example/gestaobilhares/data/repository/AcertoRepository;", "acertoMesaRepository", "Lcom/example/gestaobilhares/data/repository/AcertoMesaRepository;", "(Lcom/example/gestaobilhares/data/repository/MesaRepository;Lcom/example/gestaobilhares/data/repositories/ClienteRepository;Lcom/example/gestaobilhares/data/repository/AcertoRepository;Lcom/example/gestaobilhares/data/repository/AcertoMesaRepository;)V", "_clientAddress", "Lkotlinx/coroutines/flow/MutableStateFlow;", "", "_clientName", "_debitoAnterior", "", "_historicoAcertos", "", "Lcom/example/gestaobilhares/data/entities/Acerto;", "_isLoading", "", "_mesasCliente", "Lcom/example/gestaobilhares/data/entities/Mesa;", "_resultadoSalvamento", "Lkotlin/Result;", "", "clientAddress", "Lkotlinx/coroutines/flow/StateFlow;", "getClientAddress", "()Lkotlinx/coroutines/flow/StateFlow;", "clientName", "getClientName", "debitoAnterior", "getDebitoAnterior", "historicoAcertos", "getHistoricoAcertos", "isLoading", "mesasCliente", "getMesasCliente", "resultadoSalvamento", "getResultadoSalvamento", "buscarAcertoPorId", "acertoId", "(JLkotlin/coroutines/Continuation;)Ljava/lang/Object;", "buscarDebitoAnterior", "", "clienteId", "buscarMesasDoAcerto", "Lcom/example/gestaobilhares/data/entities/AcertoMesa;", "carregarDadosCliente", "callback", "Lkotlin/Function1;", "Lcom/example/gestaobilhares/data/entities/Cliente;", "carregarHistoricoAcertos", "carregarMesasClienteDireto", "limparResultadoSalvamento", "loadClientForSettlement", "loadMesasCliente", "prepararMesasParaAcerto", "(Ljava/util/List;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "resetarResultadoSalvamento", "salvarAcerto", "dadosAcerto", "Lcom/example/gestaobilhares/ui/settlement/SettlementViewModel$DadosAcerto;", "metodosPagamento", "", "desconto", "setLoading", "DadosAcerto", "app_debug"})
public final class SettlementViewModel extends androidx.lifecycle.ViewModel {
    @org.jetbrains.annotations.NotNull()
    private final com.example.gestaobilhares.data.repository.MesaRepository mesaRepository = null;
    @org.jetbrains.annotations.NotNull()
    private final com.example.gestaobilhares.data.repositories.ClienteRepository clienteRepository = null;
    @org.jetbrains.annotations.NotNull()
    private final com.example.gestaobilhares.data.repository.AcertoRepository acertoRepository = null;
    @org.jetbrains.annotations.NotNull()
    private final com.example.gestaobilhares.data.repository.AcertoMesaRepository acertoMesaRepository = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlinx.coroutines.flow.MutableStateFlow<java.lang.Boolean> _isLoading = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlinx.coroutines.flow.StateFlow<java.lang.Boolean> isLoading = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlinx.coroutines.flow.MutableStateFlow<java.lang.String> _clientName = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlinx.coroutines.flow.StateFlow<java.lang.String> clientName = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlinx.coroutines.flow.MutableStateFlow<java.lang.String> _clientAddress = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlinx.coroutines.flow.StateFlow<java.lang.String> clientAddress = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlinx.coroutines.flow.MutableStateFlow<java.util.List<com.example.gestaobilhares.data.entities.Mesa>> _mesasCliente = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlinx.coroutines.flow.StateFlow<java.util.List<com.example.gestaobilhares.data.entities.Mesa>> mesasCliente = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlinx.coroutines.flow.MutableStateFlow<kotlin.Result<java.lang.Long>> _resultadoSalvamento = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlinx.coroutines.flow.StateFlow<kotlin.Result<java.lang.Long>> resultadoSalvamento = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlinx.coroutines.flow.MutableStateFlow<java.util.List<com.example.gestaobilhares.data.entities.Acerto>> _historicoAcertos = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlinx.coroutines.flow.StateFlow<java.util.List<com.example.gestaobilhares.data.entities.Acerto>> historicoAcertos = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlinx.coroutines.flow.MutableStateFlow<java.lang.Double> _debitoAnterior = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlinx.coroutines.flow.StateFlow<java.lang.Double> debitoAnterior = null;
    
    public SettlementViewModel(@org.jetbrains.annotations.NotNull()
    com.example.gestaobilhares.data.repository.MesaRepository mesaRepository, @org.jetbrains.annotations.NotNull()
    com.example.gestaobilhares.data.repositories.ClienteRepository clienteRepository, @org.jetbrains.annotations.NotNull()
    com.example.gestaobilhares.data.repository.AcertoRepository acertoRepository, @org.jetbrains.annotations.NotNull()
    com.example.gestaobilhares.data.repository.AcertoMesaRepository acertoMesaRepository) {
        super();
    }
    
    @org.jetbrains.annotations.NotNull()
    public final kotlinx.coroutines.flow.StateFlow<java.lang.Boolean> isLoading() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final kotlinx.coroutines.flow.StateFlow<java.lang.String> getClientName() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final kotlinx.coroutines.flow.StateFlow<java.lang.String> getClientAddress() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final kotlinx.coroutines.flow.StateFlow<java.util.List<com.example.gestaobilhares.data.entities.Mesa>> getMesasCliente() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final kotlinx.coroutines.flow.StateFlow<kotlin.Result<java.lang.Long>> getResultadoSalvamento() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final kotlinx.coroutines.flow.StateFlow<java.util.List<com.example.gestaobilhares.data.entities.Acerto>> getHistoricoAcertos() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final kotlinx.coroutines.flow.StateFlow<java.lang.Double> getDebitoAnterior() {
        return null;
    }
    
    public final void loadClientForSettlement(long clienteId) {
    }
    
    /**
     * Prepara as mesas para acerto, definindo relógios iniciais baseados no último acerto
     */
    @org.jetbrains.annotations.Nullable()
    public final java.lang.Object prepararMesasParaAcerto(@org.jetbrains.annotations.NotNull()
    java.util.List<com.example.gestaobilhares.data.entities.Mesa> mesasCliente, @org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super java.util.List<com.example.gestaobilhares.data.entities.Mesa>> $completion) {
        return null;
    }
    
    public final void carregarDadosCliente(long clienteId, @org.jetbrains.annotations.NotNull()
    kotlin.jvm.functions.Function1<? super com.example.gestaobilhares.data.entities.Cliente, kotlin.Unit> callback) {
    }
    
    public final void loadMesasCliente(long clienteId) {
    }
    
    /**
     * ✅ FUNÇÃO FALLBACK: Carrega mesas diretamente sem usar Flow
     */
    @org.jetbrains.annotations.Nullable()
    public final java.lang.Object carregarMesasClienteDireto(long clienteId, @org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super java.util.List<com.example.gestaobilhares.data.entities.Mesa>> $completion) {
        return null;
    }
    
    public final void carregarHistoricoAcertos(long clienteId) {
    }
    
    /**
     * Busca o débito atual do último acerto do cliente para usar como débito anterior
     */
    public final void buscarDebitoAnterior(long clienteId) {
    }
    
    /**
     * Salva o acerto, agora recebendo os valores discriminados por método de pagamento.
     * @param clienteId ID do cliente
     * @param dadosAcerto Dados principais do acerto
     * @param metodosPagamento Mapa de método para valor recebido
     * @param desconto Valor do desconto aplicado
     */
    public final void salvarAcerto(long clienteId, @org.jetbrains.annotations.NotNull()
    com.example.gestaobilhares.ui.settlement.SettlementViewModel.DadosAcerto dadosAcerto, @org.jetbrains.annotations.NotNull()
    java.util.Map<java.lang.String, java.lang.Double> metodosPagamento, double desconto) {
    }
    
    public final void resetarResultadoSalvamento() {
    }
    
    public final void limparResultadoSalvamento() {
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.lang.Object buscarAcertoPorId(long acertoId, @org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super com.example.gestaobilhares.data.entities.Acerto> $completion) {
        return null;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.lang.Object buscarMesasDoAcerto(long acertoId, @org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super java.util.List<com.example.gestaobilhares.data.entities.AcertoMesa>> $completion) {
        return null;
    }
    
    public final void setLoading(boolean isLoading) {
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u00006\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0005\n\u0002\u0010$\n\u0002\u0010\u0006\n\u0002\b\u0019\n\u0002\u0010\b\n\u0002\b\u0002\b\u0086\b\u0018\u00002\u00020\u0001B[\u0012\f\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0006\u0012\u0006\u0010\u0007\u001a\u00020\b\u0012\b\u0010\t\u001a\u0004\u0018\u00010\u0006\u0012\u0006\u0010\n\u001a\u00020\u0006\u0012\u0006\u0010\u000b\u001a\u00020\u0006\u0012\b\u0010\f\u001a\u0004\u0018\u00010\u0006\u0012\u0012\u0010\r\u001a\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\u000f0\u000e\u00a2\u0006\u0002\u0010\u0010J\u000f\u0010\u001d\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003H\u00c6\u0003J\t\u0010\u001e\u001a\u00020\u0006H\u00c6\u0003J\t\u0010\u001f\u001a\u00020\bH\u00c6\u0003J\u000b\u0010 \u001a\u0004\u0018\u00010\u0006H\u00c6\u0003J\t\u0010!\u001a\u00020\u0006H\u00c6\u0003J\t\u0010\"\u001a\u00020\u0006H\u00c6\u0003J\u000b\u0010#\u001a\u0004\u0018\u00010\u0006H\u00c6\u0003J\u0015\u0010$\u001a\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\u000f0\u000eH\u00c6\u0003Jo\u0010%\u001a\u00020\u00002\u000e\b\u0002\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00040\u00032\b\b\u0002\u0010\u0005\u001a\u00020\u00062\b\b\u0002\u0010\u0007\u001a\u00020\b2\n\b\u0002\u0010\t\u001a\u0004\u0018\u00010\u00062\b\b\u0002\u0010\n\u001a\u00020\u00062\b\b\u0002\u0010\u000b\u001a\u00020\u00062\n\b\u0002\u0010\f\u001a\u0004\u0018\u00010\u00062\u0014\b\u0002\u0010\r\u001a\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\u000f0\u000eH\u00c6\u0001J\u0013\u0010&\u001a\u00020\b2\b\u0010\'\u001a\u0004\u0018\u00010\u0001H\u00d6\u0003J\t\u0010(\u001a\u00020)H\u00d6\u0001J\t\u0010*\u001a\u00020\u0006H\u00d6\u0001R\u0013\u0010\f\u001a\u0004\u0018\u00010\u0006\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u0012R\u0017\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u0014R\u001d\u0010\r\u001a\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\u000f0\u000e\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0015\u0010\u0016R\u0013\u0010\t\u001a\u0004\u0018\u00010\u0006\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0017\u0010\u0012R\u0011\u0010\u000b\u001a\u00020\u0006\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0018\u0010\u0012R\u0011\u0010\u0007\u001a\u00020\b\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0019\u0010\u001aR\u0011\u0010\u0005\u001a\u00020\u0006\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001b\u0010\u0012R\u0011\u0010\n\u001a\u00020\u0006\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001c\u0010\u0012\u00a8\u0006+"}, d2 = {"Lcom/example/gestaobilhares/ui/settlement/SettlementViewModel$DadosAcerto;", "", "mesas", "", "Lcom/example/gestaobilhares/data/entities/Mesa;", "representante", "", "panoTrocado", "", "numeroPano", "tipoAcerto", "observacao", "justificativa", "metodosPagamento", "", "", "(Ljava/util/List;Ljava/lang/String;ZLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)V", "getJustificativa", "()Ljava/lang/String;", "getMesas", "()Ljava/util/List;", "getMetodosPagamento", "()Ljava/util/Map;", "getNumeroPano", "getObservacao", "getPanoTrocado", "()Z", "getRepresentante", "getTipoAcerto", "component1", "component2", "component3", "component4", "component5", "component6", "component7", "component8", "copy", "equals", "other", "hashCode", "", "toString", "app_debug"})
    public static final class DadosAcerto {
        @org.jetbrains.annotations.NotNull()
        private final java.util.List<com.example.gestaobilhares.data.entities.Mesa> mesas = null;
        @org.jetbrains.annotations.NotNull()
        private final java.lang.String representante = null;
        private final boolean panoTrocado = false;
        @org.jetbrains.annotations.Nullable()
        private final java.lang.String numeroPano = null;
        @org.jetbrains.annotations.NotNull()
        private final java.lang.String tipoAcerto = null;
        @org.jetbrains.annotations.NotNull()
        private final java.lang.String observacao = null;
        @org.jetbrains.annotations.Nullable()
        private final java.lang.String justificativa = null;
        @org.jetbrains.annotations.NotNull()
        private final java.util.Map<java.lang.String, java.lang.Double> metodosPagamento = null;
        
        public DadosAcerto(@org.jetbrains.annotations.NotNull()
        java.util.List<com.example.gestaobilhares.data.entities.Mesa> mesas, @org.jetbrains.annotations.NotNull()
        java.lang.String representante, boolean panoTrocado, @org.jetbrains.annotations.Nullable()
        java.lang.String numeroPano, @org.jetbrains.annotations.NotNull()
        java.lang.String tipoAcerto, @org.jetbrains.annotations.NotNull()
        java.lang.String observacao, @org.jetbrains.annotations.Nullable()
        java.lang.String justificativa, @org.jetbrains.annotations.NotNull()
        java.util.Map<java.lang.String, java.lang.Double> metodosPagamento) {
            super();
        }
        
        @org.jetbrains.annotations.NotNull()
        public final java.util.List<com.example.gestaobilhares.data.entities.Mesa> getMesas() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final java.lang.String getRepresentante() {
            return null;
        }
        
        public final boolean getPanoTrocado() {
            return false;
        }
        
        @org.jetbrains.annotations.Nullable()
        public final java.lang.String getNumeroPano() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final java.lang.String getTipoAcerto() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final java.lang.String getObservacao() {
            return null;
        }
        
        @org.jetbrains.annotations.Nullable()
        public final java.lang.String getJustificativa() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final java.util.Map<java.lang.String, java.lang.Double> getMetodosPagamento() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final java.util.List<com.example.gestaobilhares.data.entities.Mesa> component1() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final java.lang.String component2() {
            return null;
        }
        
        public final boolean component3() {
            return false;
        }
        
        @org.jetbrains.annotations.Nullable()
        public final java.lang.String component4() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final java.lang.String component5() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final java.lang.String component6() {
            return null;
        }
        
        @org.jetbrains.annotations.Nullable()
        public final java.lang.String component7() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final java.util.Map<java.lang.String, java.lang.Double> component8() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.example.gestaobilhares.ui.settlement.SettlementViewModel.DadosAcerto copy(@org.jetbrains.annotations.NotNull()
        java.util.List<com.example.gestaobilhares.data.entities.Mesa> mesas, @org.jetbrains.annotations.NotNull()
        java.lang.String representante, boolean panoTrocado, @org.jetbrains.annotations.Nullable()
        java.lang.String numeroPano, @org.jetbrains.annotations.NotNull()
        java.lang.String tipoAcerto, @org.jetbrains.annotations.NotNull()
        java.lang.String observacao, @org.jetbrains.annotations.Nullable()
        java.lang.String justificativa, @org.jetbrains.annotations.NotNull()
        java.util.Map<java.lang.String, java.lang.Double> metodosPagamento) {
            return null;
        }
        
        @java.lang.Override()
        public boolean equals(@org.jetbrains.annotations.Nullable()
        java.lang.Object other) {
            return false;
        }
        
        @java.lang.Override()
        public int hashCode() {
            return 0;
        }
        
        @java.lang.Override()
        @org.jetbrains.annotations.NotNull()
        public java.lang.String toString() {
            return null;
        }
    }
}