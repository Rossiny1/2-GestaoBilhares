package com.example.gestaobilhares.data.entities;

/**
 * Data class para representar um resumo de cliente na lista
 * Contém informações calculadas para exibição na UI
 */
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000B\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0010\u0006\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\'\b\u0086\b\u0018\u00002\u00020\u0001Bi\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\b\u0010\u0006\u001a\u0004\u0018\u00010\u0005\u0012\u0006\u0010\u0007\u001a\u00020\u0003\u0012\u0006\u0010\b\u001a\u00020\t\u0012\u0006\u0010\n\u001a\u00020\t\u0012\u0006\u0010\u000b\u001a\u00020\f\u0012\u0006\u0010\r\u001a\u00020\u000e\u0012\b\u0010\u000f\u001a\u0004\u0018\u00010\u0010\u0012\u0006\u0010\u0011\u001a\u00020\u000e\u0012\u0006\u0010\u0012\u001a\u00020\u0013\u0012\u0006\u0010\u0014\u001a\u00020\u0015\u00a2\u0006\u0002\u0010\u0016J\t\u0010+\u001a\u00020\u0003H\u00c6\u0003J\t\u0010,\u001a\u00020\u000eH\u00c6\u0003J\t\u0010-\u001a\u00020\u0013H\u00c6\u0003J\t\u0010.\u001a\u00020\u0015H\u00c6\u0003J\t\u0010/\u001a\u00020\u0005H\u00c6\u0003J\u000b\u00100\u001a\u0004\u0018\u00010\u0005H\u00c6\u0003J\t\u00101\u001a\u00020\u0003H\u00c6\u0003J\t\u00102\u001a\u00020\tH\u00c6\u0003J\t\u00103\u001a\u00020\tH\u00c6\u0003J\t\u00104\u001a\u00020\fH\u00c6\u0003J\t\u00105\u001a\u00020\u000eH\u00c6\u0003J\u000b\u00106\u001a\u0004\u0018\u00010\u0010H\u00c6\u0003J\u0085\u0001\u00107\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\n\b\u0002\u0010\u0006\u001a\u0004\u0018\u00010\u00052\b\b\u0002\u0010\u0007\u001a\u00020\u00032\b\b\u0002\u0010\b\u001a\u00020\t2\b\b\u0002\u0010\n\u001a\u00020\t2\b\b\u0002\u0010\u000b\u001a\u00020\f2\b\b\u0002\u0010\r\u001a\u00020\u000e2\n\b\u0002\u0010\u000f\u001a\u0004\u0018\u00010\u00102\b\b\u0002\u0010\u0011\u001a\u00020\u000e2\b\b\u0002\u0010\u0012\u001a\u00020\u00132\b\b\u0002\u0010\u0014\u001a\u00020\u0015H\u00c6\u0001J\u0013\u00108\u001a\u00020\f2\b\u00109\u001a\u0004\u0018\u00010\u0001H\u00d6\u0003J\t\u0010:\u001a\u00020\u000eH\u00d6\u0001J\t\u0010;\u001a\u00020\u0005H\u00d6\u0001R\u0011\u0010\u000b\u001a\u00020\f\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0017\u0010\u0018R\u0011\u0010\n\u001a\u00020\t\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0019\u0010\u001aR\u0011\u0010\u0011\u001a\u00020\u000e\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001b\u0010\u001cR\u0011\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001d\u0010\u001eR\u0011\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001f\u0010 R\u0013\u0010\u0006\u001a\u0004\u0018\u00010\u0005\u00a2\u0006\b\n\u0000\u001a\u0004\b!\u0010 R\u0011\u0010\r\u001a\u00020\u000e\u00a2\u0006\b\n\u0000\u001a\u0004\b\"\u0010\u001cR\u0011\u0010\u0007\u001a\u00020\u0003\u00a2\u0006\b\n\u0000\u001a\u0004\b#\u0010\u001eR\u0011\u0010\u0014\u001a\u00020\u0015\u00a2\u0006\b\n\u0000\u001a\u0004\b$\u0010%R\u0011\u0010\u0012\u001a\u00020\u0013\u00a2\u0006\b\n\u0000\u001a\u0004\b&\u0010\'R\u0013\u0010\u000f\u001a\u0004\u0018\u00010\u0010\u00a2\u0006\b\n\u0000\u001a\u0004\b(\u0010)R\u0011\u0010\b\u001a\u00020\t\u00a2\u0006\b\n\u0000\u001a\u0004\b*\u0010\u001a\u00a8\u0006<"}, d2 = {"Lcom/example/gestaobilhares/data/entities/ClienteResumo;", "", "id", "", "nome", "", "nomeFantasia", "rotaId", "valorFicha", "", "debitoAtual", "ativo", "", "numeroMesasAtivas", "", "ultimoAcerto", "Ljava/util/Date;", "diasSemAcerto", "statusDebito", "Lcom/example/gestaobilhares/data/entities/StatusDebito;", "statusAcerto", "Lcom/example/gestaobilhares/data/entities/StatusAcertoCliente;", "(JLjava/lang/String;Ljava/lang/String;JDDZILjava/util/Date;ILcom/example/gestaobilhares/data/entities/StatusDebito;Lcom/example/gestaobilhares/data/entities/StatusAcertoCliente;)V", "getAtivo", "()Z", "getDebitoAtual", "()D", "getDiasSemAcerto", "()I", "getId", "()J", "getNome", "()Ljava/lang/String;", "getNomeFantasia", "getNumeroMesasAtivas", "getRotaId", "getStatusAcerto", "()Lcom/example/gestaobilhares/data/entities/StatusAcertoCliente;", "getStatusDebito", "()Lcom/example/gestaobilhares/data/entities/StatusDebito;", "getUltimoAcerto", "()Ljava/util/Date;", "getValorFicha", "component1", "component10", "component11", "component12", "component2", "component3", "component4", "component5", "component6", "component7", "component8", "component9", "copy", "equals", "other", "hashCode", "toString", "app_debug"})
public final class ClienteResumo {
    private final long id = 0L;
    @org.jetbrains.annotations.NotNull()
    private final java.lang.String nome = null;
    @org.jetbrains.annotations.Nullable()
    private final java.lang.String nomeFantasia = null;
    private final long rotaId = 0L;
    private final double valorFicha = 0.0;
    private final double debitoAtual = 0.0;
    private final boolean ativo = false;
    private final int numeroMesasAtivas = 0;
    @org.jetbrains.annotations.Nullable()
    private final java.util.Date ultimoAcerto = null;
    private final int diasSemAcerto = 0;
    @org.jetbrains.annotations.NotNull()
    private final com.example.gestaobilhares.data.entities.StatusDebito statusDebito = null;
    @org.jetbrains.annotations.NotNull()
    private final com.example.gestaobilhares.data.entities.StatusAcertoCliente statusAcerto = null;
    
    public ClienteResumo(long id, @org.jetbrains.annotations.NotNull()
    java.lang.String nome, @org.jetbrains.annotations.Nullable()
    java.lang.String nomeFantasia, long rotaId, double valorFicha, double debitoAtual, boolean ativo, int numeroMesasAtivas, @org.jetbrains.annotations.Nullable()
    java.util.Date ultimoAcerto, int diasSemAcerto, @org.jetbrains.annotations.NotNull()
    com.example.gestaobilhares.data.entities.StatusDebito statusDebito, @org.jetbrains.annotations.NotNull()
    com.example.gestaobilhares.data.entities.StatusAcertoCliente statusAcerto) {
        super();
    }
    
    public final long getId() {
        return 0L;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.lang.String getNome() {
        return null;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.lang.String getNomeFantasia() {
        return null;
    }
    
    public final long getRotaId() {
        return 0L;
    }
    
    public final double getValorFicha() {
        return 0.0;
    }
    
    public final double getDebitoAtual() {
        return 0.0;
    }
    
    public final boolean getAtivo() {
        return false;
    }
    
    public final int getNumeroMesasAtivas() {
        return 0;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.util.Date getUltimoAcerto() {
        return null;
    }
    
    public final int getDiasSemAcerto() {
        return 0;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.example.gestaobilhares.data.entities.StatusDebito getStatusDebito() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.example.gestaobilhares.data.entities.StatusAcertoCliente getStatusAcerto() {
        return null;
    }
    
    public final long component1() {
        return 0L;
    }
    
    public final int component10() {
        return 0;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.example.gestaobilhares.data.entities.StatusDebito component11() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.example.gestaobilhares.data.entities.StatusAcertoCliente component12() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.lang.String component2() {
        return null;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.lang.String component3() {
        return null;
    }
    
    public final long component4() {
        return 0L;
    }
    
    public final double component5() {
        return 0.0;
    }
    
    public final double component6() {
        return 0.0;
    }
    
    public final boolean component7() {
        return false;
    }
    
    public final int component8() {
        return 0;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.util.Date component9() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.example.gestaobilhares.data.entities.ClienteResumo copy(long id, @org.jetbrains.annotations.NotNull()
    java.lang.String nome, @org.jetbrains.annotations.Nullable()
    java.lang.String nomeFantasia, long rotaId, double valorFicha, double debitoAtual, boolean ativo, int numeroMesasAtivas, @org.jetbrains.annotations.Nullable()
    java.util.Date ultimoAcerto, int diasSemAcerto, @org.jetbrains.annotations.NotNull()
    com.example.gestaobilhares.data.entities.StatusDebito statusDebito, @org.jetbrains.annotations.NotNull()
    com.example.gestaobilhares.data.entities.StatusAcertoCliente statusAcerto) {
        return null;
    }
    
    @java.lang.Override()
    public boolean equals(@org.jetbrains.annotations.Nullable()
    java.lang.Object other) {
        return false;
    }
    
    @java.lang.Override()
    public int hashCode() {
        return 0;
    }
    
    @java.lang.Override()
    @org.jetbrains.annotations.NotNull()
    public java.lang.String toString() {
        return null;
    }
}