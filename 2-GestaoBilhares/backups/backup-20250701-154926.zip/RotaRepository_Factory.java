package com.example.gestaobilhares.data.repository;

import com.example.gestaobilhares.data.dao.RotaDao;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import javax.inject.Provider;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava"
})
public final class RotaRepository_Factory implements Factory<RotaRepository> {
  private final Provider<RotaDao> rotaDaoProvider;

  public RotaRepository_Factory(Provider<RotaDao> rotaDaoProvider) {
    this.rotaDaoProvider = rotaDaoProvider;
  }

  @Override
  public RotaRepository get() {
    return newInstance(rotaDaoProvider.get());
  }

  public static RotaRepository_Factory create(Provider<RotaDao> rotaDaoProvider) {
    return new RotaRepository_Factory(rotaDaoProvider);
  }

  public static RotaRepository newInstance(RotaDao rotaDao) {
    return new RotaRepository(rotaDao);
  }
}
