package com.example.gestaobilhares.ui.mesas

import androidx.navigation.ActionOnlyNavDirections
import androidx.navigation.NavDirections
import com.example.gestaobilhares.R

public class MesasDepositoFragmentDirections private constructor() {
  public companion object {
    public fun actionMesasDepositoFragmentToCadastroMesaFragment(): NavDirections =
        ActionOnlyNavDirections(R.id.action_mesasDepositoFragment_to_cadastroMesaFragment)
  }
}
