package com.example.gestaobilhares.data.repository;

import com.example.gestaobilhares.data.dao.AcertoMesaDao;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import javax.inject.Provider;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava"
})
public final class AcertoMesaRepository_Factory implements Factory<AcertoMesaRepository> {
  private final Provider<AcertoMesaDao> acertoMesaDaoProvider;

  public AcertoMesaRepository_Factory(Provider<AcertoMesaDao> acertoMesaDaoProvider) {
    this.acertoMesaDaoProvider = acertoMesaDaoProvider;
  }

  @Override
  public AcertoMesaRepository get() {
    return newInstance(acertoMesaDaoProvider.get());
  }

  public static AcertoMesaRepository_Factory create(Provider<AcertoMesaDao> acertoMesaDaoProvider) {
    return new AcertoMesaRepository_Factory(acertoMesaDaoProvider);
  }

  public static AcertoMesaRepository newInstance(AcertoMesaDao acertoMesaDao) {
    return new AcertoMesaRepository(acertoMesaDao);
  }
}
