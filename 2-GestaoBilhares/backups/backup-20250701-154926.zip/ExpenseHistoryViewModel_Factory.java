package com.example.gestaobilhares.ui.expenses;

import com.example.gestaobilhares.data.repository.DespesaRepository;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import javax.inject.Provider;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava"
})
public final class ExpenseHistoryViewModel_Factory implements Factory<ExpenseHistoryViewModel> {
  private final Provider<DespesaRepository> despesaRepositoryProvider;

  public ExpenseHistoryViewModel_Factory(Provider<DespesaRepository> despesaRepositoryProvider) {
    this.despesaRepositoryProvider = despesaRepositoryProvider;
  }

  @Override
  public ExpenseHistoryViewModel get() {
    return newInstance(despesaRepositoryProvider.get());
  }

  public static ExpenseHistoryViewModel_Factory create(
      Provider<DespesaRepository> despesaRepositoryProvider) {
    return new ExpenseHistoryViewModel_Factory(despesaRepositoryProvider);
  }

  public static ExpenseHistoryViewModel newInstance(DespesaRepository despesaRepository) {
    return new ExpenseHistoryViewModel(despesaRepository);
  }
}
