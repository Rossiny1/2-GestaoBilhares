package com.example.gestaobilhares.di;

import com.example.gestaobilhares.data.dao.AcertoMesaDao;
import com.example.gestaobilhares.data.database.AppDatabase;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import javax.inject.Provider;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava"
})
public final class DatabaseModule_ProvideAcertoMesaDaoFactory implements Factory<AcertoMesaDao> {
  private final Provider<AppDatabase> appDatabaseProvider;

  public DatabaseModule_ProvideAcertoMesaDaoFactory(Provider<AppDatabase> appDatabaseProvider) {
    this.appDatabaseProvider = appDatabaseProvider;
  }

  @Override
  public AcertoMesaDao get() {
    return provideAcertoMesaDao(appDatabaseProvider.get());
  }

  public static DatabaseModule_ProvideAcertoMesaDaoFactory create(
      Provider<AppDatabase> appDatabaseProvider) {
    return new DatabaseModule_ProvideAcertoMesaDaoFactory(appDatabaseProvider);
  }

  public static AcertoMesaDao provideAcertoMesaDao(AppDatabase appDatabase) {
    return Preconditions.checkNotNullFromProvides(DatabaseModule.INSTANCE.provideAcertoMesaDao(appDatabase));
  }
}
