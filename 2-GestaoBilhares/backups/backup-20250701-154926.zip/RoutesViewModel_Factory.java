package com.example.gestaobilhares.ui.routes;

import com.example.gestaobilhares.data.repository.RotaRepository;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import javax.inject.Provider;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava"
})
public final class RoutesViewModel_Factory implements Factory<RoutesViewModel> {
  private final Provider<RotaRepository> rotaRepositoryProvider;

  public RoutesViewModel_Factory(Provider<RotaRepository> rotaRepositoryProvider) {
    this.rotaRepositoryProvider = rotaRepositoryProvider;
  }

  @Override
  public RoutesViewModel get() {
    return newInstance(rotaRepositoryProvider.get());
  }

  public static RoutesViewModel_Factory create(Provider<RotaRepository> rotaRepositoryProvider) {
    return new RoutesViewModel_Factory(rotaRepositoryProvider);
  }

  public static RoutesViewModel newInstance(RotaRepository rotaRepository) {
    return new RoutesViewModel(rotaRepository);
  }
}
