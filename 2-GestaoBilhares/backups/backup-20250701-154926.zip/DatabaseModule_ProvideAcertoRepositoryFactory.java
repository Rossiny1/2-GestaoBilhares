package com.example.gestaobilhares.di;

import com.example.gestaobilhares.data.dao.AcertoDao;
import com.example.gestaobilhares.data.repository.AcertoRepository;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import javax.inject.Provider;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava"
})
public final class DatabaseModule_ProvideAcertoRepositoryFactory implements Factory<AcertoRepository> {
  private final Provider<AcertoDao> acertoDaoProvider;

  public DatabaseModule_ProvideAcertoRepositoryFactory(Provider<AcertoDao> acertoDaoProvider) {
    this.acertoDaoProvider = acertoDaoProvider;
  }

  @Override
  public AcertoRepository get() {
    return provideAcertoRepository(acertoDaoProvider.get());
  }

  public static DatabaseModule_ProvideAcertoRepositoryFactory create(
      Provider<AcertoDao> acertoDaoProvider) {
    return new DatabaseModule_ProvideAcertoRepositoryFactory(acertoDaoProvider);
  }

  public static AcertoRepository provideAcertoRepository(AcertoDao acertoDao) {
    return Preconditions.checkNotNullFromProvides(DatabaseModule.INSTANCE.provideAcertoRepository(acertoDao));
  }
}
