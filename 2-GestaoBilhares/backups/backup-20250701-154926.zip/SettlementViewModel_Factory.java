package com.example.gestaobilhares.ui.settlement;

import com.example.gestaobilhares.data.repositories.ClienteRepository;
import com.example.gestaobilhares.data.repository.AcertoMesaRepository;
import com.example.gestaobilhares.data.repository.AcertoRepository;
import com.example.gestaobilhares.data.repository.MesaRepository;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import javax.inject.Provider;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava"
})
public final class SettlementViewModel_Factory implements Factory<SettlementViewModel> {
  private final Provider<MesaRepository> mesaRepositoryProvider;

  private final Provider<ClienteRepository> clienteRepositoryProvider;

  private final Provider<AcertoRepository> acertoRepositoryProvider;

  private final Provider<AcertoMesaRepository> acertoMesaRepositoryProvider;

  public SettlementViewModel_Factory(Provider<MesaRepository> mesaRepositoryProvider,
      Provider<ClienteRepository> clienteRepositoryProvider,
      Provider<AcertoRepository> acertoRepositoryProvider,
      Provider<AcertoMesaRepository> acertoMesaRepositoryProvider) {
    this.mesaRepositoryProvider = mesaRepositoryProvider;
    this.clienteRepositoryProvider = clienteRepositoryProvider;
    this.acertoRepositoryProvider = acertoRepositoryProvider;
    this.acertoMesaRepositoryProvider = acertoMesaRepositoryProvider;
  }

  @Override
  public SettlementViewModel get() {
    return newInstance(mesaRepositoryProvider.get(), clienteRepositoryProvider.get(), acertoRepositoryProvider.get(), acertoMesaRepositoryProvider.get());
  }

  public static SettlementViewModel_Factory create(Provider<MesaRepository> mesaRepositoryProvider,
      Provider<ClienteRepository> clienteRepositoryProvider,
      Provider<AcertoRepository> acertoRepositoryProvider,
      Provider<AcertoMesaRepository> acertoMesaRepositoryProvider) {
    return new SettlementViewModel_Factory(mesaRepositoryProvider, clienteRepositoryProvider, acertoRepositoryProvider, acertoMesaRepositoryProvider);
  }

  public static SettlementViewModel newInstance(MesaRepository mesaRepository,
      ClienteRepository clienteRepository, AcertoRepository acertoRepository,
      AcertoMesaRepository acertoMesaRepository) {
    return new SettlementViewModel(mesaRepository, clienteRepository, acertoRepository, acertoMesaRepository);
  }
}
