package com.example.gestaobilhares.ui.mesas;

import com.example.gestaobilhares.data.repository.MesaRepository;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import javax.inject.Provider;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava"
})
public final class CadastroMesaViewModel_Factory implements Factory<CadastroMesaViewModel> {
  private final Provider<MesaRepository> mesaRepositoryProvider;

  public CadastroMesaViewModel_Factory(Provider<MesaRepository> mesaRepositoryProvider) {
    this.mesaRepositoryProvider = mesaRepositoryProvider;
  }

  @Override
  public CadastroMesaViewModel get() {
    return newInstance(mesaRepositoryProvider.get());
  }

  public static CadastroMesaViewModel_Factory create(
      Provider<MesaRepository> mesaRepositoryProvider) {
    return new CadastroMesaViewModel_Factory(mesaRepositoryProvider);
  }

  public static CadastroMesaViewModel newInstance(MesaRepository mesaRepository) {
    return new CadastroMesaViewModel(mesaRepository);
  }
}
