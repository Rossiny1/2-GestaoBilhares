package com.example.gestaobilhares.ui.routes

import android.os.Bundle
import androidx.navigation.ActionOnlyNavDirections
import androidx.navigation.NavDirections
import com.example.gestaobilhares.R
import kotlin.Int
import kotlin.Long

public class RoutesFragmentDirections private constructor() {
  private data class ActionRoutesFragmentToClientListFragment(
    public val rotaId: Long = 0L,
  ) : NavDirections {
    public override val actionId: Int = R.id.action_routesFragment_to_clientListFragment

    public override val arguments: Bundle
      get() {
        val result = Bundle()
        result.putLong("rotaId", this.rotaId)
        return result
      }
  }

  public companion object {
    public fun actionRoutesFragmentToRouteManagementFragment(): NavDirections =
        ActionOnlyNavDirections(R.id.action_routesFragment_to_routeManagementFragment)

    public fun actionRoutesFragmentToClientListFragment(rotaId: Long = 0L): NavDirections =
        ActionRoutesFragmentToClientListFragment(rotaId)

    public fun actionRoutesFragmentToExpenseHistoryFragment(): NavDirections =
        ActionOnlyNavDirections(R.id.action_routesFragment_to_expenseHistoryFragment)
  }
}
