package com.example.gestaobilhares.ui.clients

import android.os.Bundle
import androidx.navigation.NavDirections
import com.example.gestaobilhares.R
import kotlin.Int
import kotlin.Long

public class ClientRegisterFragmentDirections private constructor() {
  private data class ActionClientRegisterFragmentToClientDetailFragment(
    public val clienteId: Long = 0L,
  ) : NavDirections {
    public override val actionId: Int = R.id.action_clientRegisterFragment_to_clientDetailFragment

    public override val arguments: Bundle
      get() {
        val result = Bundle()
        result.putLong("clienteId", this.clienteId)
        return result
      }
  }

  private data class ActionClientRegisterFragmentToMesasDepositoFragment(
    public val clienteId: Long = 0L,
  ) : NavDirections {
    public override val actionId: Int = R.id.action_clientRegisterFragment_to_mesasDepositoFragment

    public override val arguments: Bundle
      get() {
        val result = Bundle()
        result.putLong("clienteId", this.clienteId)
        return result
      }
  }

  public companion object {
    public fun actionClientRegisterFragmentToClientDetailFragment(clienteId: Long = 0L):
        NavDirections = ActionClientRegisterFragmentToClientDetailFragment(clienteId)

    public fun actionClientRegisterFragmentToMesasDepositoFragment(clienteId: Long = 0L):
        NavDirections = ActionClientRegisterFragmentToMesasDepositoFragment(clienteId)
  }
}
