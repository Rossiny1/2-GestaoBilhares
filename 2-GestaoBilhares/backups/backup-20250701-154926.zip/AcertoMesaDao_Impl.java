package com.example.gestaobilhares.data.dao;

import android.database.Cursor;
import android.os.CancellationSignal;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.room.CoroutinesRoom;
import androidx.room.EntityDeletionOrUpdateAdapter;
import androidx.room.EntityInsertionAdapter;
import androidx.room.RoomDatabase;
import androidx.room.RoomSQLiteQuery;
import androidx.room.SharedSQLiteStatement;
import androidx.room.util.CursorUtil;
import androidx.room.util.DBUtil;
import androidx.sqlite.db.SupportSQLiteStatement;
import com.example.gestaobilhares.data.database.Converters;
import com.example.gestaobilhares.data.entities.AcertoMesa;
import java.lang.Class;
import java.lang.Exception;
import java.lang.Long;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.lang.SuppressWarnings;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.concurrent.Callable;
import javax.annotation.processing.Generated;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlinx.coroutines.flow.Flow;

@Generated("androidx.room.RoomProcessor")
@SuppressWarnings({"unchecked", "deprecation"})
public final class AcertoMesaDao_Impl implements AcertoMesaDao {
  private final RoomDatabase __db;

  private final EntityInsertionAdapter<AcertoMesa> __insertionAdapterOfAcertoMesa;

  private final Converters __converters = new Converters();

  private final EntityDeletionOrUpdateAdapter<AcertoMesa> __deletionAdapterOfAcertoMesa;

  private final EntityDeletionOrUpdateAdapter<AcertoMesa> __updateAdapterOfAcertoMesa;

  private final SharedSQLiteStatement __preparedStmtOfDeletarPorAcerto;

  public AcertoMesaDao_Impl(@NonNull final RoomDatabase __db) {
    this.__db = __db;
    this.__insertionAdapterOfAcertoMesa = new EntityInsertionAdapter<AcertoMesa>(__db) {
      @Override
      @NonNull
      protected String createQuery() {
        return "INSERT OR REPLACE INTO `acerto_mesas` (`id`,`acerto_id`,`mesa_id`,`relogio_inicial`,`relogio_final`,`fichas_jogadas`,`valor_fixo`,`valor_ficha`,`comissao_ficha`,`subtotal`,`com_defeito`,`observacoes`,`data_criacao`) VALUES (nullif(?, 0),?,?,?,?,?,?,?,?,?,?,?,?)";
      }

      @Override
      protected void bind(@NonNull final SupportSQLiteStatement statement,
          @NonNull final AcertoMesa entity) {
        statement.bindLong(1, entity.getId());
        statement.bindLong(2, entity.getAcertoId());
        statement.bindLong(3, entity.getMesaId());
        statement.bindLong(4, entity.getRelogioInicial());
        statement.bindLong(5, entity.getRelogioFinal());
        statement.bindLong(6, entity.getFichasJogadas());
        statement.bindDouble(7, entity.getValorFixo());
        statement.bindDouble(8, entity.getValorFicha());
        statement.bindDouble(9, entity.getComissaoFicha());
        statement.bindDouble(10, entity.getSubtotal());
        final int _tmp = entity.getComDefeito() ? 1 : 0;
        statement.bindLong(11, _tmp);
        if (entity.getObservacoes() == null) {
          statement.bindNull(12);
        } else {
          statement.bindString(12, entity.getObservacoes());
        }
        final Long _tmp_1 = __converters.dateToTimestamp(entity.getDataCriacao());
        if (_tmp_1 == null) {
          statement.bindNull(13);
        } else {
          statement.bindLong(13, _tmp_1);
        }
      }
    };
    this.__deletionAdapterOfAcertoMesa = new EntityDeletionOrUpdateAdapter<AcertoMesa>(__db) {
      @Override
      @NonNull
      protected String createQuery() {
        return "DELETE FROM `acerto_mesas` WHERE `id` = ?";
      }

      @Override
      protected void bind(@NonNull final SupportSQLiteStatement statement,
          @NonNull final AcertoMesa entity) {
        statement.bindLong(1, entity.getId());
      }
    };
    this.__updateAdapterOfAcertoMesa = new EntityDeletionOrUpdateAdapter<AcertoMesa>(__db) {
      @Override
      @NonNull
      protected String createQuery() {
        return "UPDATE OR ABORT `acerto_mesas` SET `id` = ?,`acerto_id` = ?,`mesa_id` = ?,`relogio_inicial` = ?,`relogio_final` = ?,`fichas_jogadas` = ?,`valor_fixo` = ?,`valor_ficha` = ?,`comissao_ficha` = ?,`subtotal` = ?,`com_defeito` = ?,`observacoes` = ?,`data_criacao` = ? WHERE `id` = ?";
      }

      @Override
      protected void bind(@NonNull final SupportSQLiteStatement statement,
          @NonNull final AcertoMesa entity) {
        statement.bindLong(1, entity.getId());
        statement.bindLong(2, entity.getAcertoId());
        statement.bindLong(3, entity.getMesaId());
        statement.bindLong(4, entity.getRelogioInicial());
        statement.bindLong(5, entity.getRelogioFinal());
        statement.bindLong(6, entity.getFichasJogadas());
        statement.bindDouble(7, entity.getValorFixo());
        statement.bindDouble(8, entity.getValorFicha());
        statement.bindDouble(9, entity.getComissaoFicha());
        statement.bindDouble(10, entity.getSubtotal());
        final int _tmp = entity.getComDefeito() ? 1 : 0;
        statement.bindLong(11, _tmp);
        if (entity.getObservacoes() == null) {
          statement.bindNull(12);
        } else {
          statement.bindString(12, entity.getObservacoes());
        }
        final Long _tmp_1 = __converters.dateToTimestamp(entity.getDataCriacao());
        if (_tmp_1 == null) {
          statement.bindNull(13);
        } else {
          statement.bindLong(13, _tmp_1);
        }
        statement.bindLong(14, entity.getId());
      }
    };
    this.__preparedStmtOfDeletarPorAcerto = new SharedSQLiteStatement(__db) {
      @Override
      @NonNull
      public String createQuery() {
        final String _query = "DELETE FROM acerto_mesas WHERE acerto_id = ?";
        return _query;
      }
    };
  }

  @Override
  public Object inserir(final AcertoMesa acertoMesa, final Continuation<? super Long> $completion) {
    return CoroutinesRoom.execute(__db, true, new Callable<Long>() {
      @Override
      @NonNull
      public Long call() throws Exception {
        __db.beginTransaction();
        try {
          final Long _result = __insertionAdapterOfAcertoMesa.insertAndReturnId(acertoMesa);
          __db.setTransactionSuccessful();
          return _result;
        } finally {
          __db.endTransaction();
        }
      }
    }, $completion);
  }

  @Override
  public Object inserirLista(final List<AcertoMesa> acertoMesas,
      final Continuation<? super Unit> $completion) {
    return CoroutinesRoom.execute(__db, true, new Callable<Unit>() {
      @Override
      @NonNull
      public Unit call() throws Exception {
        __db.beginTransaction();
        try {
          __insertionAdapterOfAcertoMesa.insert(acertoMesas);
          __db.setTransactionSuccessful();
          return Unit.INSTANCE;
        } finally {
          __db.endTransaction();
        }
      }
    }, $completion);
  }

  @Override
  public Object deletar(final AcertoMesa acertoMesa, final Continuation<? super Unit> $completion) {
    return CoroutinesRoom.execute(__db, true, new Callable<Unit>() {
      @Override
      @NonNull
      public Unit call() throws Exception {
        __db.beginTransaction();
        try {
          __deletionAdapterOfAcertoMesa.handle(acertoMesa);
          __db.setTransactionSuccessful();
          return Unit.INSTANCE;
        } finally {
          __db.endTransaction();
        }
      }
    }, $completion);
  }

  @Override
  public Object atualizar(final AcertoMesa acertoMesa,
      final Continuation<? super Unit> $completion) {
    return CoroutinesRoom.execute(__db, true, new Callable<Unit>() {
      @Override
      @NonNull
      public Unit call() throws Exception {
        __db.beginTransaction();
        try {
          __updateAdapterOfAcertoMesa.handle(acertoMesa);
          __db.setTransactionSuccessful();
          return Unit.INSTANCE;
        } finally {
          __db.endTransaction();
        }
      }
    }, $completion);
  }

  @Override
  public Object deletarPorAcerto(final long acertoId,
      final Continuation<? super Unit> $completion) {
    return CoroutinesRoom.execute(__db, true, new Callable<Unit>() {
      @Override
      @NonNull
      public Unit call() throws Exception {
        final SupportSQLiteStatement _stmt = __preparedStmtOfDeletarPorAcerto.acquire();
        int _argIndex = 1;
        _stmt.bindLong(_argIndex, acertoId);
        try {
          __db.beginTransaction();
          try {
            _stmt.executeUpdateDelete();
            __db.setTransactionSuccessful();
            return Unit.INSTANCE;
          } finally {
            __db.endTransaction();
          }
        } finally {
          __preparedStmtOfDeletarPorAcerto.release(_stmt);
        }
      }
    }, $completion);
  }

  @Override
  public Flow<List<AcertoMesa>> buscarPorAcerto(final long acertoId) {
    final String _sql = "SELECT * FROM acerto_mesas WHERE acerto_id = ?";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 1);
    int _argIndex = 1;
    _statement.bindLong(_argIndex, acertoId);
    return CoroutinesRoom.createFlow(__db, false, new String[] {"acerto_mesas"}, new Callable<List<AcertoMesa>>() {
      @Override
      @NonNull
      public List<AcertoMesa> call() throws Exception {
        final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
        try {
          final int _cursorIndexOfId = CursorUtil.getColumnIndexOrThrow(_cursor, "id");
          final int _cursorIndexOfAcertoId = CursorUtil.getColumnIndexOrThrow(_cursor, "acerto_id");
          final int _cursorIndexOfMesaId = CursorUtil.getColumnIndexOrThrow(_cursor, "mesa_id");
          final int _cursorIndexOfRelogioInicial = CursorUtil.getColumnIndexOrThrow(_cursor, "relogio_inicial");
          final int _cursorIndexOfRelogioFinal = CursorUtil.getColumnIndexOrThrow(_cursor, "relogio_final");
          final int _cursorIndexOfFichasJogadas = CursorUtil.getColumnIndexOrThrow(_cursor, "fichas_jogadas");
          final int _cursorIndexOfValorFixo = CursorUtil.getColumnIndexOrThrow(_cursor, "valor_fixo");
          final int _cursorIndexOfValorFicha = CursorUtil.getColumnIndexOrThrow(_cursor, "valor_ficha");
          final int _cursorIndexOfComissaoFicha = CursorUtil.getColumnIndexOrThrow(_cursor, "comissao_ficha");
          final int _cursorIndexOfSubtotal = CursorUtil.getColumnIndexOrThrow(_cursor, "subtotal");
          final int _cursorIndexOfComDefeito = CursorUtil.getColumnIndexOrThrow(_cursor, "com_defeito");
          final int _cursorIndexOfObservacoes = CursorUtil.getColumnIndexOrThrow(_cursor, "observacoes");
          final int _cursorIndexOfDataCriacao = CursorUtil.getColumnIndexOrThrow(_cursor, "data_criacao");
          final List<AcertoMesa> _result = new ArrayList<AcertoMesa>(_cursor.getCount());
          while (_cursor.moveToNext()) {
            final AcertoMesa _item;
            final long _tmpId;
            _tmpId = _cursor.getLong(_cursorIndexOfId);
            final long _tmpAcertoId;
            _tmpAcertoId = _cursor.getLong(_cursorIndexOfAcertoId);
            final long _tmpMesaId;
            _tmpMesaId = _cursor.getLong(_cursorIndexOfMesaId);
            final int _tmpRelogioInicial;
            _tmpRelogioInicial = _cursor.getInt(_cursorIndexOfRelogioInicial);
            final int _tmpRelogioFinal;
            _tmpRelogioFinal = _cursor.getInt(_cursorIndexOfRelogioFinal);
            final int _tmpFichasJogadas;
            _tmpFichasJogadas = _cursor.getInt(_cursorIndexOfFichasJogadas);
            final double _tmpValorFixo;
            _tmpValorFixo = _cursor.getDouble(_cursorIndexOfValorFixo);
            final double _tmpValorFicha;
            _tmpValorFicha = _cursor.getDouble(_cursorIndexOfValorFicha);
            final double _tmpComissaoFicha;
            _tmpComissaoFicha = _cursor.getDouble(_cursorIndexOfComissaoFicha);
            final double _tmpSubtotal;
            _tmpSubtotal = _cursor.getDouble(_cursorIndexOfSubtotal);
            final boolean _tmpComDefeito;
            final int _tmp;
            _tmp = _cursor.getInt(_cursorIndexOfComDefeito);
            _tmpComDefeito = _tmp != 0;
            final String _tmpObservacoes;
            if (_cursor.isNull(_cursorIndexOfObservacoes)) {
              _tmpObservacoes = null;
            } else {
              _tmpObservacoes = _cursor.getString(_cursorIndexOfObservacoes);
            }
            final Date _tmpDataCriacao;
            final Long _tmp_1;
            if (_cursor.isNull(_cursorIndexOfDataCriacao)) {
              _tmp_1 = null;
            } else {
              _tmp_1 = _cursor.getLong(_cursorIndexOfDataCriacao);
            }
            _tmpDataCriacao = __converters.fromTimestamp(_tmp_1);
            _item = new AcertoMesa(_tmpId,_tmpAcertoId,_tmpMesaId,_tmpRelogioInicial,_tmpRelogioFinal,_tmpFichasJogadas,_tmpValorFixo,_tmpValorFicha,_tmpComissaoFicha,_tmpSubtotal,_tmpComDefeito,_tmpObservacoes,_tmpDataCriacao);
            _result.add(_item);
          }
          return _result;
        } finally {
          _cursor.close();
        }
      }

      @Override
      protected void finalize() {
        _statement.release();
      }
    });
  }

  @Override
  public Flow<List<AcertoMesa>> buscarPorMesa(final long mesaId) {
    final String _sql = "SELECT * FROM acerto_mesas WHERE mesa_id = ? ORDER BY data_criacao DESC";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 1);
    int _argIndex = 1;
    _statement.bindLong(_argIndex, mesaId);
    return CoroutinesRoom.createFlow(__db, false, new String[] {"acerto_mesas"}, new Callable<List<AcertoMesa>>() {
      @Override
      @NonNull
      public List<AcertoMesa> call() throws Exception {
        final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
        try {
          final int _cursorIndexOfId = CursorUtil.getColumnIndexOrThrow(_cursor, "id");
          final int _cursorIndexOfAcertoId = CursorUtil.getColumnIndexOrThrow(_cursor, "acerto_id");
          final int _cursorIndexOfMesaId = CursorUtil.getColumnIndexOrThrow(_cursor, "mesa_id");
          final int _cursorIndexOfRelogioInicial = CursorUtil.getColumnIndexOrThrow(_cursor, "relogio_inicial");
          final int _cursorIndexOfRelogioFinal = CursorUtil.getColumnIndexOrThrow(_cursor, "relogio_final");
          final int _cursorIndexOfFichasJogadas = CursorUtil.getColumnIndexOrThrow(_cursor, "fichas_jogadas");
          final int _cursorIndexOfValorFixo = CursorUtil.getColumnIndexOrThrow(_cursor, "valor_fixo");
          final int _cursorIndexOfValorFicha = CursorUtil.getColumnIndexOrThrow(_cursor, "valor_ficha");
          final int _cursorIndexOfComissaoFicha = CursorUtil.getColumnIndexOrThrow(_cursor, "comissao_ficha");
          final int _cursorIndexOfSubtotal = CursorUtil.getColumnIndexOrThrow(_cursor, "subtotal");
          final int _cursorIndexOfComDefeito = CursorUtil.getColumnIndexOrThrow(_cursor, "com_defeito");
          final int _cursorIndexOfObservacoes = CursorUtil.getColumnIndexOrThrow(_cursor, "observacoes");
          final int _cursorIndexOfDataCriacao = CursorUtil.getColumnIndexOrThrow(_cursor, "data_criacao");
          final List<AcertoMesa> _result = new ArrayList<AcertoMesa>(_cursor.getCount());
          while (_cursor.moveToNext()) {
            final AcertoMesa _item;
            final long _tmpId;
            _tmpId = _cursor.getLong(_cursorIndexOfId);
            final long _tmpAcertoId;
            _tmpAcertoId = _cursor.getLong(_cursorIndexOfAcertoId);
            final long _tmpMesaId;
            _tmpMesaId = _cursor.getLong(_cursorIndexOfMesaId);
            final int _tmpRelogioInicial;
            _tmpRelogioInicial = _cursor.getInt(_cursorIndexOfRelogioInicial);
            final int _tmpRelogioFinal;
            _tmpRelogioFinal = _cursor.getInt(_cursorIndexOfRelogioFinal);
            final int _tmpFichasJogadas;
            _tmpFichasJogadas = _cursor.getInt(_cursorIndexOfFichasJogadas);
            final double _tmpValorFixo;
            _tmpValorFixo = _cursor.getDouble(_cursorIndexOfValorFixo);
            final double _tmpValorFicha;
            _tmpValorFicha = _cursor.getDouble(_cursorIndexOfValorFicha);
            final double _tmpComissaoFicha;
            _tmpComissaoFicha = _cursor.getDouble(_cursorIndexOfComissaoFicha);
            final double _tmpSubtotal;
            _tmpSubtotal = _cursor.getDouble(_cursorIndexOfSubtotal);
            final boolean _tmpComDefeito;
            final int _tmp;
            _tmp = _cursor.getInt(_cursorIndexOfComDefeito);
            _tmpComDefeito = _tmp != 0;
            final String _tmpObservacoes;
            if (_cursor.isNull(_cursorIndexOfObservacoes)) {
              _tmpObservacoes = null;
            } else {
              _tmpObservacoes = _cursor.getString(_cursorIndexOfObservacoes);
            }
            final Date _tmpDataCriacao;
            final Long _tmp_1;
            if (_cursor.isNull(_cursorIndexOfDataCriacao)) {
              _tmp_1 = null;
            } else {
              _tmp_1 = _cursor.getLong(_cursorIndexOfDataCriacao);
            }
            _tmpDataCriacao = __converters.fromTimestamp(_tmp_1);
            _item = new AcertoMesa(_tmpId,_tmpAcertoId,_tmpMesaId,_tmpRelogioInicial,_tmpRelogioFinal,_tmpFichasJogadas,_tmpValorFixo,_tmpValorFicha,_tmpComissaoFicha,_tmpSubtotal,_tmpComDefeito,_tmpObservacoes,_tmpDataCriacao);
            _result.add(_item);
          }
          return _result;
        } finally {
          _cursor.close();
        }
      }

      @Override
      protected void finalize() {
        _statement.release();
      }
    });
  }

  @Override
  public Object buscarUltimoAcertoMesa(final long mesaId,
      final Continuation<? super AcertoMesa> $completion) {
    final String _sql = "SELECT * FROM acerto_mesas WHERE mesa_id = ? ORDER BY data_criacao DESC LIMIT 1";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 1);
    int _argIndex = 1;
    _statement.bindLong(_argIndex, mesaId);
    final CancellationSignal _cancellationSignal = DBUtil.createCancellationSignal();
    return CoroutinesRoom.execute(__db, false, _cancellationSignal, new Callable<AcertoMesa>() {
      @Override
      @Nullable
      public AcertoMesa call() throws Exception {
        final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
        try {
          final int _cursorIndexOfId = CursorUtil.getColumnIndexOrThrow(_cursor, "id");
          final int _cursorIndexOfAcertoId = CursorUtil.getColumnIndexOrThrow(_cursor, "acerto_id");
          final int _cursorIndexOfMesaId = CursorUtil.getColumnIndexOrThrow(_cursor, "mesa_id");
          final int _cursorIndexOfRelogioInicial = CursorUtil.getColumnIndexOrThrow(_cursor, "relogio_inicial");
          final int _cursorIndexOfRelogioFinal = CursorUtil.getColumnIndexOrThrow(_cursor, "relogio_final");
          final int _cursorIndexOfFichasJogadas = CursorUtil.getColumnIndexOrThrow(_cursor, "fichas_jogadas");
          final int _cursorIndexOfValorFixo = CursorUtil.getColumnIndexOrThrow(_cursor, "valor_fixo");
          final int _cursorIndexOfValorFicha = CursorUtil.getColumnIndexOrThrow(_cursor, "valor_ficha");
          final int _cursorIndexOfComissaoFicha = CursorUtil.getColumnIndexOrThrow(_cursor, "comissao_ficha");
          final int _cursorIndexOfSubtotal = CursorUtil.getColumnIndexOrThrow(_cursor, "subtotal");
          final int _cursorIndexOfComDefeito = CursorUtil.getColumnIndexOrThrow(_cursor, "com_defeito");
          final int _cursorIndexOfObservacoes = CursorUtil.getColumnIndexOrThrow(_cursor, "observacoes");
          final int _cursorIndexOfDataCriacao = CursorUtil.getColumnIndexOrThrow(_cursor, "data_criacao");
          final AcertoMesa _result;
          if (_cursor.moveToFirst()) {
            final long _tmpId;
            _tmpId = _cursor.getLong(_cursorIndexOfId);
            final long _tmpAcertoId;
            _tmpAcertoId = _cursor.getLong(_cursorIndexOfAcertoId);
            final long _tmpMesaId;
            _tmpMesaId = _cursor.getLong(_cursorIndexOfMesaId);
            final int _tmpRelogioInicial;
            _tmpRelogioInicial = _cursor.getInt(_cursorIndexOfRelogioInicial);
            final int _tmpRelogioFinal;
            _tmpRelogioFinal = _cursor.getInt(_cursorIndexOfRelogioFinal);
            final int _tmpFichasJogadas;
            _tmpFichasJogadas = _cursor.getInt(_cursorIndexOfFichasJogadas);
            final double _tmpValorFixo;
            _tmpValorFixo = _cursor.getDouble(_cursorIndexOfValorFixo);
            final double _tmpValorFicha;
            _tmpValorFicha = _cursor.getDouble(_cursorIndexOfValorFicha);
            final double _tmpComissaoFicha;
            _tmpComissaoFicha = _cursor.getDouble(_cursorIndexOfComissaoFicha);
            final double _tmpSubtotal;
            _tmpSubtotal = _cursor.getDouble(_cursorIndexOfSubtotal);
            final boolean _tmpComDefeito;
            final int _tmp;
            _tmp = _cursor.getInt(_cursorIndexOfComDefeito);
            _tmpComDefeito = _tmp != 0;
            final String _tmpObservacoes;
            if (_cursor.isNull(_cursorIndexOfObservacoes)) {
              _tmpObservacoes = null;
            } else {
              _tmpObservacoes = _cursor.getString(_cursorIndexOfObservacoes);
            }
            final Date _tmpDataCriacao;
            final Long _tmp_1;
            if (_cursor.isNull(_cursorIndexOfDataCriacao)) {
              _tmp_1 = null;
            } else {
              _tmp_1 = _cursor.getLong(_cursorIndexOfDataCriacao);
            }
            _tmpDataCriacao = __converters.fromTimestamp(_tmp_1);
            _result = new AcertoMesa(_tmpId,_tmpAcertoId,_tmpMesaId,_tmpRelogioInicial,_tmpRelogioFinal,_tmpFichasJogadas,_tmpValorFixo,_tmpValorFicha,_tmpComissaoFicha,_tmpSubtotal,_tmpComDefeito,_tmpObservacoes,_tmpDataCriacao);
          } else {
            _result = null;
          }
          return _result;
        } finally {
          _cursor.close();
          _statement.release();
        }
      }
    }, $completion);
  }

  @Override
  public Object buscarPorAcertoId(final long acertoId,
      final Continuation<? super List<AcertoMesa>> $completion) {
    final String _sql = "SELECT * FROM acerto_mesas WHERE acerto_id = ?";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 1);
    int _argIndex = 1;
    _statement.bindLong(_argIndex, acertoId);
    final CancellationSignal _cancellationSignal = DBUtil.createCancellationSignal();
    return CoroutinesRoom.execute(__db, false, _cancellationSignal, new Callable<List<AcertoMesa>>() {
      @Override
      @NonNull
      public List<AcertoMesa> call() throws Exception {
        final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
        try {
          final int _cursorIndexOfId = CursorUtil.getColumnIndexOrThrow(_cursor, "id");
          final int _cursorIndexOfAcertoId = CursorUtil.getColumnIndexOrThrow(_cursor, "acerto_id");
          final int _cursorIndexOfMesaId = CursorUtil.getColumnIndexOrThrow(_cursor, "mesa_id");
          final int _cursorIndexOfRelogioInicial = CursorUtil.getColumnIndexOrThrow(_cursor, "relogio_inicial");
          final int _cursorIndexOfRelogioFinal = CursorUtil.getColumnIndexOrThrow(_cursor, "relogio_final");
          final int _cursorIndexOfFichasJogadas = CursorUtil.getColumnIndexOrThrow(_cursor, "fichas_jogadas");
          final int _cursorIndexOfValorFixo = CursorUtil.getColumnIndexOrThrow(_cursor, "valor_fixo");
          final int _cursorIndexOfValorFicha = CursorUtil.getColumnIndexOrThrow(_cursor, "valor_ficha");
          final int _cursorIndexOfComissaoFicha = CursorUtil.getColumnIndexOrThrow(_cursor, "comissao_ficha");
          final int _cursorIndexOfSubtotal = CursorUtil.getColumnIndexOrThrow(_cursor, "subtotal");
          final int _cursorIndexOfComDefeito = CursorUtil.getColumnIndexOrThrow(_cursor, "com_defeito");
          final int _cursorIndexOfObservacoes = CursorUtil.getColumnIndexOrThrow(_cursor, "observacoes");
          final int _cursorIndexOfDataCriacao = CursorUtil.getColumnIndexOrThrow(_cursor, "data_criacao");
          final List<AcertoMesa> _result = new ArrayList<AcertoMesa>(_cursor.getCount());
          while (_cursor.moveToNext()) {
            final AcertoMesa _item;
            final long _tmpId;
            _tmpId = _cursor.getLong(_cursorIndexOfId);
            final long _tmpAcertoId;
            _tmpAcertoId = _cursor.getLong(_cursorIndexOfAcertoId);
            final long _tmpMesaId;
            _tmpMesaId = _cursor.getLong(_cursorIndexOfMesaId);
            final int _tmpRelogioInicial;
            _tmpRelogioInicial = _cursor.getInt(_cursorIndexOfRelogioInicial);
            final int _tmpRelogioFinal;
            _tmpRelogioFinal = _cursor.getInt(_cursorIndexOfRelogioFinal);
            final int _tmpFichasJogadas;
            _tmpFichasJogadas = _cursor.getInt(_cursorIndexOfFichasJogadas);
            final double _tmpValorFixo;
            _tmpValorFixo = _cursor.getDouble(_cursorIndexOfValorFixo);
            final double _tmpValorFicha;
            _tmpValorFicha = _cursor.getDouble(_cursorIndexOfValorFicha);
            final double _tmpComissaoFicha;
            _tmpComissaoFicha = _cursor.getDouble(_cursorIndexOfComissaoFicha);
            final double _tmpSubtotal;
            _tmpSubtotal = _cursor.getDouble(_cursorIndexOfSubtotal);
            final boolean _tmpComDefeito;
            final int _tmp;
            _tmp = _cursor.getInt(_cursorIndexOfComDefeito);
            _tmpComDefeito = _tmp != 0;
            final String _tmpObservacoes;
            if (_cursor.isNull(_cursorIndexOfObservacoes)) {
              _tmpObservacoes = null;
            } else {
              _tmpObservacoes = _cursor.getString(_cursorIndexOfObservacoes);
            }
            final Date _tmpDataCriacao;
            final Long _tmp_1;
            if (_cursor.isNull(_cursorIndexOfDataCriacao)) {
              _tmp_1 = null;
            } else {
              _tmp_1 = _cursor.getLong(_cursorIndexOfDataCriacao);
            }
            _tmpDataCriacao = __converters.fromTimestamp(_tmp_1);
            _item = new AcertoMesa(_tmpId,_tmpAcertoId,_tmpMesaId,_tmpRelogioInicial,_tmpRelogioFinal,_tmpFichasJogadas,_tmpValorFixo,_tmpValorFicha,_tmpComissaoFicha,_tmpSubtotal,_tmpComDefeito,_tmpObservacoes,_tmpDataCriacao);
            _result.add(_item);
          }
          return _result;
        } finally {
          _cursor.close();
          _statement.release();
        }
      }
    }, $completion);
  }

  @NonNull
  public static List<Class<?>> getRequiredConverters() {
    return Collections.emptyList();
  }
}
