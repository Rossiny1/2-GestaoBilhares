package com.example.gestaobilhares.ui.settlement

import android.os.Bundle
import android.os.Parcelable
import androidx.lifecycle.SavedStateHandle
import androidx.navigation.NavArgs
import java.lang.IllegalArgumentException
import kotlin.Array
import kotlin.Long
import kotlin.Suppress
import kotlin.jvm.JvmStatic

public data class SettlementFragmentArgs(
  public val mesasCliente: Array<MesaDTO>?,
  public val clienteId: Long = 0L,
) : NavArgs {
  public fun toBundle(): Bundle {
    val result = Bundle()
    result.putLong("clienteId", this.clienteId)
    result.putParcelableArray("mesasCliente", this.mesasCliente)
    return result
  }

  public fun toSavedStateHandle(): SavedStateHandle {
    val result = SavedStateHandle()
    result.set("clienteId", this.clienteId)
    result.set("mesasCliente", this.mesasCliente)
    return result
  }

  public companion object {
    @JvmStatic
    @Suppress("UNCHECKED_CAST","DEPRECATION")
    public fun fromBundle(bundle: Bundle): SettlementFragmentArgs {
      bundle.setClassLoader(SettlementFragmentArgs::class.java.classLoader)
      val __clienteId : Long
      if (bundle.containsKey("clienteId")) {
        __clienteId = bundle.getLong("clienteId")
      } else {
        __clienteId = 0L
      }
      val __mesasCliente : Array<MesaDTO>?
      if (bundle.containsKey("mesasCliente")) {
        __mesasCliente = bundle.getParcelableArray("mesasCliente")?.map { it as MesaDTO
            }?.toTypedArray()
      } else {
        throw IllegalArgumentException("Required argument \"mesasCliente\" is missing and does not have an android:defaultValue")
      }
      return SettlementFragmentArgs(__mesasCliente, __clienteId)
    }

    @JvmStatic
    public fun fromSavedStateHandle(savedStateHandle: SavedStateHandle): SettlementFragmentArgs {
      val __clienteId : Long?
      if (savedStateHandle.contains("clienteId")) {
        __clienteId = savedStateHandle["clienteId"]
        if (__clienteId == null) {
          throw IllegalArgumentException("Argument \"clienteId\" of type long does not support null values")
        }
      } else {
        __clienteId = 0L
      }
      val __mesasCliente : Array<MesaDTO>?
      if (savedStateHandle.contains("mesasCliente")) {
        __mesasCliente = savedStateHandle.get<Array<Parcelable>>("mesasCliente")?.map { it as
            MesaDTO }?.toTypedArray()
      } else {
        throw IllegalArgumentException("Required argument \"mesasCliente\" is missing and does not have an android:defaultValue")
      }
      return SettlementFragmentArgs(__mesasCliente, __clienteId)
    }
  }
}
