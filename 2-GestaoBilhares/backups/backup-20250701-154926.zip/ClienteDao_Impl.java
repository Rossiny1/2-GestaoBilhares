package com.example.gestaobilhares.data.dao;

import android.database.Cursor;
import android.os.CancellationSignal;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.room.CoroutinesRoom;
import androidx.room.EntityDeletionOrUpdateAdapter;
import androidx.room.EntityInsertionAdapter;
import androidx.room.RoomDatabase;
import androidx.room.RoomSQLiteQuery;
import androidx.room.SharedSQLiteStatement;
import androidx.room.util.CursorUtil;
import androidx.room.util.DBUtil;
import androidx.sqlite.db.SupportSQLiteStatement;
import com.example.gestaobilhares.data.database.Converters;
import com.example.gestaobilhares.data.entities.Cliente;
import java.lang.Class;
import java.lang.Double;
import java.lang.Exception;
import java.lang.Long;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.lang.SuppressWarnings;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.concurrent.Callable;
import javax.annotation.processing.Generated;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlinx.coroutines.flow.Flow;

@Generated("androidx.room.RoomProcessor")
@SuppressWarnings({"unchecked", "deprecation"})
public final class ClienteDao_Impl implements ClienteDao {
  private final RoomDatabase __db;

  private final EntityInsertionAdapter<Cliente> __insertionAdapterOfCliente;

  private final Converters __converters = new Converters();

  private final EntityDeletionOrUpdateAdapter<Cliente> __deletionAdapterOfCliente;

  private final EntityDeletionOrUpdateAdapter<Cliente> __updateAdapterOfCliente;

  private final SharedSQLiteStatement __preparedStmtOfAtualizarDebitoAtual;

  public ClienteDao_Impl(@NonNull final RoomDatabase __db) {
    this.__db = __db;
    this.__insertionAdapterOfCliente = new EntityInsertionAdapter<Cliente>(__db) {
      @Override
      @NonNull
      protected String createQuery() {
        return "INSERT OR ABORT INTO `clientes` (`id`,`nome`,`nome_fantasia`,`cnpj`,`telefone`,`email`,`endereco`,`cidade`,`estado`,`cep`,`rota_id`,`valor_ficha`,`comissao_ficha`,`numero_contrato`,`debito_anterior`,`debito_atual`,`ativo`,`observacoes`,`data_cadastro`,`data_ultima_atualizacao`) VALUES (nullif(?, 0),?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
      }

      @Override
      protected void bind(@NonNull final SupportSQLiteStatement statement,
          @NonNull final Cliente entity) {
        statement.bindLong(1, entity.getId());
        if (entity.getNome() == null) {
          statement.bindNull(2);
        } else {
          statement.bindString(2, entity.getNome());
        }
        if (entity.getNomeFantasia() == null) {
          statement.bindNull(3);
        } else {
          statement.bindString(3, entity.getNomeFantasia());
        }
        if (entity.getCnpj() == null) {
          statement.bindNull(4);
        } else {
          statement.bindString(4, entity.getCnpj());
        }
        if (entity.getTelefone() == null) {
          statement.bindNull(5);
        } else {
          statement.bindString(5, entity.getTelefone());
        }
        if (entity.getEmail() == null) {
          statement.bindNull(6);
        } else {
          statement.bindString(6, entity.getEmail());
        }
        if (entity.getEndereco() == null) {
          statement.bindNull(7);
        } else {
          statement.bindString(7, entity.getEndereco());
        }
        if (entity.getCidade() == null) {
          statement.bindNull(8);
        } else {
          statement.bindString(8, entity.getCidade());
        }
        if (entity.getEstado() == null) {
          statement.bindNull(9);
        } else {
          statement.bindString(9, entity.getEstado());
        }
        if (entity.getCep() == null) {
          statement.bindNull(10);
        } else {
          statement.bindString(10, entity.getCep());
        }
        statement.bindLong(11, entity.getRotaId());
        statement.bindDouble(12, entity.getValorFicha());
        statement.bindDouble(13, entity.getComissaoFicha());
        if (entity.getNumeroContrato() == null) {
          statement.bindNull(14);
        } else {
          statement.bindString(14, entity.getNumeroContrato());
        }
        statement.bindDouble(15, entity.getDebitoAnterior());
        statement.bindDouble(16, entity.getDebitoAtual());
        final int _tmp = entity.getAtivo() ? 1 : 0;
        statement.bindLong(17, _tmp);
        if (entity.getObservacoes() == null) {
          statement.bindNull(18);
        } else {
          statement.bindString(18, entity.getObservacoes());
        }
        final Long _tmp_1 = __converters.dateToTimestamp(entity.getDataCadastro());
        if (_tmp_1 == null) {
          statement.bindNull(19);
        } else {
          statement.bindLong(19, _tmp_1);
        }
        final Long _tmp_2 = __converters.dateToTimestamp(entity.getDataUltimaAtualizacao());
        if (_tmp_2 == null) {
          statement.bindNull(20);
        } else {
          statement.bindLong(20, _tmp_2);
        }
      }
    };
    this.__deletionAdapterOfCliente = new EntityDeletionOrUpdateAdapter<Cliente>(__db) {
      @Override
      @NonNull
      protected String createQuery() {
        return "DELETE FROM `clientes` WHERE `id` = ?";
      }

      @Override
      protected void bind(@NonNull final SupportSQLiteStatement statement,
          @NonNull final Cliente entity) {
        statement.bindLong(1, entity.getId());
      }
    };
    this.__updateAdapterOfCliente = new EntityDeletionOrUpdateAdapter<Cliente>(__db) {
      @Override
      @NonNull
      protected String createQuery() {
        return "UPDATE OR ABORT `clientes` SET `id` = ?,`nome` = ?,`nome_fantasia` = ?,`cnpj` = ?,`telefone` = ?,`email` = ?,`endereco` = ?,`cidade` = ?,`estado` = ?,`cep` = ?,`rota_id` = ?,`valor_ficha` = ?,`comissao_ficha` = ?,`numero_contrato` = ?,`debito_anterior` = ?,`debito_atual` = ?,`ativo` = ?,`observacoes` = ?,`data_cadastro` = ?,`data_ultima_atualizacao` = ? WHERE `id` = ?";
      }

      @Override
      protected void bind(@NonNull final SupportSQLiteStatement statement,
          @NonNull final Cliente entity) {
        statement.bindLong(1, entity.getId());
        if (entity.getNome() == null) {
          statement.bindNull(2);
        } else {
          statement.bindString(2, entity.getNome());
        }
        if (entity.getNomeFantasia() == null) {
          statement.bindNull(3);
        } else {
          statement.bindString(3, entity.getNomeFantasia());
        }
        if (entity.getCnpj() == null) {
          statement.bindNull(4);
        } else {
          statement.bindString(4, entity.getCnpj());
        }
        if (entity.getTelefone() == null) {
          statement.bindNull(5);
        } else {
          statement.bindString(5, entity.getTelefone());
        }
        if (entity.getEmail() == null) {
          statement.bindNull(6);
        } else {
          statement.bindString(6, entity.getEmail());
        }
        if (entity.getEndereco() == null) {
          statement.bindNull(7);
        } else {
          statement.bindString(7, entity.getEndereco());
        }
        if (entity.getCidade() == null) {
          statement.bindNull(8);
        } else {
          statement.bindString(8, entity.getCidade());
        }
        if (entity.getEstado() == null) {
          statement.bindNull(9);
        } else {
          statement.bindString(9, entity.getEstado());
        }
        if (entity.getCep() == null) {
          statement.bindNull(10);
        } else {
          statement.bindString(10, entity.getCep());
        }
        statement.bindLong(11, entity.getRotaId());
        statement.bindDouble(12, entity.getValorFicha());
        statement.bindDouble(13, entity.getComissaoFicha());
        if (entity.getNumeroContrato() == null) {
          statement.bindNull(14);
        } else {
          statement.bindString(14, entity.getNumeroContrato());
        }
        statement.bindDouble(15, entity.getDebitoAnterior());
        statement.bindDouble(16, entity.getDebitoAtual());
        final int _tmp = entity.getAtivo() ? 1 : 0;
        statement.bindLong(17, _tmp);
        if (entity.getObservacoes() == null) {
          statement.bindNull(18);
        } else {
          statement.bindString(18, entity.getObservacoes());
        }
        final Long _tmp_1 = __converters.dateToTimestamp(entity.getDataCadastro());
        if (_tmp_1 == null) {
          statement.bindNull(19);
        } else {
          statement.bindLong(19, _tmp_1);
        }
        final Long _tmp_2 = __converters.dateToTimestamp(entity.getDataUltimaAtualizacao());
        if (_tmp_2 == null) {
          statement.bindNull(20);
        } else {
          statement.bindLong(20, _tmp_2);
        }
        statement.bindLong(21, entity.getId());
      }
    };
    this.__preparedStmtOfAtualizarDebitoAtual = new SharedSQLiteStatement(__db) {
      @Override
      @NonNull
      public String createQuery() {
        final String _query = "UPDATE clientes SET debito_atual = ? WHERE id = ?";
        return _query;
      }
    };
  }

  @Override
  public Object inserir(final Cliente cliente, final Continuation<? super Long> $completion) {
    return CoroutinesRoom.execute(__db, true, new Callable<Long>() {
      @Override
      @NonNull
      public Long call() throws Exception {
        __db.beginTransaction();
        try {
          final Long _result = __insertionAdapterOfCliente.insertAndReturnId(cliente);
          __db.setTransactionSuccessful();
          return _result;
        } finally {
          __db.endTransaction();
        }
      }
    }, $completion);
  }

  @Override
  public Object deletar(final Cliente cliente, final Continuation<? super Unit> $completion) {
    return CoroutinesRoom.execute(__db, true, new Callable<Unit>() {
      @Override
      @NonNull
      public Unit call() throws Exception {
        __db.beginTransaction();
        try {
          __deletionAdapterOfCliente.handle(cliente);
          __db.setTransactionSuccessful();
          return Unit.INSTANCE;
        } finally {
          __db.endTransaction();
        }
      }
    }, $completion);
  }

  @Override
  public Object atualizar(final Cliente cliente, final Continuation<? super Unit> $completion) {
    return CoroutinesRoom.execute(__db, true, new Callable<Unit>() {
      @Override
      @NonNull
      public Unit call() throws Exception {
        __db.beginTransaction();
        try {
          __updateAdapterOfCliente.handle(cliente);
          __db.setTransactionSuccessful();
          return Unit.INSTANCE;
        } finally {
          __db.endTransaction();
        }
      }
    }, $completion);
  }

  @Override
  public Object atualizarDebitoAtual(final long clienteId, final double novoDebito,
      final Continuation<? super Unit> $completion) {
    return CoroutinesRoom.execute(__db, true, new Callable<Unit>() {
      @Override
      @NonNull
      public Unit call() throws Exception {
        final SupportSQLiteStatement _stmt = __preparedStmtOfAtualizarDebitoAtual.acquire();
        int _argIndex = 1;
        _stmt.bindDouble(_argIndex, novoDebito);
        _argIndex = 2;
        _stmt.bindLong(_argIndex, clienteId);
        try {
          __db.beginTransaction();
          try {
            _stmt.executeUpdateDelete();
            __db.setTransactionSuccessful();
            return Unit.INSTANCE;
          } finally {
            __db.endTransaction();
          }
        } finally {
          __preparedStmtOfAtualizarDebitoAtual.release(_stmt);
        }
      }
    }, $completion);
  }

  @Override
  public Flow<List<Cliente>> obterClientesPorRota(final long rotaId) {
    final String _sql = "SELECT * FROM clientes WHERE rota_id = ? ORDER BY nome ASC";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 1);
    int _argIndex = 1;
    _statement.bindLong(_argIndex, rotaId);
    return CoroutinesRoom.createFlow(__db, false, new String[] {"clientes"}, new Callable<List<Cliente>>() {
      @Override
      @NonNull
      public List<Cliente> call() throws Exception {
        final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
        try {
          final int _cursorIndexOfId = CursorUtil.getColumnIndexOrThrow(_cursor, "id");
          final int _cursorIndexOfNome = CursorUtil.getColumnIndexOrThrow(_cursor, "nome");
          final int _cursorIndexOfNomeFantasia = CursorUtil.getColumnIndexOrThrow(_cursor, "nome_fantasia");
          final int _cursorIndexOfCnpj = CursorUtil.getColumnIndexOrThrow(_cursor, "cnpj");
          final int _cursorIndexOfTelefone = CursorUtil.getColumnIndexOrThrow(_cursor, "telefone");
          final int _cursorIndexOfEmail = CursorUtil.getColumnIndexOrThrow(_cursor, "email");
          final int _cursorIndexOfEndereco = CursorUtil.getColumnIndexOrThrow(_cursor, "endereco");
          final int _cursorIndexOfCidade = CursorUtil.getColumnIndexOrThrow(_cursor, "cidade");
          final int _cursorIndexOfEstado = CursorUtil.getColumnIndexOrThrow(_cursor, "estado");
          final int _cursorIndexOfCep = CursorUtil.getColumnIndexOrThrow(_cursor, "cep");
          final int _cursorIndexOfRotaId = CursorUtil.getColumnIndexOrThrow(_cursor, "rota_id");
          final int _cursorIndexOfValorFicha = CursorUtil.getColumnIndexOrThrow(_cursor, "valor_ficha");
          final int _cursorIndexOfComissaoFicha = CursorUtil.getColumnIndexOrThrow(_cursor, "comissao_ficha");
          final int _cursorIndexOfNumeroContrato = CursorUtil.getColumnIndexOrThrow(_cursor, "numero_contrato");
          final int _cursorIndexOfDebitoAnterior = CursorUtil.getColumnIndexOrThrow(_cursor, "debito_anterior");
          final int _cursorIndexOfDebitoAtual = CursorUtil.getColumnIndexOrThrow(_cursor, "debito_atual");
          final int _cursorIndexOfAtivo = CursorUtil.getColumnIndexOrThrow(_cursor, "ativo");
          final int _cursorIndexOfObservacoes = CursorUtil.getColumnIndexOrThrow(_cursor, "observacoes");
          final int _cursorIndexOfDataCadastro = CursorUtil.getColumnIndexOrThrow(_cursor, "data_cadastro");
          final int _cursorIndexOfDataUltimaAtualizacao = CursorUtil.getColumnIndexOrThrow(_cursor, "data_ultima_atualizacao");
          final List<Cliente> _result = new ArrayList<Cliente>(_cursor.getCount());
          while (_cursor.moveToNext()) {
            final Cliente _item;
            final long _tmpId;
            _tmpId = _cursor.getLong(_cursorIndexOfId);
            final String _tmpNome;
            if (_cursor.isNull(_cursorIndexOfNome)) {
              _tmpNome = null;
            } else {
              _tmpNome = _cursor.getString(_cursorIndexOfNome);
            }
            final String _tmpNomeFantasia;
            if (_cursor.isNull(_cursorIndexOfNomeFantasia)) {
              _tmpNomeFantasia = null;
            } else {
              _tmpNomeFantasia = _cursor.getString(_cursorIndexOfNomeFantasia);
            }
            final String _tmpCnpj;
            if (_cursor.isNull(_cursorIndexOfCnpj)) {
              _tmpCnpj = null;
            } else {
              _tmpCnpj = _cursor.getString(_cursorIndexOfCnpj);
            }
            final String _tmpTelefone;
            if (_cursor.isNull(_cursorIndexOfTelefone)) {
              _tmpTelefone = null;
            } else {
              _tmpTelefone = _cursor.getString(_cursorIndexOfTelefone);
            }
            final String _tmpEmail;
            if (_cursor.isNull(_cursorIndexOfEmail)) {
              _tmpEmail = null;
            } else {
              _tmpEmail = _cursor.getString(_cursorIndexOfEmail);
            }
            final String _tmpEndereco;
            if (_cursor.isNull(_cursorIndexOfEndereco)) {
              _tmpEndereco = null;
            } else {
              _tmpEndereco = _cursor.getString(_cursorIndexOfEndereco);
            }
            final String _tmpCidade;
            if (_cursor.isNull(_cursorIndexOfCidade)) {
              _tmpCidade = null;
            } else {
              _tmpCidade = _cursor.getString(_cursorIndexOfCidade);
            }
            final String _tmpEstado;
            if (_cursor.isNull(_cursorIndexOfEstado)) {
              _tmpEstado = null;
            } else {
              _tmpEstado = _cursor.getString(_cursorIndexOfEstado);
            }
            final String _tmpCep;
            if (_cursor.isNull(_cursorIndexOfCep)) {
              _tmpCep = null;
            } else {
              _tmpCep = _cursor.getString(_cursorIndexOfCep);
            }
            final long _tmpRotaId;
            _tmpRotaId = _cursor.getLong(_cursorIndexOfRotaId);
            final double _tmpValorFicha;
            _tmpValorFicha = _cursor.getDouble(_cursorIndexOfValorFicha);
            final double _tmpComissaoFicha;
            _tmpComissaoFicha = _cursor.getDouble(_cursorIndexOfComissaoFicha);
            final String _tmpNumeroContrato;
            if (_cursor.isNull(_cursorIndexOfNumeroContrato)) {
              _tmpNumeroContrato = null;
            } else {
              _tmpNumeroContrato = _cursor.getString(_cursorIndexOfNumeroContrato);
            }
            final double _tmpDebitoAnterior;
            _tmpDebitoAnterior = _cursor.getDouble(_cursorIndexOfDebitoAnterior);
            final double _tmpDebitoAtual;
            _tmpDebitoAtual = _cursor.getDouble(_cursorIndexOfDebitoAtual);
            final boolean _tmpAtivo;
            final int _tmp;
            _tmp = _cursor.getInt(_cursorIndexOfAtivo);
            _tmpAtivo = _tmp != 0;
            final String _tmpObservacoes;
            if (_cursor.isNull(_cursorIndexOfObservacoes)) {
              _tmpObservacoes = null;
            } else {
              _tmpObservacoes = _cursor.getString(_cursorIndexOfObservacoes);
            }
            final Date _tmpDataCadastro;
            final Long _tmp_1;
            if (_cursor.isNull(_cursorIndexOfDataCadastro)) {
              _tmp_1 = null;
            } else {
              _tmp_1 = _cursor.getLong(_cursorIndexOfDataCadastro);
            }
            _tmpDataCadastro = __converters.fromTimestamp(_tmp_1);
            final Date _tmpDataUltimaAtualizacao;
            final Long _tmp_2;
            if (_cursor.isNull(_cursorIndexOfDataUltimaAtualizacao)) {
              _tmp_2 = null;
            } else {
              _tmp_2 = _cursor.getLong(_cursorIndexOfDataUltimaAtualizacao);
            }
            _tmpDataUltimaAtualizacao = __converters.fromTimestamp(_tmp_2);
            _item = new Cliente(_tmpId,_tmpNome,_tmpNomeFantasia,_tmpCnpj,_tmpTelefone,_tmpEmail,_tmpEndereco,_tmpCidade,_tmpEstado,_tmpCep,_tmpRotaId,_tmpValorFicha,_tmpComissaoFicha,_tmpNumeroContrato,_tmpDebitoAnterior,_tmpDebitoAtual,_tmpAtivo,_tmpObservacoes,_tmpDataCadastro,_tmpDataUltimaAtualizacao);
            _result.add(_item);
          }
          return _result;
        } finally {
          _cursor.close();
        }
      }

      @Override
      protected void finalize() {
        _statement.release();
      }
    });
  }

  @Override
  public Object obterPorId(final long id, final Continuation<? super Cliente> $completion) {
    final String _sql = "SELECT * FROM clientes WHERE id = ?";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 1);
    int _argIndex = 1;
    _statement.bindLong(_argIndex, id);
    final CancellationSignal _cancellationSignal = DBUtil.createCancellationSignal();
    return CoroutinesRoom.execute(__db, false, _cancellationSignal, new Callable<Cliente>() {
      @Override
      @Nullable
      public Cliente call() throws Exception {
        final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
        try {
          final int _cursorIndexOfId = CursorUtil.getColumnIndexOrThrow(_cursor, "id");
          final int _cursorIndexOfNome = CursorUtil.getColumnIndexOrThrow(_cursor, "nome");
          final int _cursorIndexOfNomeFantasia = CursorUtil.getColumnIndexOrThrow(_cursor, "nome_fantasia");
          final int _cursorIndexOfCnpj = CursorUtil.getColumnIndexOrThrow(_cursor, "cnpj");
          final int _cursorIndexOfTelefone = CursorUtil.getColumnIndexOrThrow(_cursor, "telefone");
          final int _cursorIndexOfEmail = CursorUtil.getColumnIndexOrThrow(_cursor, "email");
          final int _cursorIndexOfEndereco = CursorUtil.getColumnIndexOrThrow(_cursor, "endereco");
          final int _cursorIndexOfCidade = CursorUtil.getColumnIndexOrThrow(_cursor, "cidade");
          final int _cursorIndexOfEstado = CursorUtil.getColumnIndexOrThrow(_cursor, "estado");
          final int _cursorIndexOfCep = CursorUtil.getColumnIndexOrThrow(_cursor, "cep");
          final int _cursorIndexOfRotaId = CursorUtil.getColumnIndexOrThrow(_cursor, "rota_id");
          final int _cursorIndexOfValorFicha = CursorUtil.getColumnIndexOrThrow(_cursor, "valor_ficha");
          final int _cursorIndexOfComissaoFicha = CursorUtil.getColumnIndexOrThrow(_cursor, "comissao_ficha");
          final int _cursorIndexOfNumeroContrato = CursorUtil.getColumnIndexOrThrow(_cursor, "numero_contrato");
          final int _cursorIndexOfDebitoAnterior = CursorUtil.getColumnIndexOrThrow(_cursor, "debito_anterior");
          final int _cursorIndexOfDebitoAtual = CursorUtil.getColumnIndexOrThrow(_cursor, "debito_atual");
          final int _cursorIndexOfAtivo = CursorUtil.getColumnIndexOrThrow(_cursor, "ativo");
          final int _cursorIndexOfObservacoes = CursorUtil.getColumnIndexOrThrow(_cursor, "observacoes");
          final int _cursorIndexOfDataCadastro = CursorUtil.getColumnIndexOrThrow(_cursor, "data_cadastro");
          final int _cursorIndexOfDataUltimaAtualizacao = CursorUtil.getColumnIndexOrThrow(_cursor, "data_ultima_atualizacao");
          final Cliente _result;
          if (_cursor.moveToFirst()) {
            final long _tmpId;
            _tmpId = _cursor.getLong(_cursorIndexOfId);
            final String _tmpNome;
            if (_cursor.isNull(_cursorIndexOfNome)) {
              _tmpNome = null;
            } else {
              _tmpNome = _cursor.getString(_cursorIndexOfNome);
            }
            final String _tmpNomeFantasia;
            if (_cursor.isNull(_cursorIndexOfNomeFantasia)) {
              _tmpNomeFantasia = null;
            } else {
              _tmpNomeFantasia = _cursor.getString(_cursorIndexOfNomeFantasia);
            }
            final String _tmpCnpj;
            if (_cursor.isNull(_cursorIndexOfCnpj)) {
              _tmpCnpj = null;
            } else {
              _tmpCnpj = _cursor.getString(_cursorIndexOfCnpj);
            }
            final String _tmpTelefone;
            if (_cursor.isNull(_cursorIndexOfTelefone)) {
              _tmpTelefone = null;
            } else {
              _tmpTelefone = _cursor.getString(_cursorIndexOfTelefone);
            }
            final String _tmpEmail;
            if (_cursor.isNull(_cursorIndexOfEmail)) {
              _tmpEmail = null;
            } else {
              _tmpEmail = _cursor.getString(_cursorIndexOfEmail);
            }
            final String _tmpEndereco;
            if (_cursor.isNull(_cursorIndexOfEndereco)) {
              _tmpEndereco = null;
            } else {
              _tmpEndereco = _cursor.getString(_cursorIndexOfEndereco);
            }
            final String _tmpCidade;
            if (_cursor.isNull(_cursorIndexOfCidade)) {
              _tmpCidade = null;
            } else {
              _tmpCidade = _cursor.getString(_cursorIndexOfCidade);
            }
            final String _tmpEstado;
            if (_cursor.isNull(_cursorIndexOfEstado)) {
              _tmpEstado = null;
            } else {
              _tmpEstado = _cursor.getString(_cursorIndexOfEstado);
            }
            final String _tmpCep;
            if (_cursor.isNull(_cursorIndexOfCep)) {
              _tmpCep = null;
            } else {
              _tmpCep = _cursor.getString(_cursorIndexOfCep);
            }
            final long _tmpRotaId;
            _tmpRotaId = _cursor.getLong(_cursorIndexOfRotaId);
            final double _tmpValorFicha;
            _tmpValorFicha = _cursor.getDouble(_cursorIndexOfValorFicha);
            final double _tmpComissaoFicha;
            _tmpComissaoFicha = _cursor.getDouble(_cursorIndexOfComissaoFicha);
            final String _tmpNumeroContrato;
            if (_cursor.isNull(_cursorIndexOfNumeroContrato)) {
              _tmpNumeroContrato = null;
            } else {
              _tmpNumeroContrato = _cursor.getString(_cursorIndexOfNumeroContrato);
            }
            final double _tmpDebitoAnterior;
            _tmpDebitoAnterior = _cursor.getDouble(_cursorIndexOfDebitoAnterior);
            final double _tmpDebitoAtual;
            _tmpDebitoAtual = _cursor.getDouble(_cursorIndexOfDebitoAtual);
            final boolean _tmpAtivo;
            final int _tmp;
            _tmp = _cursor.getInt(_cursorIndexOfAtivo);
            _tmpAtivo = _tmp != 0;
            final String _tmpObservacoes;
            if (_cursor.isNull(_cursorIndexOfObservacoes)) {
              _tmpObservacoes = null;
            } else {
              _tmpObservacoes = _cursor.getString(_cursorIndexOfObservacoes);
            }
            final Date _tmpDataCadastro;
            final Long _tmp_1;
            if (_cursor.isNull(_cursorIndexOfDataCadastro)) {
              _tmp_1 = null;
            } else {
              _tmp_1 = _cursor.getLong(_cursorIndexOfDataCadastro);
            }
            _tmpDataCadastro = __converters.fromTimestamp(_tmp_1);
            final Date _tmpDataUltimaAtualizacao;
            final Long _tmp_2;
            if (_cursor.isNull(_cursorIndexOfDataUltimaAtualizacao)) {
              _tmp_2 = null;
            } else {
              _tmp_2 = _cursor.getLong(_cursorIndexOfDataUltimaAtualizacao);
            }
            _tmpDataUltimaAtualizacao = __converters.fromTimestamp(_tmp_2);
            _result = new Cliente(_tmpId,_tmpNome,_tmpNomeFantasia,_tmpCnpj,_tmpTelefone,_tmpEmail,_tmpEndereco,_tmpCidade,_tmpEstado,_tmpCep,_tmpRotaId,_tmpValorFicha,_tmpComissaoFicha,_tmpNumeroContrato,_tmpDebitoAnterior,_tmpDebitoAtual,_tmpAtivo,_tmpObservacoes,_tmpDataCadastro,_tmpDataUltimaAtualizacao);
          } else {
            _result = null;
          }
          return _result;
        } finally {
          _cursor.close();
          _statement.release();
        }
      }
    }, $completion);
  }

  @Override
  public Flow<List<Cliente>> obterTodos() {
    final String _sql = "SELECT * FROM clientes ORDER BY nome ASC";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 0);
    return CoroutinesRoom.createFlow(__db, false, new String[] {"clientes"}, new Callable<List<Cliente>>() {
      @Override
      @NonNull
      public List<Cliente> call() throws Exception {
        final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
        try {
          final int _cursorIndexOfId = CursorUtil.getColumnIndexOrThrow(_cursor, "id");
          final int _cursorIndexOfNome = CursorUtil.getColumnIndexOrThrow(_cursor, "nome");
          final int _cursorIndexOfNomeFantasia = CursorUtil.getColumnIndexOrThrow(_cursor, "nome_fantasia");
          final int _cursorIndexOfCnpj = CursorUtil.getColumnIndexOrThrow(_cursor, "cnpj");
          final int _cursorIndexOfTelefone = CursorUtil.getColumnIndexOrThrow(_cursor, "telefone");
          final int _cursorIndexOfEmail = CursorUtil.getColumnIndexOrThrow(_cursor, "email");
          final int _cursorIndexOfEndereco = CursorUtil.getColumnIndexOrThrow(_cursor, "endereco");
          final int _cursorIndexOfCidade = CursorUtil.getColumnIndexOrThrow(_cursor, "cidade");
          final int _cursorIndexOfEstado = CursorUtil.getColumnIndexOrThrow(_cursor, "estado");
          final int _cursorIndexOfCep = CursorUtil.getColumnIndexOrThrow(_cursor, "cep");
          final int _cursorIndexOfRotaId = CursorUtil.getColumnIndexOrThrow(_cursor, "rota_id");
          final int _cursorIndexOfValorFicha = CursorUtil.getColumnIndexOrThrow(_cursor, "valor_ficha");
          final int _cursorIndexOfComissaoFicha = CursorUtil.getColumnIndexOrThrow(_cursor, "comissao_ficha");
          final int _cursorIndexOfNumeroContrato = CursorUtil.getColumnIndexOrThrow(_cursor, "numero_contrato");
          final int _cursorIndexOfDebitoAnterior = CursorUtil.getColumnIndexOrThrow(_cursor, "debito_anterior");
          final int _cursorIndexOfDebitoAtual = CursorUtil.getColumnIndexOrThrow(_cursor, "debito_atual");
          final int _cursorIndexOfAtivo = CursorUtil.getColumnIndexOrThrow(_cursor, "ativo");
          final int _cursorIndexOfObservacoes = CursorUtil.getColumnIndexOrThrow(_cursor, "observacoes");
          final int _cursorIndexOfDataCadastro = CursorUtil.getColumnIndexOrThrow(_cursor, "data_cadastro");
          final int _cursorIndexOfDataUltimaAtualizacao = CursorUtil.getColumnIndexOrThrow(_cursor, "data_ultima_atualizacao");
          final List<Cliente> _result = new ArrayList<Cliente>(_cursor.getCount());
          while (_cursor.moveToNext()) {
            final Cliente _item;
            final long _tmpId;
            _tmpId = _cursor.getLong(_cursorIndexOfId);
            final String _tmpNome;
            if (_cursor.isNull(_cursorIndexOfNome)) {
              _tmpNome = null;
            } else {
              _tmpNome = _cursor.getString(_cursorIndexOfNome);
            }
            final String _tmpNomeFantasia;
            if (_cursor.isNull(_cursorIndexOfNomeFantasia)) {
              _tmpNomeFantasia = null;
            } else {
              _tmpNomeFantasia = _cursor.getString(_cursorIndexOfNomeFantasia);
            }
            final String _tmpCnpj;
            if (_cursor.isNull(_cursorIndexOfCnpj)) {
              _tmpCnpj = null;
            } else {
              _tmpCnpj = _cursor.getString(_cursorIndexOfCnpj);
            }
            final String _tmpTelefone;
            if (_cursor.isNull(_cursorIndexOfTelefone)) {
              _tmpTelefone = null;
            } else {
              _tmpTelefone = _cursor.getString(_cursorIndexOfTelefone);
            }
            final String _tmpEmail;
            if (_cursor.isNull(_cursorIndexOfEmail)) {
              _tmpEmail = null;
            } else {
              _tmpEmail = _cursor.getString(_cursorIndexOfEmail);
            }
            final String _tmpEndereco;
            if (_cursor.isNull(_cursorIndexOfEndereco)) {
              _tmpEndereco = null;
            } else {
              _tmpEndereco = _cursor.getString(_cursorIndexOfEndereco);
            }
            final String _tmpCidade;
            if (_cursor.isNull(_cursorIndexOfCidade)) {
              _tmpCidade = null;
            } else {
              _tmpCidade = _cursor.getString(_cursorIndexOfCidade);
            }
            final String _tmpEstado;
            if (_cursor.isNull(_cursorIndexOfEstado)) {
              _tmpEstado = null;
            } else {
              _tmpEstado = _cursor.getString(_cursorIndexOfEstado);
            }
            final String _tmpCep;
            if (_cursor.isNull(_cursorIndexOfCep)) {
              _tmpCep = null;
            } else {
              _tmpCep = _cursor.getString(_cursorIndexOfCep);
            }
            final long _tmpRotaId;
            _tmpRotaId = _cursor.getLong(_cursorIndexOfRotaId);
            final double _tmpValorFicha;
            _tmpValorFicha = _cursor.getDouble(_cursorIndexOfValorFicha);
            final double _tmpComissaoFicha;
            _tmpComissaoFicha = _cursor.getDouble(_cursorIndexOfComissaoFicha);
            final String _tmpNumeroContrato;
            if (_cursor.isNull(_cursorIndexOfNumeroContrato)) {
              _tmpNumeroContrato = null;
            } else {
              _tmpNumeroContrato = _cursor.getString(_cursorIndexOfNumeroContrato);
            }
            final double _tmpDebitoAnterior;
            _tmpDebitoAnterior = _cursor.getDouble(_cursorIndexOfDebitoAnterior);
            final double _tmpDebitoAtual;
            _tmpDebitoAtual = _cursor.getDouble(_cursorIndexOfDebitoAtual);
            final boolean _tmpAtivo;
            final int _tmp;
            _tmp = _cursor.getInt(_cursorIndexOfAtivo);
            _tmpAtivo = _tmp != 0;
            final String _tmpObservacoes;
            if (_cursor.isNull(_cursorIndexOfObservacoes)) {
              _tmpObservacoes = null;
            } else {
              _tmpObservacoes = _cursor.getString(_cursorIndexOfObservacoes);
            }
            final Date _tmpDataCadastro;
            final Long _tmp_1;
            if (_cursor.isNull(_cursorIndexOfDataCadastro)) {
              _tmp_1 = null;
            } else {
              _tmp_1 = _cursor.getLong(_cursorIndexOfDataCadastro);
            }
            _tmpDataCadastro = __converters.fromTimestamp(_tmp_1);
            final Date _tmpDataUltimaAtualizacao;
            final Long _tmp_2;
            if (_cursor.isNull(_cursorIndexOfDataUltimaAtualizacao)) {
              _tmp_2 = null;
            } else {
              _tmp_2 = _cursor.getLong(_cursorIndexOfDataUltimaAtualizacao);
            }
            _tmpDataUltimaAtualizacao = __converters.fromTimestamp(_tmp_2);
            _item = new Cliente(_tmpId,_tmpNome,_tmpNomeFantasia,_tmpCnpj,_tmpTelefone,_tmpEmail,_tmpEndereco,_tmpCidade,_tmpEstado,_tmpCep,_tmpRotaId,_tmpValorFicha,_tmpComissaoFicha,_tmpNumeroContrato,_tmpDebitoAnterior,_tmpDebitoAtual,_tmpAtivo,_tmpObservacoes,_tmpDataCadastro,_tmpDataUltimaAtualizacao);
            _result.add(_item);
          }
          return _result;
        } finally {
          _cursor.close();
        }
      }

      @Override
      protected void finalize() {
        _statement.release();
      }
    });
  }

  @Override
  public Object obterDebitoAtual(final long clienteId,
      final Continuation<? super Double> $completion) {
    final String _sql = "SELECT debito_atual FROM clientes WHERE id = ?";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 1);
    int _argIndex = 1;
    _statement.bindLong(_argIndex, clienteId);
    final CancellationSignal _cancellationSignal = DBUtil.createCancellationSignal();
    return CoroutinesRoom.execute(__db, false, _cancellationSignal, new Callable<Double>() {
      @Override
      @NonNull
      public Double call() throws Exception {
        final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
        try {
          final Double _result;
          if (_cursor.moveToFirst()) {
            if (_cursor.isNull(0)) {
              _result = null;
            } else {
              _result = _cursor.getDouble(0);
            }
          } else {
            _result = null;
          }
          return _result;
        } finally {
          _cursor.close();
          _statement.release();
        }
      }
    }, $completion);
  }

  @Override
  public Object obterClienteComDebitoAtual(final long clienteId,
      final Continuation<? super Cliente> $completion) {
    final String _sql = "\n"
            + "        SELECT c.*, \n"
            + "               COALESCE(ultimo_acerto.debito_atual, 0.0) as debito_atual_calculado\n"
            + "        FROM clientes c\n"
            + "        LEFT JOIN (\n"
            + "            SELECT cliente_id, debito_atual, data_acerto\n"
            + "            FROM acertos \n"
            + "            WHERE cliente_id = ? \n"
            + "            ORDER BY data_acerto DESC \n"
            + "            LIMIT 1\n"
            + "        ) ultimo_acerto ON c.id = ultimo_acerto.cliente_id\n"
            + "        WHERE c.id = ?\n"
            + "    ";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 2);
    int _argIndex = 1;
    _statement.bindLong(_argIndex, clienteId);
    _argIndex = 2;
    _statement.bindLong(_argIndex, clienteId);
    final CancellationSignal _cancellationSignal = DBUtil.createCancellationSignal();
    return CoroutinesRoom.execute(__db, false, _cancellationSignal, new Callable<Cliente>() {
      @Override
      @Nullable
      public Cliente call() throws Exception {
        final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
        try {
          final int _cursorIndexOfId = CursorUtil.getColumnIndexOrThrow(_cursor, "id");
          final int _cursorIndexOfNome = CursorUtil.getColumnIndexOrThrow(_cursor, "nome");
          final int _cursorIndexOfNomeFantasia = CursorUtil.getColumnIndexOrThrow(_cursor, "nome_fantasia");
          final int _cursorIndexOfCnpj = CursorUtil.getColumnIndexOrThrow(_cursor, "cnpj");
          final int _cursorIndexOfTelefone = CursorUtil.getColumnIndexOrThrow(_cursor, "telefone");
          final int _cursorIndexOfEmail = CursorUtil.getColumnIndexOrThrow(_cursor, "email");
          final int _cursorIndexOfEndereco = CursorUtil.getColumnIndexOrThrow(_cursor, "endereco");
          final int _cursorIndexOfCidade = CursorUtil.getColumnIndexOrThrow(_cursor, "cidade");
          final int _cursorIndexOfEstado = CursorUtil.getColumnIndexOrThrow(_cursor, "estado");
          final int _cursorIndexOfCep = CursorUtil.getColumnIndexOrThrow(_cursor, "cep");
          final int _cursorIndexOfRotaId = CursorUtil.getColumnIndexOrThrow(_cursor, "rota_id");
          final int _cursorIndexOfValorFicha = CursorUtil.getColumnIndexOrThrow(_cursor, "valor_ficha");
          final int _cursorIndexOfComissaoFicha = CursorUtil.getColumnIndexOrThrow(_cursor, "comissao_ficha");
          final int _cursorIndexOfNumeroContrato = CursorUtil.getColumnIndexOrThrow(_cursor, "numero_contrato");
          final int _cursorIndexOfDebitoAnterior = CursorUtil.getColumnIndexOrThrow(_cursor, "debito_anterior");
          final int _cursorIndexOfDebitoAtual = CursorUtil.getColumnIndexOrThrow(_cursor, "debito_atual");
          final int _cursorIndexOfAtivo = CursorUtil.getColumnIndexOrThrow(_cursor, "ativo");
          final int _cursorIndexOfObservacoes = CursorUtil.getColumnIndexOrThrow(_cursor, "observacoes");
          final int _cursorIndexOfDataCadastro = CursorUtil.getColumnIndexOrThrow(_cursor, "data_cadastro");
          final int _cursorIndexOfDataUltimaAtualizacao = CursorUtil.getColumnIndexOrThrow(_cursor, "data_ultima_atualizacao");
          final Cliente _result;
          if (_cursor.moveToFirst()) {
            final long _tmpId;
            _tmpId = _cursor.getLong(_cursorIndexOfId);
            final String _tmpNome;
            if (_cursor.isNull(_cursorIndexOfNome)) {
              _tmpNome = null;
            } else {
              _tmpNome = _cursor.getString(_cursorIndexOfNome);
            }
            final String _tmpNomeFantasia;
            if (_cursor.isNull(_cursorIndexOfNomeFantasia)) {
              _tmpNomeFantasia = null;
            } else {
              _tmpNomeFantasia = _cursor.getString(_cursorIndexOfNomeFantasia);
            }
            final String _tmpCnpj;
            if (_cursor.isNull(_cursorIndexOfCnpj)) {
              _tmpCnpj = null;
            } else {
              _tmpCnpj = _cursor.getString(_cursorIndexOfCnpj);
            }
            final String _tmpTelefone;
            if (_cursor.isNull(_cursorIndexOfTelefone)) {
              _tmpTelefone = null;
            } else {
              _tmpTelefone = _cursor.getString(_cursorIndexOfTelefone);
            }
            final String _tmpEmail;
            if (_cursor.isNull(_cursorIndexOfEmail)) {
              _tmpEmail = null;
            } else {
              _tmpEmail = _cursor.getString(_cursorIndexOfEmail);
            }
            final String _tmpEndereco;
            if (_cursor.isNull(_cursorIndexOfEndereco)) {
              _tmpEndereco = null;
            } else {
              _tmpEndereco = _cursor.getString(_cursorIndexOfEndereco);
            }
            final String _tmpCidade;
            if (_cursor.isNull(_cursorIndexOfCidade)) {
              _tmpCidade = null;
            } else {
              _tmpCidade = _cursor.getString(_cursorIndexOfCidade);
            }
            final String _tmpEstado;
            if (_cursor.isNull(_cursorIndexOfEstado)) {
              _tmpEstado = null;
            } else {
              _tmpEstado = _cursor.getString(_cursorIndexOfEstado);
            }
            final String _tmpCep;
            if (_cursor.isNull(_cursorIndexOfCep)) {
              _tmpCep = null;
            } else {
              _tmpCep = _cursor.getString(_cursorIndexOfCep);
            }
            final long _tmpRotaId;
            _tmpRotaId = _cursor.getLong(_cursorIndexOfRotaId);
            final double _tmpValorFicha;
            _tmpValorFicha = _cursor.getDouble(_cursorIndexOfValorFicha);
            final double _tmpComissaoFicha;
            _tmpComissaoFicha = _cursor.getDouble(_cursorIndexOfComissaoFicha);
            final String _tmpNumeroContrato;
            if (_cursor.isNull(_cursorIndexOfNumeroContrato)) {
              _tmpNumeroContrato = null;
            } else {
              _tmpNumeroContrato = _cursor.getString(_cursorIndexOfNumeroContrato);
            }
            final double _tmpDebitoAnterior;
            _tmpDebitoAnterior = _cursor.getDouble(_cursorIndexOfDebitoAnterior);
            final double _tmpDebitoAtual;
            _tmpDebitoAtual = _cursor.getDouble(_cursorIndexOfDebitoAtual);
            final boolean _tmpAtivo;
            final int _tmp;
            _tmp = _cursor.getInt(_cursorIndexOfAtivo);
            _tmpAtivo = _tmp != 0;
            final String _tmpObservacoes;
            if (_cursor.isNull(_cursorIndexOfObservacoes)) {
              _tmpObservacoes = null;
            } else {
              _tmpObservacoes = _cursor.getString(_cursorIndexOfObservacoes);
            }
            final Date _tmpDataCadastro;
            final Long _tmp_1;
            if (_cursor.isNull(_cursorIndexOfDataCadastro)) {
              _tmp_1 = null;
            } else {
              _tmp_1 = _cursor.getLong(_cursorIndexOfDataCadastro);
            }
            _tmpDataCadastro = __converters.fromTimestamp(_tmp_1);
            final Date _tmpDataUltimaAtualizacao;
            final Long _tmp_2;
            if (_cursor.isNull(_cursorIndexOfDataUltimaAtualizacao)) {
              _tmp_2 = null;
            } else {
              _tmp_2 = _cursor.getLong(_cursorIndexOfDataUltimaAtualizacao);
            }
            _tmpDataUltimaAtualizacao = __converters.fromTimestamp(_tmp_2);
            _result = new Cliente(_tmpId,_tmpNome,_tmpNomeFantasia,_tmpCnpj,_tmpTelefone,_tmpEmail,_tmpEndereco,_tmpCidade,_tmpEstado,_tmpCep,_tmpRotaId,_tmpValorFicha,_tmpComissaoFicha,_tmpNumeroContrato,_tmpDebitoAnterior,_tmpDebitoAtual,_tmpAtivo,_tmpObservacoes,_tmpDataCadastro,_tmpDataUltimaAtualizacao);
          } else {
            _result = null;
          }
          return _result;
        } finally {
          _cursor.close();
          _statement.release();
        }
      }
    }, $completion);
  }

  @NonNull
  public static List<Class<?>> getRequiredConverters() {
    return Collections.emptyList();
  }
}
