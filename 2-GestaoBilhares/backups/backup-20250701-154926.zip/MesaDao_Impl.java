package com.example.gestaobilhares.data.dao;

import android.database.Cursor;
import android.os.CancellationSignal;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.room.CoroutinesRoom;
import androidx.room.EntityDeletionOrUpdateAdapter;
import androidx.room.EntityInsertionAdapter;
import androidx.room.RoomDatabase;
import androidx.room.RoomSQLiteQuery;
import androidx.room.SharedSQLiteStatement;
import androidx.room.util.CursorUtil;
import androidx.room.util.DBUtil;
import androidx.sqlite.db.SupportSQLiteStatement;
import com.example.gestaobilhares.data.database.Converters;
import com.example.gestaobilhares.data.entities.Mesa;
import com.example.gestaobilhares.data.entities.TipoMesa;
import java.lang.Class;
import java.lang.Exception;
import java.lang.Long;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.lang.SuppressWarnings;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.concurrent.Callable;
import javax.annotation.processing.Generated;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlinx.coroutines.flow.Flow;

@Generated("androidx.room.RoomProcessor")
@SuppressWarnings({"unchecked", "deprecation"})
public final class MesaDao_Impl implements MesaDao {
  private final RoomDatabase __db;

  private final EntityInsertionAdapter<Mesa> __insertionAdapterOfMesa;

  private final Converters __converters = new Converters();

  private final EntityDeletionOrUpdateAdapter<Mesa> __deletionAdapterOfMesa;

  private final EntityDeletionOrUpdateAdapter<Mesa> __updateAdapterOfMesa;

  private final SharedSQLiteStatement __preparedStmtOfDesvincularMesa;

  private final SharedSQLiteStatement __preparedStmtOfVincularMesa;

  private final SharedSQLiteStatement __preparedStmtOfVincularMesaComValorFixo;

  private final SharedSQLiteStatement __preparedStmtOfRetirarMesa;

  private final SharedSQLiteStatement __preparedStmtOfAtualizarRelogioMesa;

  public MesaDao_Impl(@NonNull final RoomDatabase __db) {
    this.__db = __db;
    this.__insertionAdapterOfMesa = new EntityInsertionAdapter<Mesa>(__db) {
      @Override
      @NonNull
      protected String createQuery() {
        return "INSERT OR REPLACE INTO `mesas` (`id`,`numero`,`cliente_id`,`fichas_inicial`,`fichas_final`,`relogio_inicial`,`relogio_final`,`valor_fixo`,`tipo_mesa`,`ativa`,`observacoes`,`data_instalacao`,`data_ultima_leitura`) VALUES (nullif(?, 0),?,?,?,?,?,?,?,?,?,?,?,?)";
      }

      @Override
      protected void bind(@NonNull final SupportSQLiteStatement statement,
          @NonNull final Mesa entity) {
        statement.bindLong(1, entity.getId());
        if (entity.getNumero() == null) {
          statement.bindNull(2);
        } else {
          statement.bindString(2, entity.getNumero());
        }
        if (entity.getClienteId() == null) {
          statement.bindNull(3);
        } else {
          statement.bindLong(3, entity.getClienteId());
        }
        statement.bindLong(4, entity.getFichasInicial());
        statement.bindLong(5, entity.getFichasFinal());
        statement.bindLong(6, entity.getRelogioInicial());
        statement.bindLong(7, entity.getRelogioFinal());
        statement.bindDouble(8, entity.getValorFixo());
        final String _tmp = __converters.fromTipoMesa(entity.getTipoMesa());
        if (_tmp == null) {
          statement.bindNull(9);
        } else {
          statement.bindString(9, _tmp);
        }
        final int _tmp_1 = entity.getAtiva() ? 1 : 0;
        statement.bindLong(10, _tmp_1);
        if (entity.getObservacoes() == null) {
          statement.bindNull(11);
        } else {
          statement.bindString(11, entity.getObservacoes());
        }
        final Long _tmp_2 = __converters.dateToTimestamp(entity.getDataInstalacao());
        if (_tmp_2 == null) {
          statement.bindNull(12);
        } else {
          statement.bindLong(12, _tmp_2);
        }
        final Long _tmp_3 = __converters.dateToTimestamp(entity.getDataUltimaLeitura());
        if (_tmp_3 == null) {
          statement.bindNull(13);
        } else {
          statement.bindLong(13, _tmp_3);
        }
      }
    };
    this.__deletionAdapterOfMesa = new EntityDeletionOrUpdateAdapter<Mesa>(__db) {
      @Override
      @NonNull
      protected String createQuery() {
        return "DELETE FROM `mesas` WHERE `id` = ?";
      }

      @Override
      protected void bind(@NonNull final SupportSQLiteStatement statement,
          @NonNull final Mesa entity) {
        statement.bindLong(1, entity.getId());
      }
    };
    this.__updateAdapterOfMesa = new EntityDeletionOrUpdateAdapter<Mesa>(__db) {
      @Override
      @NonNull
      protected String createQuery() {
        return "UPDATE OR ABORT `mesas` SET `id` = ?,`numero` = ?,`cliente_id` = ?,`fichas_inicial` = ?,`fichas_final` = ?,`relogio_inicial` = ?,`relogio_final` = ?,`valor_fixo` = ?,`tipo_mesa` = ?,`ativa` = ?,`observacoes` = ?,`data_instalacao` = ?,`data_ultima_leitura` = ? WHERE `id` = ?";
      }

      @Override
      protected void bind(@NonNull final SupportSQLiteStatement statement,
          @NonNull final Mesa entity) {
        statement.bindLong(1, entity.getId());
        if (entity.getNumero() == null) {
          statement.bindNull(2);
        } else {
          statement.bindString(2, entity.getNumero());
        }
        if (entity.getClienteId() == null) {
          statement.bindNull(3);
        } else {
          statement.bindLong(3, entity.getClienteId());
        }
        statement.bindLong(4, entity.getFichasInicial());
        statement.bindLong(5, entity.getFichasFinal());
        statement.bindLong(6, entity.getRelogioInicial());
        statement.bindLong(7, entity.getRelogioFinal());
        statement.bindDouble(8, entity.getValorFixo());
        final String _tmp = __converters.fromTipoMesa(entity.getTipoMesa());
        if (_tmp == null) {
          statement.bindNull(9);
        } else {
          statement.bindString(9, _tmp);
        }
        final int _tmp_1 = entity.getAtiva() ? 1 : 0;
        statement.bindLong(10, _tmp_1);
        if (entity.getObservacoes() == null) {
          statement.bindNull(11);
        } else {
          statement.bindString(11, entity.getObservacoes());
        }
        final Long _tmp_2 = __converters.dateToTimestamp(entity.getDataInstalacao());
        if (_tmp_2 == null) {
          statement.bindNull(12);
        } else {
          statement.bindLong(12, _tmp_2);
        }
        final Long _tmp_3 = __converters.dateToTimestamp(entity.getDataUltimaLeitura());
        if (_tmp_3 == null) {
          statement.bindNull(13);
        } else {
          statement.bindLong(13, _tmp_3);
        }
        statement.bindLong(14, entity.getId());
      }
    };
    this.__preparedStmtOfDesvincularMesa = new SharedSQLiteStatement(__db) {
      @Override
      @NonNull
      public String createQuery() {
        final String _query = "UPDATE mesas SET cliente_id = NULL, ativa = 0 WHERE id = ?";
        return _query;
      }
    };
    this.__preparedStmtOfVincularMesa = new SharedSQLiteStatement(__db) {
      @Override
      @NonNull
      public String createQuery() {
        final String _query = "UPDATE mesas SET cliente_id = ?, ativa = 1 WHERE id = ?";
        return _query;
      }
    };
    this.__preparedStmtOfVincularMesaComValorFixo = new SharedSQLiteStatement(__db) {
      @Override
      @NonNull
      public String createQuery() {
        final String _query = "UPDATE mesas SET cliente_id = ?, ativa = 1, valor_fixo = ? WHERE id = ?";
        return _query;
      }
    };
    this.__preparedStmtOfRetirarMesa = new SharedSQLiteStatement(__db) {
      @Override
      @NonNull
      public String createQuery() {
        final String _query = "\n"
                + "        UPDATE mesas \n"
                + "        SET cliente_id = NULL, \n"
                + "            ativa = 0,\n"
                + "            relogio_inicial = relogio_final\n"
                + "        WHERE id = ?\n"
                + "    ";
        return _query;
      }
    };
    this.__preparedStmtOfAtualizarRelogioMesa = new SharedSQLiteStatement(__db) {
      @Override
      @NonNull
      public String createQuery() {
        final String _query = "\n"
                + "        UPDATE mesas \n"
                + "        SET relogio_inicial = ?,\n"
                + "            relogio_final = ?,\n"
                + "            fichas_inicial = ?,\n"
                + "            fichas_final = ?\n"
                + "        WHERE id = ?\n"
                + "    ";
        return _query;
      }
    };
  }

  @Override
  public Object inserir(final Mesa mesa, final Continuation<? super Long> $completion) {
    return CoroutinesRoom.execute(__db, true, new Callable<Long>() {
      @Override
      @NonNull
      public Long call() throws Exception {
        __db.beginTransaction();
        try {
          final Long _result = __insertionAdapterOfMesa.insertAndReturnId(mesa);
          __db.setTransactionSuccessful();
          return _result;
        } finally {
          __db.endTransaction();
        }
      }
    }, $completion);
  }

  @Override
  public Object deletar(final Mesa mesa, final Continuation<? super Unit> $completion) {
    return CoroutinesRoom.execute(__db, true, new Callable<Unit>() {
      @Override
      @NonNull
      public Unit call() throws Exception {
        __db.beginTransaction();
        try {
          __deletionAdapterOfMesa.handle(mesa);
          __db.setTransactionSuccessful();
          return Unit.INSTANCE;
        } finally {
          __db.endTransaction();
        }
      }
    }, $completion);
  }

  @Override
  public Object atualizar(final Mesa mesa, final Continuation<? super Unit> $completion) {
    return CoroutinesRoom.execute(__db, true, new Callable<Unit>() {
      @Override
      @NonNull
      public Unit call() throws Exception {
        __db.beginTransaction();
        try {
          __updateAdapterOfMesa.handle(mesa);
          __db.setTransactionSuccessful();
          return Unit.INSTANCE;
        } finally {
          __db.endTransaction();
        }
      }
    }, $completion);
  }

  @Override
  public Object desvincularMesa(final long mesaId, final Continuation<? super Unit> $completion) {
    return CoroutinesRoom.execute(__db, true, new Callable<Unit>() {
      @Override
      @NonNull
      public Unit call() throws Exception {
        final SupportSQLiteStatement _stmt = __preparedStmtOfDesvincularMesa.acquire();
        int _argIndex = 1;
        _stmt.bindLong(_argIndex, mesaId);
        try {
          __db.beginTransaction();
          try {
            _stmt.executeUpdateDelete();
            __db.setTransactionSuccessful();
            return Unit.INSTANCE;
          } finally {
            __db.endTransaction();
          }
        } finally {
          __preparedStmtOfDesvincularMesa.release(_stmt);
        }
      }
    }, $completion);
  }

  @Override
  public Object vincularMesa(final long mesaId, final long clienteId,
      final Continuation<? super Unit> $completion) {
    return CoroutinesRoom.execute(__db, true, new Callable<Unit>() {
      @Override
      @NonNull
      public Unit call() throws Exception {
        final SupportSQLiteStatement _stmt = __preparedStmtOfVincularMesa.acquire();
        int _argIndex = 1;
        _stmt.bindLong(_argIndex, clienteId);
        _argIndex = 2;
        _stmt.bindLong(_argIndex, mesaId);
        try {
          __db.beginTransaction();
          try {
            _stmt.executeUpdateDelete();
            __db.setTransactionSuccessful();
            return Unit.INSTANCE;
          } finally {
            __db.endTransaction();
          }
        } finally {
          __preparedStmtOfVincularMesa.release(_stmt);
        }
      }
    }, $completion);
  }

  @Override
  public Object vincularMesaComValorFixo(final long mesaId, final long clienteId,
      final double valorFixo, final Continuation<? super Unit> $completion) {
    return CoroutinesRoom.execute(__db, true, new Callable<Unit>() {
      @Override
      @NonNull
      public Unit call() throws Exception {
        final SupportSQLiteStatement _stmt = __preparedStmtOfVincularMesaComValorFixo.acquire();
        int _argIndex = 1;
        _stmt.bindLong(_argIndex, clienteId);
        _argIndex = 2;
        _stmt.bindDouble(_argIndex, valorFixo);
        _argIndex = 3;
        _stmt.bindLong(_argIndex, mesaId);
        try {
          __db.beginTransaction();
          try {
            _stmt.executeUpdateDelete();
            __db.setTransactionSuccessful();
            return Unit.INSTANCE;
          } finally {
            __db.endTransaction();
          }
        } finally {
          __preparedStmtOfVincularMesaComValorFixo.release(_stmt);
        }
      }
    }, $completion);
  }

  @Override
  public Object retirarMesa(final long mesaId, final Continuation<? super Unit> $completion) {
    return CoroutinesRoom.execute(__db, true, new Callable<Unit>() {
      @Override
      @NonNull
      public Unit call() throws Exception {
        final SupportSQLiteStatement _stmt = __preparedStmtOfRetirarMesa.acquire();
        int _argIndex = 1;
        _stmt.bindLong(_argIndex, mesaId);
        try {
          __db.beginTransaction();
          try {
            _stmt.executeUpdateDelete();
            __db.setTransactionSuccessful();
            return Unit.INSTANCE;
          } finally {
            __db.endTransaction();
          }
        } finally {
          __preparedStmtOfRetirarMesa.release(_stmt);
        }
      }
    }, $completion);
  }

  @Override
  public Object atualizarRelogioMesa(final long mesaId, final int relogioInicial,
      final int relogioFinal, final int fichasInicial, final int fichasFinal,
      final Continuation<? super Unit> $completion) {
    return CoroutinesRoom.execute(__db, true, new Callable<Unit>() {
      @Override
      @NonNull
      public Unit call() throws Exception {
        final SupportSQLiteStatement _stmt = __preparedStmtOfAtualizarRelogioMesa.acquire();
        int _argIndex = 1;
        _stmt.bindLong(_argIndex, relogioInicial);
        _argIndex = 2;
        _stmt.bindLong(_argIndex, relogioFinal);
        _argIndex = 3;
        _stmt.bindLong(_argIndex, fichasInicial);
        _argIndex = 4;
        _stmt.bindLong(_argIndex, fichasFinal);
        _argIndex = 5;
        _stmt.bindLong(_argIndex, mesaId);
        try {
          __db.beginTransaction();
          try {
            _stmt.executeUpdateDelete();
            __db.setTransactionSuccessful();
            return Unit.INSTANCE;
          } finally {
            __db.endTransaction();
          }
        } finally {
          __preparedStmtOfAtualizarRelogioMesa.release(_stmt);
        }
      }
    }, $completion);
  }

  @Override
  public Flow<List<Mesa>> obterMesasPorCliente(final long clienteId) {
    final String _sql = "SELECT * FROM mesas WHERE cliente_id = ? AND ativa = 1 ORDER BY numero ASC";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 1);
    int _argIndex = 1;
    _statement.bindLong(_argIndex, clienteId);
    return CoroutinesRoom.createFlow(__db, false, new String[] {"mesas"}, new Callable<List<Mesa>>() {
      @Override
      @NonNull
      public List<Mesa> call() throws Exception {
        final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
        try {
          final int _cursorIndexOfId = CursorUtil.getColumnIndexOrThrow(_cursor, "id");
          final int _cursorIndexOfNumero = CursorUtil.getColumnIndexOrThrow(_cursor, "numero");
          final int _cursorIndexOfClienteId = CursorUtil.getColumnIndexOrThrow(_cursor, "cliente_id");
          final int _cursorIndexOfFichasInicial = CursorUtil.getColumnIndexOrThrow(_cursor, "fichas_inicial");
          final int _cursorIndexOfFichasFinal = CursorUtil.getColumnIndexOrThrow(_cursor, "fichas_final");
          final int _cursorIndexOfRelogioInicial = CursorUtil.getColumnIndexOrThrow(_cursor, "relogio_inicial");
          final int _cursorIndexOfRelogioFinal = CursorUtil.getColumnIndexOrThrow(_cursor, "relogio_final");
          final int _cursorIndexOfValorFixo = CursorUtil.getColumnIndexOrThrow(_cursor, "valor_fixo");
          final int _cursorIndexOfTipoMesa = CursorUtil.getColumnIndexOrThrow(_cursor, "tipo_mesa");
          final int _cursorIndexOfAtiva = CursorUtil.getColumnIndexOrThrow(_cursor, "ativa");
          final int _cursorIndexOfObservacoes = CursorUtil.getColumnIndexOrThrow(_cursor, "observacoes");
          final int _cursorIndexOfDataInstalacao = CursorUtil.getColumnIndexOrThrow(_cursor, "data_instalacao");
          final int _cursorIndexOfDataUltimaLeitura = CursorUtil.getColumnIndexOrThrow(_cursor, "data_ultima_leitura");
          final List<Mesa> _result = new ArrayList<Mesa>(_cursor.getCount());
          while (_cursor.moveToNext()) {
            final Mesa _item;
            final long _tmpId;
            _tmpId = _cursor.getLong(_cursorIndexOfId);
            final String _tmpNumero;
            if (_cursor.isNull(_cursorIndexOfNumero)) {
              _tmpNumero = null;
            } else {
              _tmpNumero = _cursor.getString(_cursorIndexOfNumero);
            }
            final Long _tmpClienteId;
            if (_cursor.isNull(_cursorIndexOfClienteId)) {
              _tmpClienteId = null;
            } else {
              _tmpClienteId = _cursor.getLong(_cursorIndexOfClienteId);
            }
            final int _tmpFichasInicial;
            _tmpFichasInicial = _cursor.getInt(_cursorIndexOfFichasInicial);
            final int _tmpFichasFinal;
            _tmpFichasFinal = _cursor.getInt(_cursorIndexOfFichasFinal);
            final int _tmpRelogioInicial;
            _tmpRelogioInicial = _cursor.getInt(_cursorIndexOfRelogioInicial);
            final int _tmpRelogioFinal;
            _tmpRelogioFinal = _cursor.getInt(_cursorIndexOfRelogioFinal);
            final double _tmpValorFixo;
            _tmpValorFixo = _cursor.getDouble(_cursorIndexOfValorFixo);
            final TipoMesa _tmpTipoMesa;
            final String _tmp;
            if (_cursor.isNull(_cursorIndexOfTipoMesa)) {
              _tmp = null;
            } else {
              _tmp = _cursor.getString(_cursorIndexOfTipoMesa);
            }
            _tmpTipoMesa = __converters.toTipoMesa(_tmp);
            final boolean _tmpAtiva;
            final int _tmp_1;
            _tmp_1 = _cursor.getInt(_cursorIndexOfAtiva);
            _tmpAtiva = _tmp_1 != 0;
            final String _tmpObservacoes;
            if (_cursor.isNull(_cursorIndexOfObservacoes)) {
              _tmpObservacoes = null;
            } else {
              _tmpObservacoes = _cursor.getString(_cursorIndexOfObservacoes);
            }
            final Date _tmpDataInstalacao;
            final Long _tmp_2;
            if (_cursor.isNull(_cursorIndexOfDataInstalacao)) {
              _tmp_2 = null;
            } else {
              _tmp_2 = _cursor.getLong(_cursorIndexOfDataInstalacao);
            }
            _tmpDataInstalacao = __converters.fromTimestamp(_tmp_2);
            final Date _tmpDataUltimaLeitura;
            final Long _tmp_3;
            if (_cursor.isNull(_cursorIndexOfDataUltimaLeitura)) {
              _tmp_3 = null;
            } else {
              _tmp_3 = _cursor.getLong(_cursorIndexOfDataUltimaLeitura);
            }
            _tmpDataUltimaLeitura = __converters.fromTimestamp(_tmp_3);
            _item = new Mesa(_tmpId,_tmpNumero,_tmpClienteId,_tmpFichasInicial,_tmpFichasFinal,_tmpRelogioInicial,_tmpRelogioFinal,_tmpValorFixo,_tmpTipoMesa,_tmpAtiva,_tmpObservacoes,_tmpDataInstalacao,_tmpDataUltimaLeitura);
            _result.add(_item);
          }
          return _result;
        } finally {
          _cursor.close();
        }
      }

      @Override
      protected void finalize() {
        _statement.release();
      }
    });
  }

  @Override
  public Flow<List<Mesa>> obterMesasDisponiveis() {
    final String _sql = "SELECT * FROM mesas WHERE ativa = 0 OR cliente_id IS NULL ORDER BY numero ASC";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 0);
    return CoroutinesRoom.createFlow(__db, false, new String[] {"mesas"}, new Callable<List<Mesa>>() {
      @Override
      @NonNull
      public List<Mesa> call() throws Exception {
        final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
        try {
          final int _cursorIndexOfId = CursorUtil.getColumnIndexOrThrow(_cursor, "id");
          final int _cursorIndexOfNumero = CursorUtil.getColumnIndexOrThrow(_cursor, "numero");
          final int _cursorIndexOfClienteId = CursorUtil.getColumnIndexOrThrow(_cursor, "cliente_id");
          final int _cursorIndexOfFichasInicial = CursorUtil.getColumnIndexOrThrow(_cursor, "fichas_inicial");
          final int _cursorIndexOfFichasFinal = CursorUtil.getColumnIndexOrThrow(_cursor, "fichas_final");
          final int _cursorIndexOfRelogioInicial = CursorUtil.getColumnIndexOrThrow(_cursor, "relogio_inicial");
          final int _cursorIndexOfRelogioFinal = CursorUtil.getColumnIndexOrThrow(_cursor, "relogio_final");
          final int _cursorIndexOfValorFixo = CursorUtil.getColumnIndexOrThrow(_cursor, "valor_fixo");
          final int _cursorIndexOfTipoMesa = CursorUtil.getColumnIndexOrThrow(_cursor, "tipo_mesa");
          final int _cursorIndexOfAtiva = CursorUtil.getColumnIndexOrThrow(_cursor, "ativa");
          final int _cursorIndexOfObservacoes = CursorUtil.getColumnIndexOrThrow(_cursor, "observacoes");
          final int _cursorIndexOfDataInstalacao = CursorUtil.getColumnIndexOrThrow(_cursor, "data_instalacao");
          final int _cursorIndexOfDataUltimaLeitura = CursorUtil.getColumnIndexOrThrow(_cursor, "data_ultima_leitura");
          final List<Mesa> _result = new ArrayList<Mesa>(_cursor.getCount());
          while (_cursor.moveToNext()) {
            final Mesa _item;
            final long _tmpId;
            _tmpId = _cursor.getLong(_cursorIndexOfId);
            final String _tmpNumero;
            if (_cursor.isNull(_cursorIndexOfNumero)) {
              _tmpNumero = null;
            } else {
              _tmpNumero = _cursor.getString(_cursorIndexOfNumero);
            }
            final Long _tmpClienteId;
            if (_cursor.isNull(_cursorIndexOfClienteId)) {
              _tmpClienteId = null;
            } else {
              _tmpClienteId = _cursor.getLong(_cursorIndexOfClienteId);
            }
            final int _tmpFichasInicial;
            _tmpFichasInicial = _cursor.getInt(_cursorIndexOfFichasInicial);
            final int _tmpFichasFinal;
            _tmpFichasFinal = _cursor.getInt(_cursorIndexOfFichasFinal);
            final int _tmpRelogioInicial;
            _tmpRelogioInicial = _cursor.getInt(_cursorIndexOfRelogioInicial);
            final int _tmpRelogioFinal;
            _tmpRelogioFinal = _cursor.getInt(_cursorIndexOfRelogioFinal);
            final double _tmpValorFixo;
            _tmpValorFixo = _cursor.getDouble(_cursorIndexOfValorFixo);
            final TipoMesa _tmpTipoMesa;
            final String _tmp;
            if (_cursor.isNull(_cursorIndexOfTipoMesa)) {
              _tmp = null;
            } else {
              _tmp = _cursor.getString(_cursorIndexOfTipoMesa);
            }
            _tmpTipoMesa = __converters.toTipoMesa(_tmp);
            final boolean _tmpAtiva;
            final int _tmp_1;
            _tmp_1 = _cursor.getInt(_cursorIndexOfAtiva);
            _tmpAtiva = _tmp_1 != 0;
            final String _tmpObservacoes;
            if (_cursor.isNull(_cursorIndexOfObservacoes)) {
              _tmpObservacoes = null;
            } else {
              _tmpObservacoes = _cursor.getString(_cursorIndexOfObservacoes);
            }
            final Date _tmpDataInstalacao;
            final Long _tmp_2;
            if (_cursor.isNull(_cursorIndexOfDataInstalacao)) {
              _tmp_2 = null;
            } else {
              _tmp_2 = _cursor.getLong(_cursorIndexOfDataInstalacao);
            }
            _tmpDataInstalacao = __converters.fromTimestamp(_tmp_2);
            final Date _tmpDataUltimaLeitura;
            final Long _tmp_3;
            if (_cursor.isNull(_cursorIndexOfDataUltimaLeitura)) {
              _tmp_3 = null;
            } else {
              _tmp_3 = _cursor.getLong(_cursorIndexOfDataUltimaLeitura);
            }
            _tmpDataUltimaLeitura = __converters.fromTimestamp(_tmp_3);
            _item = new Mesa(_tmpId,_tmpNumero,_tmpClienteId,_tmpFichasInicial,_tmpFichasFinal,_tmpRelogioInicial,_tmpRelogioFinal,_tmpValorFixo,_tmpTipoMesa,_tmpAtiva,_tmpObservacoes,_tmpDataInstalacao,_tmpDataUltimaLeitura);
            _result.add(_item);
          }
          return _result;
        } finally {
          _cursor.close();
        }
      }

      @Override
      protected void finalize() {
        _statement.release();
      }
    });
  }

  @Override
  public Object obterMesaPorId(final long mesaId, final Continuation<? super Mesa> $completion) {
    final String _sql = "SELECT * FROM mesas WHERE id = ?";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 1);
    int _argIndex = 1;
    _statement.bindLong(_argIndex, mesaId);
    final CancellationSignal _cancellationSignal = DBUtil.createCancellationSignal();
    return CoroutinesRoom.execute(__db, false, _cancellationSignal, new Callable<Mesa>() {
      @Override
      @Nullable
      public Mesa call() throws Exception {
        final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
        try {
          final int _cursorIndexOfId = CursorUtil.getColumnIndexOrThrow(_cursor, "id");
          final int _cursorIndexOfNumero = CursorUtil.getColumnIndexOrThrow(_cursor, "numero");
          final int _cursorIndexOfClienteId = CursorUtil.getColumnIndexOrThrow(_cursor, "cliente_id");
          final int _cursorIndexOfFichasInicial = CursorUtil.getColumnIndexOrThrow(_cursor, "fichas_inicial");
          final int _cursorIndexOfFichasFinal = CursorUtil.getColumnIndexOrThrow(_cursor, "fichas_final");
          final int _cursorIndexOfRelogioInicial = CursorUtil.getColumnIndexOrThrow(_cursor, "relogio_inicial");
          final int _cursorIndexOfRelogioFinal = CursorUtil.getColumnIndexOrThrow(_cursor, "relogio_final");
          final int _cursorIndexOfValorFixo = CursorUtil.getColumnIndexOrThrow(_cursor, "valor_fixo");
          final int _cursorIndexOfTipoMesa = CursorUtil.getColumnIndexOrThrow(_cursor, "tipo_mesa");
          final int _cursorIndexOfAtiva = CursorUtil.getColumnIndexOrThrow(_cursor, "ativa");
          final int _cursorIndexOfObservacoes = CursorUtil.getColumnIndexOrThrow(_cursor, "observacoes");
          final int _cursorIndexOfDataInstalacao = CursorUtil.getColumnIndexOrThrow(_cursor, "data_instalacao");
          final int _cursorIndexOfDataUltimaLeitura = CursorUtil.getColumnIndexOrThrow(_cursor, "data_ultima_leitura");
          final Mesa _result;
          if (_cursor.moveToFirst()) {
            final long _tmpId;
            _tmpId = _cursor.getLong(_cursorIndexOfId);
            final String _tmpNumero;
            if (_cursor.isNull(_cursorIndexOfNumero)) {
              _tmpNumero = null;
            } else {
              _tmpNumero = _cursor.getString(_cursorIndexOfNumero);
            }
            final Long _tmpClienteId;
            if (_cursor.isNull(_cursorIndexOfClienteId)) {
              _tmpClienteId = null;
            } else {
              _tmpClienteId = _cursor.getLong(_cursorIndexOfClienteId);
            }
            final int _tmpFichasInicial;
            _tmpFichasInicial = _cursor.getInt(_cursorIndexOfFichasInicial);
            final int _tmpFichasFinal;
            _tmpFichasFinal = _cursor.getInt(_cursorIndexOfFichasFinal);
            final int _tmpRelogioInicial;
            _tmpRelogioInicial = _cursor.getInt(_cursorIndexOfRelogioInicial);
            final int _tmpRelogioFinal;
            _tmpRelogioFinal = _cursor.getInt(_cursorIndexOfRelogioFinal);
            final double _tmpValorFixo;
            _tmpValorFixo = _cursor.getDouble(_cursorIndexOfValorFixo);
            final TipoMesa _tmpTipoMesa;
            final String _tmp;
            if (_cursor.isNull(_cursorIndexOfTipoMesa)) {
              _tmp = null;
            } else {
              _tmp = _cursor.getString(_cursorIndexOfTipoMesa);
            }
            _tmpTipoMesa = __converters.toTipoMesa(_tmp);
            final boolean _tmpAtiva;
            final int _tmp_1;
            _tmp_1 = _cursor.getInt(_cursorIndexOfAtiva);
            _tmpAtiva = _tmp_1 != 0;
            final String _tmpObservacoes;
            if (_cursor.isNull(_cursorIndexOfObservacoes)) {
              _tmpObservacoes = null;
            } else {
              _tmpObservacoes = _cursor.getString(_cursorIndexOfObservacoes);
            }
            final Date _tmpDataInstalacao;
            final Long _tmp_2;
            if (_cursor.isNull(_cursorIndexOfDataInstalacao)) {
              _tmp_2 = null;
            } else {
              _tmp_2 = _cursor.getLong(_cursorIndexOfDataInstalacao);
            }
            _tmpDataInstalacao = __converters.fromTimestamp(_tmp_2);
            final Date _tmpDataUltimaLeitura;
            final Long _tmp_3;
            if (_cursor.isNull(_cursorIndexOfDataUltimaLeitura)) {
              _tmp_3 = null;
            } else {
              _tmp_3 = _cursor.getLong(_cursorIndexOfDataUltimaLeitura);
            }
            _tmpDataUltimaLeitura = __converters.fromTimestamp(_tmp_3);
            _result = new Mesa(_tmpId,_tmpNumero,_tmpClienteId,_tmpFichasInicial,_tmpFichasFinal,_tmpRelogioInicial,_tmpRelogioFinal,_tmpValorFixo,_tmpTipoMesa,_tmpAtiva,_tmpObservacoes,_tmpDataInstalacao,_tmpDataUltimaLeitura);
          } else {
            _result = null;
          }
          return _result;
        } finally {
          _cursor.close();
          _statement.release();
        }
      }
    }, $completion);
  }

  @NonNull
  public static List<Class<?>> getRequiredConverters() {
    return Collections.emptyList();
  }
}
