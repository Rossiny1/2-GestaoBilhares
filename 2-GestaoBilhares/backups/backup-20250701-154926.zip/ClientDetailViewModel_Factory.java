package com.example.gestaobilhares.ui.clients;

import com.example.gestaobilhares.data.repositories.ClienteRepository;
import com.example.gestaobilhares.data.repository.AcertoRepository;
import com.example.gestaobilhares.data.repository.MesaRepository;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import javax.inject.Provider;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava"
})
public final class ClientDetailViewModel_Factory implements Factory<ClientDetailViewModel> {
  private final Provider<ClienteRepository> clienteRepositoryProvider;

  private final Provider<MesaRepository> mesaRepositoryProvider;

  private final Provider<AcertoRepository> acertoRepositoryProvider;

  public ClientDetailViewModel_Factory(Provider<ClienteRepository> clienteRepositoryProvider,
      Provider<MesaRepository> mesaRepositoryProvider,
      Provider<AcertoRepository> acertoRepositoryProvider) {
    this.clienteRepositoryProvider = clienteRepositoryProvider;
    this.mesaRepositoryProvider = mesaRepositoryProvider;
    this.acertoRepositoryProvider = acertoRepositoryProvider;
  }

  @Override
  public ClientDetailViewModel get() {
    return newInstance(clienteRepositoryProvider.get(), mesaRepositoryProvider.get(), acertoRepositoryProvider.get());
  }

  public static ClientDetailViewModel_Factory create(
      Provider<ClienteRepository> clienteRepositoryProvider,
      Provider<MesaRepository> mesaRepositoryProvider,
      Provider<AcertoRepository> acertoRepositoryProvider) {
    return new ClientDetailViewModel_Factory(clienteRepositoryProvider, mesaRepositoryProvider, acertoRepositoryProvider);
  }

  public static ClientDetailViewModel newInstance(ClienteRepository clienteRepository,
      MesaRepository mesaRepository, AcertoRepository acertoRepository) {
    return new ClientDetailViewModel(clienteRepository, mesaRepository, acertoRepository);
  }
}
