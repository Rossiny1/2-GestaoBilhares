package com.example.gestaobilhares.ui.mesas;

import com.example.gestaobilhares.data.repository.MesaRepository;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import javax.inject.Provider;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava"
})
public final class MesasDepositoViewModel_Factory implements Factory<MesasDepositoViewModel> {
  private final Provider<MesaRepository> mesaRepositoryProvider;

  public MesasDepositoViewModel_Factory(Provider<MesaRepository> mesaRepositoryProvider) {
    this.mesaRepositoryProvider = mesaRepositoryProvider;
  }

  @Override
  public MesasDepositoViewModel get() {
    return newInstance(mesaRepositoryProvider.get());
  }

  public static MesasDepositoViewModel_Factory create(
      Provider<MesaRepository> mesaRepositoryProvider) {
    return new MesasDepositoViewModel_Factory(mesaRepositoryProvider);
  }

  public static MesasDepositoViewModel newInstance(MesaRepository mesaRepository) {
    return new MesasDepositoViewModel(mesaRepository);
  }
}
