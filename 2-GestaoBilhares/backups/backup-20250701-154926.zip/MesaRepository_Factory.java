package com.example.gestaobilhares.data.repository;

import com.example.gestaobilhares.data.dao.MesaDao;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import javax.inject.Provider;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava"
})
public final class MesaRepository_Factory implements Factory<MesaRepository> {
  private final Provider<MesaDao> mesaDaoProvider;

  public MesaRepository_Factory(Provider<MesaDao> mesaDaoProvider) {
    this.mesaDaoProvider = mesaDaoProvider;
  }

  @Override
  public MesaRepository get() {
    return newInstance(mesaDaoProvider.get());
  }

  public static MesaRepository_Factory create(Provider<MesaDao> mesaDaoProvider) {
    return new MesaRepository_Factory(mesaDaoProvider);
  }

  public static MesaRepository newInstance(MesaDao mesaDao) {
    return new MesaRepository(mesaDao);
  }
}
