package com.example.gestaobilhares.ui.settlement;

import com.example.gestaobilhares.data.repository.AcertoMesaRepository;
import com.example.gestaobilhares.data.repository.AcertoRepository;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import javax.inject.Provider;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava"
})
public final class SettlementDetailViewModel_Factory implements Factory<SettlementDetailViewModel> {
  private final Provider<AcertoRepository> acertoRepositoryProvider;

  private final Provider<AcertoMesaRepository> acertoMesaRepositoryProvider;

  public SettlementDetailViewModel_Factory(Provider<AcertoRepository> acertoRepositoryProvider,
      Provider<AcertoMesaRepository> acertoMesaRepositoryProvider) {
    this.acertoRepositoryProvider = acertoRepositoryProvider;
    this.acertoMesaRepositoryProvider = acertoMesaRepositoryProvider;
  }

  @Override
  public SettlementDetailViewModel get() {
    return newInstance(acertoRepositoryProvider.get(), acertoMesaRepositoryProvider.get());
  }

  public static SettlementDetailViewModel_Factory create(
      Provider<AcertoRepository> acertoRepositoryProvider,
      Provider<AcertoMesaRepository> acertoMesaRepositoryProvider) {
    return new SettlementDetailViewModel_Factory(acertoRepositoryProvider, acertoMesaRepositoryProvider);
  }

  public static SettlementDetailViewModel newInstance(AcertoRepository acertoRepository,
      AcertoMesaRepository acertoMesaRepository) {
    return new SettlementDetailViewModel(acertoRepository, acertoMesaRepository);
  }
}
