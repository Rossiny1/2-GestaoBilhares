package com.example.gestaobilhares.data.database;

import androidx.annotation.NonNull;
import androidx.room.DatabaseConfiguration;
import androidx.room.InvalidationTracker;
import androidx.room.RoomDatabase;
import androidx.room.RoomOpenHelper;
import androidx.room.migration.AutoMigrationSpec;
import androidx.room.migration.Migration;
import androidx.room.util.DBUtil;
import androidx.room.util.TableInfo;
import androidx.sqlite.db.SupportSQLiteDatabase;
import androidx.sqlite.db.SupportSQLiteOpenHelper;
import com.example.gestaobilhares.data.dao.AcertoDao;
import com.example.gestaobilhares.data.dao.AcertoDao_Impl;
import com.example.gestaobilhares.data.dao.ClienteDao;
import com.example.gestaobilhares.data.dao.ClienteDao_Impl;
import com.example.gestaobilhares.data.dao.DespesaDao;
import com.example.gestaobilhares.data.dao.DespesaDao_Impl;
import com.example.gestaobilhares.data.dao.MesaDao;
import com.example.gestaobilhares.data.dao.MesaDao_Impl;
import com.example.gestaobilhares.data.dao.RotaDao;
import com.example.gestaobilhares.data.dao.RotaDao_Impl;
import java.lang.Class;
import java.lang.Override;
import java.lang.String;
import java.lang.SuppressWarnings;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.annotation.processing.Generated;

@Generated("androidx.room.RoomProcessor")
@SuppressWarnings({"unchecked", "deprecation"})
public final class AppDatabase_Impl extends AppDatabase {
  private volatile RotaDao _rotaDao;

  private volatile ClienteDao _clienteDao;

  private volatile MesaDao _mesaDao;

  private volatile AcertoDao _acertoDao;

  private volatile DespesaDao _despesaDao;

  @Override
  @NonNull
  protected SupportSQLiteOpenHelper createOpenHelper(@NonNull final DatabaseConfiguration config) {
    final SupportSQLiteOpenHelper.Callback _openCallback = new RoomOpenHelper(config, new RoomOpenHelper.Delegate(6) {
      @Override
      public void createAllTables(@NonNull final SupportSQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS `rotas` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `nome` TEXT NOT NULL, `descricao` TEXT NOT NULL, `colaboradorResponsavel` TEXT NOT NULL, `cidades` TEXT NOT NULL, `ativa` INTEGER NOT NULL, `cor` TEXT NOT NULL, `dataCriacao` INTEGER NOT NULL, `dataAtualizacao` INTEGER NOT NULL)");
        db.execSQL("CREATE TABLE IF NOT EXISTS `clientes` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `nome` TEXT NOT NULL, `nome_fantasia` TEXT, `cnpj` TEXT, `telefone` TEXT, `email` TEXT, `endereco` TEXT, `cidade` TEXT, `estado` TEXT, `cep` TEXT, `rota_id` INTEGER NOT NULL, `valor_ficha` REAL NOT NULL, `comissao_ficha` REAL NOT NULL, `numero_contrato` TEXT, `debito_anterior` REAL NOT NULL, `ativo` INTEGER NOT NULL, `observacoes` TEXT, `data_cadastro` INTEGER NOT NULL, `data_ultima_atualizacao` INTEGER NOT NULL, FOREIGN KEY(`rota_id`) REFERENCES `rotas`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )");
        db.execSQL("CREATE INDEX IF NOT EXISTS `index_clientes_rota_id` ON `clientes` (`rota_id`)");
        db.execSQL("CREATE TABLE IF NOT EXISTS `mesas` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `numero` TEXT NOT NULL, `cliente_id` INTEGER, `fichas_inicial` INTEGER NOT NULL, `fichas_final` INTEGER NOT NULL, `valor_fixo` REAL NOT NULL, `tipo_mesa` TEXT NOT NULL, `ativa` INTEGER NOT NULL, `observacoes` TEXT, `data_instalacao` INTEGER NOT NULL, `data_ultima_leitura` INTEGER NOT NULL, FOREIGN KEY(`cliente_id`) REFERENCES `clientes`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )");
        db.execSQL("CREATE INDEX IF NOT EXISTS `index_mesas_cliente_id` ON `mesas` (`cliente_id`)");
        db.execSQL("CREATE TABLE IF NOT EXISTS `colaboradores` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `nome` TEXT NOT NULL, `email` TEXT NOT NULL, `telefone` TEXT, `cpf` TEXT, `nivel_acesso` TEXT NOT NULL, `ativo` INTEGER NOT NULL, `firebase_uid` TEXT, `data_cadastro` INTEGER NOT NULL, `data_ultimo_acesso` INTEGER)");
        db.execSQL("CREATE TABLE IF NOT EXISTS `acertos` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `cliente_id` INTEGER NOT NULL, `colaborador_id` INTEGER, `data_acerto` INTEGER NOT NULL, `periodo_inicio` INTEGER NOT NULL, `periodo_fim` INTEGER NOT NULL, `total_mesas` REAL NOT NULL, `debito_anterior` REAL NOT NULL, `valor_total` REAL NOT NULL, `desconto` REAL NOT NULL, `valor_com_desconto` REAL NOT NULL, `valor_recebido` REAL NOT NULL, `debito_atual` REAL NOT NULL, `status` TEXT NOT NULL, `observacoes` TEXT, `data_criacao` INTEGER NOT NULL, `data_finalizacao` INTEGER, FOREIGN KEY(`cliente_id`) REFERENCES `clientes`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE , FOREIGN KEY(`colaborador_id`) REFERENCES `colaboradores`(`id`) ON UPDATE NO ACTION ON DELETE SET NULL )");
        db.execSQL("CREATE INDEX IF NOT EXISTS `index_acertos_cliente_id` ON `acertos` (`cliente_id`)");
        db.execSQL("CREATE INDEX IF NOT EXISTS `index_acertos_colaborador_id` ON `acertos` (`colaborador_id`)");
        db.execSQL("CREATE TABLE IF NOT EXISTS `despesas` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `rotaId` INTEGER NOT NULL, `descricao` TEXT NOT NULL, `valor` REAL NOT NULL, `categoria` TEXT NOT NULL, `dataHora` TEXT NOT NULL, `observacoes` TEXT NOT NULL, `criadoPor` TEXT NOT NULL, FOREIGN KEY(`rotaId`) REFERENCES `rotas`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )");
        db.execSQL("CREATE INDEX IF NOT EXISTS `index_despesas_rotaId` ON `despesas` (`rotaId`)");
        db.execSQL("CREATE TABLE IF NOT EXISTS room_master_table (id INTEGER PRIMARY KEY,identity_hash TEXT)");
        db.execSQL("INSERT OR REPLACE INTO room_master_table (id,identity_hash) VALUES(42, 'e396871ee80a8ae7b5efadc33af360b7')");
      }

      @Override
      public void dropAllTables(@NonNull final SupportSQLiteDatabase db) {
        db.execSQL("DROP TABLE IF EXISTS `rotas`");
        db.execSQL("DROP TABLE IF EXISTS `clientes`");
        db.execSQL("DROP TABLE IF EXISTS `mesas`");
        db.execSQL("DROP TABLE IF EXISTS `colaboradores`");
        db.execSQL("DROP TABLE IF EXISTS `acertos`");
        db.execSQL("DROP TABLE IF EXISTS `despesas`");
        final List<? extends RoomDatabase.Callback> _callbacks = mCallbacks;
        if (_callbacks != null) {
          for (RoomDatabase.Callback _callback : _callbacks) {
            _callback.onDestructiveMigration(db);
          }
        }
      }

      @Override
      public void onCreate(@NonNull final SupportSQLiteDatabase db) {
        final List<? extends RoomDatabase.Callback> _callbacks = mCallbacks;
        if (_callbacks != null) {
          for (RoomDatabase.Callback _callback : _callbacks) {
            _callback.onCreate(db);
          }
        }
      }

      @Override
      public void onOpen(@NonNull final SupportSQLiteDatabase db) {
        mDatabase = db;
        db.execSQL("PRAGMA foreign_keys = ON");
        internalInitInvalidationTracker(db);
        final List<? extends RoomDatabase.Callback> _callbacks = mCallbacks;
        if (_callbacks != null) {
          for (RoomDatabase.Callback _callback : _callbacks) {
            _callback.onOpen(db);
          }
        }
      }

      @Override
      public void onPreMigrate(@NonNull final SupportSQLiteDatabase db) {
        DBUtil.dropFtsSyncTriggers(db);
      }

      @Override
      public void onPostMigrate(@NonNull final SupportSQLiteDatabase db) {
      }

      @Override
      @NonNull
      public RoomOpenHelper.ValidationResult onValidateSchema(
          @NonNull final SupportSQLiteDatabase db) {
        final HashMap<String, TableInfo.Column> _columnsRotas = new HashMap<String, TableInfo.Column>(9);
        _columnsRotas.put("id", new TableInfo.Column("id", "INTEGER", true, 1, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsRotas.put("nome", new TableInfo.Column("nome", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsRotas.put("descricao", new TableInfo.Column("descricao", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsRotas.put("colaboradorResponsavel", new TableInfo.Column("colaboradorResponsavel", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsRotas.put("cidades", new TableInfo.Column("cidades", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsRotas.put("ativa", new TableInfo.Column("ativa", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsRotas.put("cor", new TableInfo.Column("cor", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsRotas.put("dataCriacao", new TableInfo.Column("dataCriacao", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsRotas.put("dataAtualizacao", new TableInfo.Column("dataAtualizacao", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        final HashSet<TableInfo.ForeignKey> _foreignKeysRotas = new HashSet<TableInfo.ForeignKey>(0);
        final HashSet<TableInfo.Index> _indicesRotas = new HashSet<TableInfo.Index>(0);
        final TableInfo _infoRotas = new TableInfo("rotas", _columnsRotas, _foreignKeysRotas, _indicesRotas);
        final TableInfo _existingRotas = TableInfo.read(db, "rotas");
        if (!_infoRotas.equals(_existingRotas)) {
          return new RoomOpenHelper.ValidationResult(false, "rotas(com.example.gestaobilhares.data.entities.Rota).\n"
                  + " Expected:\n" + _infoRotas + "\n"
                  + " Found:\n" + _existingRotas);
        }
        final HashMap<String, TableInfo.Column> _columnsClientes = new HashMap<String, TableInfo.Column>(19);
        _columnsClientes.put("id", new TableInfo.Column("id", "INTEGER", true, 1, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsClientes.put("nome", new TableInfo.Column("nome", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsClientes.put("nome_fantasia", new TableInfo.Column("nome_fantasia", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsClientes.put("cnpj", new TableInfo.Column("cnpj", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsClientes.put("telefone", new TableInfo.Column("telefone", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsClientes.put("email", new TableInfo.Column("email", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsClientes.put("endereco", new TableInfo.Column("endereco", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsClientes.put("cidade", new TableInfo.Column("cidade", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsClientes.put("estado", new TableInfo.Column("estado", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsClientes.put("cep", new TableInfo.Column("cep", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsClientes.put("rota_id", new TableInfo.Column("rota_id", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsClientes.put("valor_ficha", new TableInfo.Column("valor_ficha", "REAL", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsClientes.put("comissao_ficha", new TableInfo.Column("comissao_ficha", "REAL", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsClientes.put("numero_contrato", new TableInfo.Column("numero_contrato", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsClientes.put("debito_anterior", new TableInfo.Column("debito_anterior", "REAL", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsClientes.put("ativo", new TableInfo.Column("ativo", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsClientes.put("observacoes", new TableInfo.Column("observacoes", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsClientes.put("data_cadastro", new TableInfo.Column("data_cadastro", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsClientes.put("data_ultima_atualizacao", new TableInfo.Column("data_ultima_atualizacao", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        final HashSet<TableInfo.ForeignKey> _foreignKeysClientes = new HashSet<TableInfo.ForeignKey>(1);
        _foreignKeysClientes.add(new TableInfo.ForeignKey("rotas", "CASCADE", "NO ACTION", Arrays.asList("rota_id"), Arrays.asList("id")));
        final HashSet<TableInfo.Index> _indicesClientes = new HashSet<TableInfo.Index>(1);
        _indicesClientes.add(new TableInfo.Index("index_clientes_rota_id", false, Arrays.asList("rota_id"), Arrays.asList("ASC")));
        final TableInfo _infoClientes = new TableInfo("clientes", _columnsClientes, _foreignKeysClientes, _indicesClientes);
        final TableInfo _existingClientes = TableInfo.read(db, "clientes");
        if (!_infoClientes.equals(_existingClientes)) {
          return new RoomOpenHelper.ValidationResult(false, "clientes(com.example.gestaobilhares.data.entities.Cliente).\n"
                  + " Expected:\n" + _infoClientes + "\n"
                  + " Found:\n" + _existingClientes);
        }
        final HashMap<String, TableInfo.Column> _columnsMesas = new HashMap<String, TableInfo.Column>(11);
        _columnsMesas.put("id", new TableInfo.Column("id", "INTEGER", true, 1, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsMesas.put("numero", new TableInfo.Column("numero", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsMesas.put("cliente_id", new TableInfo.Column("cliente_id", "INTEGER", false, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsMesas.put("fichas_inicial", new TableInfo.Column("fichas_inicial", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsMesas.put("fichas_final", new TableInfo.Column("fichas_final", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsMesas.put("valor_fixo", new TableInfo.Column("valor_fixo", "REAL", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsMesas.put("tipo_mesa", new TableInfo.Column("tipo_mesa", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsMesas.put("ativa", new TableInfo.Column("ativa", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsMesas.put("observacoes", new TableInfo.Column("observacoes", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsMesas.put("data_instalacao", new TableInfo.Column("data_instalacao", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsMesas.put("data_ultima_leitura", new TableInfo.Column("data_ultima_leitura", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        final HashSet<TableInfo.ForeignKey> _foreignKeysMesas = new HashSet<TableInfo.ForeignKey>(1);
        _foreignKeysMesas.add(new TableInfo.ForeignKey("clientes", "CASCADE", "NO ACTION", Arrays.asList("cliente_id"), Arrays.asList("id")));
        final HashSet<TableInfo.Index> _indicesMesas = new HashSet<TableInfo.Index>(1);
        _indicesMesas.add(new TableInfo.Index("index_mesas_cliente_id", false, Arrays.asList("cliente_id"), Arrays.asList("ASC")));
        final TableInfo _infoMesas = new TableInfo("mesas", _columnsMesas, _foreignKeysMesas, _indicesMesas);
        final TableInfo _existingMesas = TableInfo.read(db, "mesas");
        if (!_infoMesas.equals(_existingMesas)) {
          return new RoomOpenHelper.ValidationResult(false, "mesas(com.example.gestaobilhares.data.entities.Mesa).\n"
                  + " Expected:\n" + _infoMesas + "\n"
                  + " Found:\n" + _existingMesas);
        }
        final HashMap<String, TableInfo.Column> _columnsColaboradores = new HashMap<String, TableInfo.Column>(10);
        _columnsColaboradores.put("id", new TableInfo.Column("id", "INTEGER", true, 1, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsColaboradores.put("nome", new TableInfo.Column("nome", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsColaboradores.put("email", new TableInfo.Column("email", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsColaboradores.put("telefone", new TableInfo.Column("telefone", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsColaboradores.put("cpf", new TableInfo.Column("cpf", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsColaboradores.put("nivel_acesso", new TableInfo.Column("nivel_acesso", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsColaboradores.put("ativo", new TableInfo.Column("ativo", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsColaboradores.put("firebase_uid", new TableInfo.Column("firebase_uid", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsColaboradores.put("data_cadastro", new TableInfo.Column("data_cadastro", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsColaboradores.put("data_ultimo_acesso", new TableInfo.Column("data_ultimo_acesso", "INTEGER", false, 0, null, TableInfo.CREATED_FROM_ENTITY));
        final HashSet<TableInfo.ForeignKey> _foreignKeysColaboradores = new HashSet<TableInfo.ForeignKey>(0);
        final HashSet<TableInfo.Index> _indicesColaboradores = new HashSet<TableInfo.Index>(0);
        final TableInfo _infoColaboradores = new TableInfo("colaboradores", _columnsColaboradores, _foreignKeysColaboradores, _indicesColaboradores);
        final TableInfo _existingColaboradores = TableInfo.read(db, "colaboradores");
        if (!_infoColaboradores.equals(_existingColaboradores)) {
          return new RoomOpenHelper.ValidationResult(false, "colaboradores(com.example.gestaobilhares.data.entities.Colaborador).\n"
                  + " Expected:\n" + _infoColaboradores + "\n"
                  + " Found:\n" + _existingColaboradores);
        }
        final HashMap<String, TableInfo.Column> _columnsAcertos = new HashMap<String, TableInfo.Column>(17);
        _columnsAcertos.put("id", new TableInfo.Column("id", "INTEGER", true, 1, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsAcertos.put("cliente_id", new TableInfo.Column("cliente_id", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsAcertos.put("colaborador_id", new TableInfo.Column("colaborador_id", "INTEGER", false, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsAcertos.put("data_acerto", new TableInfo.Column("data_acerto", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsAcertos.put("periodo_inicio", new TableInfo.Column("periodo_inicio", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsAcertos.put("periodo_fim", new TableInfo.Column("periodo_fim", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsAcertos.put("total_mesas", new TableInfo.Column("total_mesas", "REAL", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsAcertos.put("debito_anterior", new TableInfo.Column("debito_anterior", "REAL", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsAcertos.put("valor_total", new TableInfo.Column("valor_total", "REAL", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsAcertos.put("desconto", new TableInfo.Column("desconto", "REAL", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsAcertos.put("valor_com_desconto", new TableInfo.Column("valor_com_desconto", "REAL", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsAcertos.put("valor_recebido", new TableInfo.Column("valor_recebido", "REAL", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsAcertos.put("debito_atual", new TableInfo.Column("debito_atual", "REAL", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsAcertos.put("status", new TableInfo.Column("status", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsAcertos.put("observacoes", new TableInfo.Column("observacoes", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsAcertos.put("data_criacao", new TableInfo.Column("data_criacao", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsAcertos.put("data_finalizacao", new TableInfo.Column("data_finalizacao", "INTEGER", false, 0, null, TableInfo.CREATED_FROM_ENTITY));
        final HashSet<TableInfo.ForeignKey> _foreignKeysAcertos = new HashSet<TableInfo.ForeignKey>(2);
        _foreignKeysAcertos.add(new TableInfo.ForeignKey("clientes", "CASCADE", "NO ACTION", Arrays.asList("cliente_id"), Arrays.asList("id")));
        _foreignKeysAcertos.add(new TableInfo.ForeignKey("colaboradores", "SET NULL", "NO ACTION", Arrays.asList("colaborador_id"), Arrays.asList("id")));
        final HashSet<TableInfo.Index> _indicesAcertos = new HashSet<TableInfo.Index>(2);
        _indicesAcertos.add(new TableInfo.Index("index_acertos_cliente_id", false, Arrays.asList("cliente_id"), Arrays.asList("ASC")));
        _indicesAcertos.add(new TableInfo.Index("index_acertos_colaborador_id", false, Arrays.asList("colaborador_id"), Arrays.asList("ASC")));
        final TableInfo _infoAcertos = new TableInfo("acertos", _columnsAcertos, _foreignKeysAcertos, _indicesAcertos);
        final TableInfo _existingAcertos = TableInfo.read(db, "acertos");
        if (!_infoAcertos.equals(_existingAcertos)) {
          return new RoomOpenHelper.ValidationResult(false, "acertos(com.example.gestaobilhares.data.entities.Acerto).\n"
                  + " Expected:\n" + _infoAcertos + "\n"
                  + " Found:\n" + _existingAcertos);
        }
        final HashMap<String, TableInfo.Column> _columnsDespesas = new HashMap<String, TableInfo.Column>(8);
        _columnsDespesas.put("id", new TableInfo.Column("id", "INTEGER", true, 1, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsDespesas.put("rotaId", new TableInfo.Column("rotaId", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsDespesas.put("descricao", new TableInfo.Column("descricao", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsDespesas.put("valor", new TableInfo.Column("valor", "REAL", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsDespesas.put("categoria", new TableInfo.Column("categoria", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsDespesas.put("dataHora", new TableInfo.Column("dataHora", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsDespesas.put("observacoes", new TableInfo.Column("observacoes", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsDespesas.put("criadoPor", new TableInfo.Column("criadoPor", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        final HashSet<TableInfo.ForeignKey> _foreignKeysDespesas = new HashSet<TableInfo.ForeignKey>(1);
        _foreignKeysDespesas.add(new TableInfo.ForeignKey("rotas", "CASCADE", "NO ACTION", Arrays.asList("rotaId"), Arrays.asList("id")));
        final HashSet<TableInfo.Index> _indicesDespesas = new HashSet<TableInfo.Index>(1);
        _indicesDespesas.add(new TableInfo.Index("index_despesas_rotaId", false, Arrays.asList("rotaId"), Arrays.asList("ASC")));
        final TableInfo _infoDespesas = new TableInfo("despesas", _columnsDespesas, _foreignKeysDespesas, _indicesDespesas);
        final TableInfo _existingDespesas = TableInfo.read(db, "despesas");
        if (!_infoDespesas.equals(_existingDespesas)) {
          return new RoomOpenHelper.ValidationResult(false, "despesas(com.example.gestaobilhares.data.entities.Despesa).\n"
                  + " Expected:\n" + _infoDespesas + "\n"
                  + " Found:\n" + _existingDespesas);
        }
        return new RoomOpenHelper.ValidationResult(true, null);
      }
    }, "e396871ee80a8ae7b5efadc33af360b7", "dca541c2116224f25b18fa4931d316ce");
    final SupportSQLiteOpenHelper.Configuration _sqliteConfig = SupportSQLiteOpenHelper.Configuration.builder(config.context).name(config.name).callback(_openCallback).build();
    final SupportSQLiteOpenHelper _helper = config.sqliteOpenHelperFactory.create(_sqliteConfig);
    return _helper;
  }

  @Override
  @NonNull
  protected InvalidationTracker createInvalidationTracker() {
    final HashMap<String, String> _shadowTablesMap = new HashMap<String, String>(0);
    final HashMap<String, Set<String>> _viewTables = new HashMap<String, Set<String>>(0);
    return new InvalidationTracker(this, _shadowTablesMap, _viewTables, "rotas","clientes","mesas","colaboradores","acertos","despesas");
  }

  @Override
  public void clearAllTables() {
    super.assertNotMainThread();
    final SupportSQLiteDatabase _db = super.getOpenHelper().getWritableDatabase();
    final boolean _supportsDeferForeignKeys = android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP;
    try {
      if (!_supportsDeferForeignKeys) {
        _db.execSQL("PRAGMA foreign_keys = FALSE");
      }
      super.beginTransaction();
      if (_supportsDeferForeignKeys) {
        _db.execSQL("PRAGMA defer_foreign_keys = TRUE");
      }
      _db.execSQL("DELETE FROM `rotas`");
      _db.execSQL("DELETE FROM `clientes`");
      _db.execSQL("DELETE FROM `mesas`");
      _db.execSQL("DELETE FROM `colaboradores`");
      _db.execSQL("DELETE FROM `acertos`");
      _db.execSQL("DELETE FROM `despesas`");
      super.setTransactionSuccessful();
    } finally {
      super.endTransaction();
      if (!_supportsDeferForeignKeys) {
        _db.execSQL("PRAGMA foreign_keys = TRUE");
      }
      _db.query("PRAGMA wal_checkpoint(FULL)").close();
      if (!_db.inTransaction()) {
        _db.execSQL("VACUUM");
      }
    }
  }

  @Override
  @NonNull
  protected Map<Class<?>, List<Class<?>>> getRequiredTypeConverters() {
    final HashMap<Class<?>, List<Class<?>>> _typeConvertersMap = new HashMap<Class<?>, List<Class<?>>>();
    _typeConvertersMap.put(RotaDao.class, RotaDao_Impl.getRequiredConverters());
    _typeConvertersMap.put(ClienteDao.class, ClienteDao_Impl.getRequiredConverters());
    _typeConvertersMap.put(MesaDao.class, MesaDao_Impl.getRequiredConverters());
    _typeConvertersMap.put(AcertoDao.class, AcertoDao_Impl.getRequiredConverters());
    _typeConvertersMap.put(DespesaDao.class, DespesaDao_Impl.getRequiredConverters());
    return _typeConvertersMap;
  }

  @Override
  @NonNull
  public Set<Class<? extends AutoMigrationSpec>> getRequiredAutoMigrationSpecs() {
    final HashSet<Class<? extends AutoMigrationSpec>> _autoMigrationSpecsSet = new HashSet<Class<? extends AutoMigrationSpec>>();
    return _autoMigrationSpecsSet;
  }

  @Override
  @NonNull
  public List<Migration> getAutoMigrations(
      @NonNull final Map<Class<? extends AutoMigrationSpec>, AutoMigrationSpec> autoMigrationSpecs) {
    final List<Migration> _autoMigrations = new ArrayList<Migration>();
    return _autoMigrations;
  }

  @Override
  public RotaDao rotaDao() {
    if (_rotaDao != null) {
      return _rotaDao;
    } else {
      synchronized(this) {
        if(_rotaDao == null) {
          _rotaDao = new RotaDao_Impl(this);
        }
        return _rotaDao;
      }
    }
  }

  @Override
  public ClienteDao clienteDao() {
    if (_clienteDao != null) {
      return _clienteDao;
    } else {
      synchronized(this) {
        if(_clienteDao == null) {
          _clienteDao = new ClienteDao_Impl(this);
        }
        return _clienteDao;
      }
    }
  }

  @Override
  public MesaDao mesaDao() {
    if (_mesaDao != null) {
      return _mesaDao;
    } else {
      synchronized(this) {
        if(_mesaDao == null) {
          _mesaDao = new MesaDao_Impl(this);
        }
        return _mesaDao;
      }
    }
  }

  @Override
  public AcertoDao acertoDao() {
    if (_acertoDao != null) {
      return _acertoDao;
    } else {
      synchronized(this) {
        if(_acertoDao == null) {
          _acertoDao = new AcertoDao_Impl(this);
        }
        return _acertoDao;
      }
    }
  }

  @Override
  public DespesaDao despesaDao() {
    if (_despesaDao != null) {
      return _despesaDao;
    } else {
      synchronized(this) {
        if(_despesaDao == null) {
          _despesaDao = new DespesaDao_Impl(this);
        }
        return _despesaDao;
      }
    }
  }
}
