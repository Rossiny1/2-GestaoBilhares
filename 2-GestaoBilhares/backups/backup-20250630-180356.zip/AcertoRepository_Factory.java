package com.example.gestaobilhares.data.repository;

import com.example.gestaobilhares.data.dao.AcertoDao;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import javax.inject.Provider;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava"
})
public final class AcertoRepository_Factory implements Factory<AcertoRepository> {
  private final Provider<AcertoDao> acertoDaoProvider;

  public AcertoRepository_Factory(Provider<AcertoDao> acertoDaoProvider) {
    this.acertoDaoProvider = acertoDaoProvider;
  }

  @Override
  public AcertoRepository get() {
    return newInstance(acertoDaoProvider.get());
  }

  public static AcertoRepository_Factory create(Provider<AcertoDao> acertoDaoProvider) {
    return new AcertoRepository_Factory(acertoDaoProvider);
  }

  public static AcertoRepository newInstance(AcertoDao acertoDao) {
    return new AcertoRepository(acertoDao);
  }
}
