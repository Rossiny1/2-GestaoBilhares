package com.example.gestaobilhares.ui.settlement

import android.os.Bundle
import androidx.lifecycle.SavedStateHandle
import androidx.navigation.NavArgs
import java.lang.IllegalArgumentException
import kotlin.Long
import kotlin.jvm.JvmStatic

public data class SettlementDetailFragmentArgs(
  public val acertoId: Long = 0L,
) : NavArgs {
  public fun toBundle(): Bundle {
    val result = Bundle()
    result.putLong("acertoId", this.acertoId)
    return result
  }

  public fun toSavedStateHandle(): SavedStateHandle {
    val result = SavedStateHandle()
    result.set("acertoId", this.acertoId)
    return result
  }

  public companion object {
    @JvmStatic
    public fun fromBundle(bundle: Bundle): SettlementDetailFragmentArgs {
      bundle.setClassLoader(SettlementDetailFragmentArgs::class.java.classLoader)
      val __acertoId : Long
      if (bundle.containsKey("acertoId")) {
        __acertoId = bundle.getLong("acertoId")
      } else {
        __acertoId = 0L
      }
      return SettlementDetailFragmentArgs(__acertoId)
    }

    @JvmStatic
    public fun fromSavedStateHandle(savedStateHandle: SavedStateHandle):
        SettlementDetailFragmentArgs {
      val __acertoId : Long?
      if (savedStateHandle.contains("acertoId")) {
        __acertoId = savedStateHandle["acertoId"]
        if (__acertoId == null) {
          throw IllegalArgumentException("Argument \"acertoId\" of type long does not support null values")
        }
      } else {
        __acertoId = 0L
      }
      return SettlementDetailFragmentArgs(__acertoId)
    }
  }
}
