package com.example.gestaobilhares.ui.clients;

import com.example.gestaobilhares.data.repositories.ClienteRepository;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import javax.inject.Provider;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava"
})
public final class ClientRegisterViewModel_Factory implements Factory<ClientRegisterViewModel> {
  private final Provider<ClienteRepository> clienteRepositoryProvider;

  public ClientRegisterViewModel_Factory(Provider<ClienteRepository> clienteRepositoryProvider) {
    this.clienteRepositoryProvider = clienteRepositoryProvider;
  }

  @Override
  public ClientRegisterViewModel get() {
    return newInstance(clienteRepositoryProvider.get());
  }

  public static ClientRegisterViewModel_Factory create(
      Provider<ClienteRepository> clienteRepositoryProvider) {
    return new ClientRegisterViewModel_Factory(clienteRepositoryProvider);
  }

  public static ClientRegisterViewModel newInstance(ClienteRepository clienteRepository) {
    return new ClientRegisterViewModel(clienteRepository);
  }
}
