package com.example.gestaobilhares.ui.clients

import android.os.Bundle
import androidx.lifecycle.SavedStateHandle
import androidx.navigation.NavArgs
import java.lang.IllegalArgumentException
import kotlin.Long
import kotlin.jvm.JvmStatic

public data class ClientListFragmentArgs(
  public val rotaId: Long = 0L,
) : NavArgs {
  public fun toBundle(): Bundle {
    val result = Bundle()
    result.putLong("rotaId", this.rotaId)
    return result
  }

  public fun toSavedStateHandle(): SavedStateHandle {
    val result = SavedStateHandle()
    result.set("rotaId", this.rotaId)
    return result
  }

  public companion object {
    @JvmStatic
    public fun fromBundle(bundle: Bundle): ClientListFragmentArgs {
      bundle.setClassLoader(ClientListFragmentArgs::class.java.classLoader)
      val __rotaId : Long
      if (bundle.containsKey("rotaId")) {
        __rotaId = bundle.getLong("rotaId")
      } else {
        __rotaId = 0L
      }
      return ClientListFragmentArgs(__rotaId)
    }

    @JvmStatic
    public fun fromSavedStateHandle(savedStateHandle: SavedStateHandle): ClientListFragmentArgs {
      val __rotaId : Long?
      if (savedStateHandle.contains("rotaId")) {
        __rotaId = savedStateHandle["rotaId"]
        if (__rotaId == null) {
          throw IllegalArgumentException("Argument \"rotaId\" of type long does not support null values")
        }
      } else {
        __rotaId = 0L
      }
      return ClientListFragmentArgs(__rotaId)
    }
  }
}
