package com.example.gestaobilhares.ui.routes.management;

import com.example.gestaobilhares.data.repository.RotaRepository;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import javax.inject.Provider;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava"
})
public final class RouteManagementViewModel_Factory implements Factory<RouteManagementViewModel> {
  private final Provider<RotaRepository> rotaRepositoryProvider;

  public RouteManagementViewModel_Factory(Provider<RotaRepository> rotaRepositoryProvider) {
    this.rotaRepositoryProvider = rotaRepositoryProvider;
  }

  @Override
  public RouteManagementViewModel get() {
    return newInstance(rotaRepositoryProvider.get());
  }

  public static RouteManagementViewModel_Factory create(
      Provider<RotaRepository> rotaRepositoryProvider) {
    return new RouteManagementViewModel_Factory(rotaRepositoryProvider);
  }

  public static RouteManagementViewModel newInstance(RotaRepository rotaRepository) {
    return new RouteManagementViewModel(rotaRepository);
  }
}
