package com.example.gestaobilhares.ui.clients

import android.os.Bundle
import androidx.navigation.NavDirections
import com.example.gestaobilhares.R
import kotlin.Int
import kotlin.Long

public class ClientListFragmentDirections private constructor() {
  private data class ActionClientListFragmentToClientDetailFragment(
    public val clienteId: Long = 0L,
  ) : NavDirections {
    public override val actionId: Int = R.id.action_clientListFragment_to_clientDetailFragment

    public override val arguments: Bundle
      get() {
        val result = Bundle()
        result.putLong("clienteId", this.clienteId)
        return result
      }
  }

  private data class ActionClientListFragmentToClientRegisterFragment(
    public val rotaId: Long = 0L,
  ) : NavDirections {
    public override val actionId: Int = R.id.action_clientListFragment_to_clientRegisterFragment

    public override val arguments: Bundle
      get() {
        val result = Bundle()
        result.putLong("rotaId", this.rotaId)
        return result
      }
  }

  public companion object {
    public fun actionClientListFragmentToClientDetailFragment(clienteId: Long = 0L): NavDirections =
        ActionClientListFragmentToClientDetailFragment(clienteId)

    public fun actionClientListFragmentToClientRegisterFragment(rotaId: Long = 0L): NavDirections =
        ActionClientListFragmentToClientRegisterFragment(rotaId)
  }
}
