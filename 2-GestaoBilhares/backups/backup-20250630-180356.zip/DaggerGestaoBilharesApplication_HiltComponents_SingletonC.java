package com.example.gestaobilhares;

import android.app.Activity;
import android.app.Service;
import android.view.View;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.SavedStateHandle;
import androidx.lifecycle.ViewModel;
import com.example.gestaobilhares.data.dao.AcertoDao;
import com.example.gestaobilhares.data.dao.ClienteDao;
import com.example.gestaobilhares.data.dao.DespesaDao;
import com.example.gestaobilhares.data.dao.MesaDao;
import com.example.gestaobilhares.data.dao.RotaDao;
import com.example.gestaobilhares.data.database.AppDatabase;
import com.example.gestaobilhares.data.repositories.ClienteRepository;
import com.example.gestaobilhares.data.repository.AcertoRepository;
import com.example.gestaobilhares.data.repository.DespesaRepository;
import com.example.gestaobilhares.data.repository.MesaRepository;
import com.example.gestaobilhares.data.repository.RotaRepository;
import com.example.gestaobilhares.di.DatabaseModule;
import com.example.gestaobilhares.di.DatabaseModule_ProvideAcertoDaoFactory;
import com.example.gestaobilhares.di.DatabaseModule_ProvideAcertoRepositoryFactory;
import com.example.gestaobilhares.di.DatabaseModule_ProvideAppDatabaseFactory;
import com.example.gestaobilhares.di.DatabaseModule_ProvideClienteDaoFactory;
import com.example.gestaobilhares.di.DatabaseModule_ProvideDespesaDaoFactory;
import com.example.gestaobilhares.di.DatabaseModule_ProvideMesaDaoFactory;
import com.example.gestaobilhares.di.DatabaseModule_ProvideMesaRepositoryFactory;
import com.example.gestaobilhares.di.DatabaseModule_ProvideRotaDaoFactory;
import com.example.gestaobilhares.ui.auth.LoginFragment;
import com.example.gestaobilhares.ui.clients.ClientDetailFragment;
import com.example.gestaobilhares.ui.clients.ClientDetailViewModel;
import com.example.gestaobilhares.ui.clients.ClientDetailViewModel_HiltModules_KeyModule_ProvideFactory;
import com.example.gestaobilhares.ui.clients.ClientListFragment;
import com.example.gestaobilhares.ui.clients.ClientListViewModel;
import com.example.gestaobilhares.ui.clients.ClientListViewModel_HiltModules_KeyModule_ProvideFactory;
import com.example.gestaobilhares.ui.clients.ClientRegisterFragment;
import com.example.gestaobilhares.ui.clients.ClientRegisterViewModel;
import com.example.gestaobilhares.ui.clients.ClientRegisterViewModel_HiltModules_KeyModule_ProvideFactory;
import com.example.gestaobilhares.ui.expenses.ExpenseHistoryFragment;
import com.example.gestaobilhares.ui.expenses.ExpenseHistoryViewModel;
import com.example.gestaobilhares.ui.expenses.ExpenseHistoryViewModel_HiltModules_KeyModule_ProvideFactory;
import com.example.gestaobilhares.ui.mesas.CadastroMesaFragment;
import com.example.gestaobilhares.ui.mesas.CadastroMesaViewModel;
import com.example.gestaobilhares.ui.mesas.CadastroMesaViewModel_HiltModules_KeyModule_ProvideFactory;
import com.example.gestaobilhares.ui.mesas.MesasDepositoFragment;
import com.example.gestaobilhares.ui.mesas.MesasDepositoViewModel;
import com.example.gestaobilhares.ui.mesas.MesasDepositoViewModel_HiltModules_KeyModule_ProvideFactory;
import com.example.gestaobilhares.ui.routes.RoutesFragment;
import com.example.gestaobilhares.ui.routes.RoutesViewModel;
import com.example.gestaobilhares.ui.routes.RoutesViewModel_HiltModules_KeyModule_ProvideFactory;
import com.example.gestaobilhares.ui.routes.management.RouteManagementFragment;
import com.example.gestaobilhares.ui.routes.management.RouteManagementViewModel;
import com.example.gestaobilhares.ui.routes.management.RouteManagementViewModel_HiltModules_KeyModule_ProvideFactory;
import com.example.gestaobilhares.ui.settlement.SettlementDetailFragment;
import com.example.gestaobilhares.ui.settlement.SettlementFragment;
import com.example.gestaobilhares.ui.settlement.SettlementViewModel;
import com.example.gestaobilhares.ui.settlement.SettlementViewModel_HiltModules_KeyModule_ProvideFactory;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.ImmutableSet;
import dagger.hilt.android.ActivityRetainedLifecycle;
import dagger.hilt.android.ViewModelLifecycle;
import dagger.hilt.android.flags.HiltWrapper_FragmentGetContextFix_FragmentGetContextFixModule;
import dagger.hilt.android.internal.builders.ActivityComponentBuilder;
import dagger.hilt.android.internal.builders.ActivityRetainedComponentBuilder;
import dagger.hilt.android.internal.builders.FragmentComponentBuilder;
import dagger.hilt.android.internal.builders.ServiceComponentBuilder;
import dagger.hilt.android.internal.builders.ViewComponentBuilder;
import dagger.hilt.android.internal.builders.ViewModelComponentBuilder;
import dagger.hilt.android.internal.builders.ViewWithFragmentComponentBuilder;
import dagger.hilt.android.internal.lifecycle.DefaultViewModelFactories;
import dagger.hilt.android.internal.lifecycle.DefaultViewModelFactories_InternalFactoryFactory_Factory;
import dagger.hilt.android.internal.managers.ActivityRetainedComponentManager_LifecycleModule_ProvideActivityRetainedLifecycleFactory;
import dagger.hilt.android.internal.modules.ApplicationContextModule;
import dagger.hilt.android.internal.modules.ApplicationContextModule_ProvideContextFactory;
import dagger.internal.DaggerGenerated;
import dagger.internal.DoubleCheck;
import dagger.internal.Preconditions;
import java.util.Map;
import java.util.Set;
import javax.annotation.processing.Generated;
import javax.inject.Provider;

@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava"
})
public final class DaggerGestaoBilharesApplication_HiltComponents_SingletonC {
  private DaggerGestaoBilharesApplication_HiltComponents_SingletonC() {
  }

  public static Builder builder() {
    return new Builder();
  }

  public static final class Builder {
    private ApplicationContextModule applicationContextModule;

    private Builder() {
    }

    public Builder applicationContextModule(ApplicationContextModule applicationContextModule) {
      this.applicationContextModule = Preconditions.checkNotNull(applicationContextModule);
      return this;
    }

    /**
     * @deprecated This module is declared, but an instance is not used in the component. This method is a no-op. For more, see https://dagger.dev/unused-modules.
     */
    @Deprecated
    public Builder databaseModule(DatabaseModule databaseModule) {
      Preconditions.checkNotNull(databaseModule);
      return this;
    }

    /**
     * @deprecated This module is declared, but an instance is not used in the component. This method is a no-op. For more, see https://dagger.dev/unused-modules.
     */
    @Deprecated
    public Builder hiltWrapper_FragmentGetContextFix_FragmentGetContextFixModule(
        HiltWrapper_FragmentGetContextFix_FragmentGetContextFixModule hiltWrapper_FragmentGetContextFix_FragmentGetContextFixModule) {
      Preconditions.checkNotNull(hiltWrapper_FragmentGetContextFix_FragmentGetContextFixModule);
      return this;
    }

    public GestaoBilharesApplication_HiltComponents.SingletonC build() {
      Preconditions.checkBuilderRequirement(applicationContextModule, ApplicationContextModule.class);
      return new SingletonCImpl(applicationContextModule);
    }
  }

  private static final class ActivityRetainedCBuilder implements GestaoBilharesApplication_HiltComponents.ActivityRetainedC.Builder {
    private final SingletonCImpl singletonCImpl;

    private ActivityRetainedCBuilder(SingletonCImpl singletonCImpl) {
      this.singletonCImpl = singletonCImpl;
    }

    @Override
    public GestaoBilharesApplication_HiltComponents.ActivityRetainedC build() {
      return new ActivityRetainedCImpl(singletonCImpl);
    }
  }

  private static final class ActivityCBuilder implements GestaoBilharesApplication_HiltComponents.ActivityC.Builder {
    private final SingletonCImpl singletonCImpl;

    private final ActivityRetainedCImpl activityRetainedCImpl;

    private Activity activity;

    private ActivityCBuilder(SingletonCImpl singletonCImpl,
        ActivityRetainedCImpl activityRetainedCImpl) {
      this.singletonCImpl = singletonCImpl;
      this.activityRetainedCImpl = activityRetainedCImpl;
    }

    @Override
    public ActivityCBuilder activity(Activity activity) {
      this.activity = Preconditions.checkNotNull(activity);
      return this;
    }

    @Override
    public GestaoBilharesApplication_HiltComponents.ActivityC build() {
      Preconditions.checkBuilderRequirement(activity, Activity.class);
      return new ActivityCImpl(singletonCImpl, activityRetainedCImpl, activity);
    }
  }

  private static final class FragmentCBuilder implements GestaoBilharesApplication_HiltComponents.FragmentC.Builder {
    private final SingletonCImpl singletonCImpl;

    private final ActivityRetainedCImpl activityRetainedCImpl;

    private final ActivityCImpl activityCImpl;

    private Fragment fragment;

    private FragmentCBuilder(SingletonCImpl singletonCImpl,
        ActivityRetainedCImpl activityRetainedCImpl, ActivityCImpl activityCImpl) {
      this.singletonCImpl = singletonCImpl;
      this.activityRetainedCImpl = activityRetainedCImpl;
      this.activityCImpl = activityCImpl;
    }

    @Override
    public FragmentCBuilder fragment(Fragment fragment) {
      this.fragment = Preconditions.checkNotNull(fragment);
      return this;
    }

    @Override
    public GestaoBilharesApplication_HiltComponents.FragmentC build() {
      Preconditions.checkBuilderRequirement(fragment, Fragment.class);
      return new FragmentCImpl(singletonCImpl, activityRetainedCImpl, activityCImpl, fragment);
    }
  }

  private static final class ViewWithFragmentCBuilder implements GestaoBilharesApplication_HiltComponents.ViewWithFragmentC.Builder {
    private final SingletonCImpl singletonCImpl;

    private final ActivityRetainedCImpl activityRetainedCImpl;

    private final ActivityCImpl activityCImpl;

    private final FragmentCImpl fragmentCImpl;

    private View view;

    private ViewWithFragmentCBuilder(SingletonCImpl singletonCImpl,
        ActivityRetainedCImpl activityRetainedCImpl, ActivityCImpl activityCImpl,
        FragmentCImpl fragmentCImpl) {
      this.singletonCImpl = singletonCImpl;
      this.activityRetainedCImpl = activityRetainedCImpl;
      this.activityCImpl = activityCImpl;
      this.fragmentCImpl = fragmentCImpl;
    }

    @Override
    public ViewWithFragmentCBuilder view(View view) {
      this.view = Preconditions.checkNotNull(view);
      return this;
    }

    @Override
    public GestaoBilharesApplication_HiltComponents.ViewWithFragmentC build() {
      Preconditions.checkBuilderRequirement(view, View.class);
      return new ViewWithFragmentCImpl(singletonCImpl, activityRetainedCImpl, activityCImpl, fragmentCImpl, view);
    }
  }

  private static final class ViewCBuilder implements GestaoBilharesApplication_HiltComponents.ViewC.Builder {
    private final SingletonCImpl singletonCImpl;

    private final ActivityRetainedCImpl activityRetainedCImpl;

    private final ActivityCImpl activityCImpl;

    private View view;

    private ViewCBuilder(SingletonCImpl singletonCImpl, ActivityRetainedCImpl activityRetainedCImpl,
        ActivityCImpl activityCImpl) {
      this.singletonCImpl = singletonCImpl;
      this.activityRetainedCImpl = activityRetainedCImpl;
      this.activityCImpl = activityCImpl;
    }

    @Override
    public ViewCBuilder view(View view) {
      this.view = Preconditions.checkNotNull(view);
      return this;
    }

    @Override
    public GestaoBilharesApplication_HiltComponents.ViewC build() {
      Preconditions.checkBuilderRequirement(view, View.class);
      return new ViewCImpl(singletonCImpl, activityRetainedCImpl, activityCImpl, view);
    }
  }

  private static final class ViewModelCBuilder implements GestaoBilharesApplication_HiltComponents.ViewModelC.Builder {
    private final SingletonCImpl singletonCImpl;

    private final ActivityRetainedCImpl activityRetainedCImpl;

    private SavedStateHandle savedStateHandle;

    private ViewModelLifecycle viewModelLifecycle;

    private ViewModelCBuilder(SingletonCImpl singletonCImpl,
        ActivityRetainedCImpl activityRetainedCImpl) {
      this.singletonCImpl = singletonCImpl;
      this.activityRetainedCImpl = activityRetainedCImpl;
    }

    @Override
    public ViewModelCBuilder savedStateHandle(SavedStateHandle handle) {
      this.savedStateHandle = Preconditions.checkNotNull(handle);
      return this;
    }

    @Override
    public ViewModelCBuilder viewModelLifecycle(ViewModelLifecycle viewModelLifecycle) {
      this.viewModelLifecycle = Preconditions.checkNotNull(viewModelLifecycle);
      return this;
    }

    @Override
    public GestaoBilharesApplication_HiltComponents.ViewModelC build() {
      Preconditions.checkBuilderRequirement(savedStateHandle, SavedStateHandle.class);
      Preconditions.checkBuilderRequirement(viewModelLifecycle, ViewModelLifecycle.class);
      return new ViewModelCImpl(singletonCImpl, activityRetainedCImpl, savedStateHandle, viewModelLifecycle);
    }
  }

  private static final class ServiceCBuilder implements GestaoBilharesApplication_HiltComponents.ServiceC.Builder {
    private final SingletonCImpl singletonCImpl;

    private Service service;

    private ServiceCBuilder(SingletonCImpl singletonCImpl) {
      this.singletonCImpl = singletonCImpl;
    }

    @Override
    public ServiceCBuilder service(Service service) {
      this.service = Preconditions.checkNotNull(service);
      return this;
    }

    @Override
    public GestaoBilharesApplication_HiltComponents.ServiceC build() {
      Preconditions.checkBuilderRequirement(service, Service.class);
      return new ServiceCImpl(singletonCImpl, service);
    }
  }

  private static final class ViewWithFragmentCImpl extends GestaoBilharesApplication_HiltComponents.ViewWithFragmentC {
    private final SingletonCImpl singletonCImpl;

    private final ActivityRetainedCImpl activityRetainedCImpl;

    private final ActivityCImpl activityCImpl;

    private final FragmentCImpl fragmentCImpl;

    private final ViewWithFragmentCImpl viewWithFragmentCImpl = this;

    private ViewWithFragmentCImpl(SingletonCImpl singletonCImpl,
        ActivityRetainedCImpl activityRetainedCImpl, ActivityCImpl activityCImpl,
        FragmentCImpl fragmentCImpl, View viewParam) {
      this.singletonCImpl = singletonCImpl;
      this.activityRetainedCImpl = activityRetainedCImpl;
      this.activityCImpl = activityCImpl;
      this.fragmentCImpl = fragmentCImpl;


    }
  }

  private static final class FragmentCImpl extends GestaoBilharesApplication_HiltComponents.FragmentC {
    private final SingletonCImpl singletonCImpl;

    private final ActivityRetainedCImpl activityRetainedCImpl;

    private final ActivityCImpl activityCImpl;

    private final FragmentCImpl fragmentCImpl = this;

    private FragmentCImpl(SingletonCImpl singletonCImpl,
        ActivityRetainedCImpl activityRetainedCImpl, ActivityCImpl activityCImpl,
        Fragment fragmentParam) {
      this.singletonCImpl = singletonCImpl;
      this.activityRetainedCImpl = activityRetainedCImpl;
      this.activityCImpl = activityCImpl;


    }

    @Override
    public void injectLoginFragment(LoginFragment loginFragment) {
    }

    @Override
    public void injectClientDetailFragment(ClientDetailFragment clientDetailFragment) {
    }

    @Override
    public void injectClientListFragment(ClientListFragment clientListFragment) {
    }

    @Override
    public void injectClientRegisterFragment(ClientRegisterFragment clientRegisterFragment) {
    }

    @Override
    public void injectExpenseHistoryFragment(ExpenseHistoryFragment expenseHistoryFragment) {
    }

    @Override
    public void injectCadastroMesaFragment(CadastroMesaFragment cadastroMesaFragment) {
    }

    @Override
    public void injectMesasDepositoFragment(MesasDepositoFragment mesasDepositoFragment) {
    }

    @Override
    public void injectRoutesFragment(RoutesFragment routesFragment) {
    }

    @Override
    public void injectRouteManagementFragment(RouteManagementFragment routeManagementFragment) {
    }

    @Override
    public void injectSettlementDetailFragment(SettlementDetailFragment settlementDetailFragment) {
    }

    @Override
    public void injectSettlementFragment(SettlementFragment settlementFragment) {
    }

    @Override
    public DefaultViewModelFactories.InternalFactoryFactory getHiltInternalFactoryFactory() {
      return activityCImpl.getHiltInternalFactoryFactory();
    }

    @Override
    public ViewWithFragmentComponentBuilder viewWithFragmentComponentBuilder() {
      return new ViewWithFragmentCBuilder(singletonCImpl, activityRetainedCImpl, activityCImpl, fragmentCImpl);
    }
  }

  private static final class ViewCImpl extends GestaoBilharesApplication_HiltComponents.ViewC {
    private final SingletonCImpl singletonCImpl;

    private final ActivityRetainedCImpl activityRetainedCImpl;

    private final ActivityCImpl activityCImpl;

    private final ViewCImpl viewCImpl = this;

    private ViewCImpl(SingletonCImpl singletonCImpl, ActivityRetainedCImpl activityRetainedCImpl,
        ActivityCImpl activityCImpl, View viewParam) {
      this.singletonCImpl = singletonCImpl;
      this.activityRetainedCImpl = activityRetainedCImpl;
      this.activityCImpl = activityCImpl;


    }
  }

  private static final class ActivityCImpl extends GestaoBilharesApplication_HiltComponents.ActivityC {
    private final SingletonCImpl singletonCImpl;

    private final ActivityRetainedCImpl activityRetainedCImpl;

    private final ActivityCImpl activityCImpl = this;

    private ActivityCImpl(SingletonCImpl singletonCImpl,
        ActivityRetainedCImpl activityRetainedCImpl, Activity activityParam) {
      this.singletonCImpl = singletonCImpl;
      this.activityRetainedCImpl = activityRetainedCImpl;


    }

    @Override
    public void injectMainActivity(MainActivity mainActivity) {
    }

    @Override
    public DefaultViewModelFactories.InternalFactoryFactory getHiltInternalFactoryFactory() {
      return DefaultViewModelFactories_InternalFactoryFactory_Factory.newInstance(getViewModelKeys(), new ViewModelCBuilder(singletonCImpl, activityRetainedCImpl));
    }

    @Override
    public Set<String> getViewModelKeys() {
      return ImmutableSet.<String>of(CadastroMesaViewModel_HiltModules_KeyModule_ProvideFactory.provide(), ClientDetailViewModel_HiltModules_KeyModule_ProvideFactory.provide(), ClientListViewModel_HiltModules_KeyModule_ProvideFactory.provide(), ClientRegisterViewModel_HiltModules_KeyModule_ProvideFactory.provide(), ExpenseHistoryViewModel_HiltModules_KeyModule_ProvideFactory.provide(), MesasDepositoViewModel_HiltModules_KeyModule_ProvideFactory.provide(), RouteManagementViewModel_HiltModules_KeyModule_ProvideFactory.provide(), RoutesViewModel_HiltModules_KeyModule_ProvideFactory.provide(), SettlementViewModel_HiltModules_KeyModule_ProvideFactory.provide());
    }

    @Override
    public ViewModelComponentBuilder getViewModelComponentBuilder() {
      return new ViewModelCBuilder(singletonCImpl, activityRetainedCImpl);
    }

    @Override
    public FragmentComponentBuilder fragmentComponentBuilder() {
      return new FragmentCBuilder(singletonCImpl, activityRetainedCImpl, activityCImpl);
    }

    @Override
    public ViewComponentBuilder viewComponentBuilder() {
      return new ViewCBuilder(singletonCImpl, activityRetainedCImpl, activityCImpl);
    }
  }

  private static final class ViewModelCImpl extends GestaoBilharesApplication_HiltComponents.ViewModelC {
    private final SingletonCImpl singletonCImpl;

    private final ActivityRetainedCImpl activityRetainedCImpl;

    private final ViewModelCImpl viewModelCImpl = this;

    private Provider<CadastroMesaViewModel> cadastroMesaViewModelProvider;

    private Provider<ClientDetailViewModel> clientDetailViewModelProvider;

    private Provider<ClientListViewModel> clientListViewModelProvider;

    private Provider<ClientRegisterViewModel> clientRegisterViewModelProvider;

    private Provider<ExpenseHistoryViewModel> expenseHistoryViewModelProvider;

    private Provider<MesasDepositoViewModel> mesasDepositoViewModelProvider;

    private Provider<RouteManagementViewModel> routeManagementViewModelProvider;

    private Provider<RoutesViewModel> routesViewModelProvider;

    private Provider<SettlementViewModel> settlementViewModelProvider;

    private ViewModelCImpl(SingletonCImpl singletonCImpl,
        ActivityRetainedCImpl activityRetainedCImpl, SavedStateHandle savedStateHandleParam,
        ViewModelLifecycle viewModelLifecycleParam) {
      this.singletonCImpl = singletonCImpl;
      this.activityRetainedCImpl = activityRetainedCImpl;

      initialize(savedStateHandleParam, viewModelLifecycleParam);

    }

    @SuppressWarnings("unchecked")
    private void initialize(final SavedStateHandle savedStateHandleParam,
        final ViewModelLifecycle viewModelLifecycleParam) {
      this.cadastroMesaViewModelProvider = new SwitchingProvider<>(singletonCImpl, activityRetainedCImpl, viewModelCImpl, 0);
      this.clientDetailViewModelProvider = new SwitchingProvider<>(singletonCImpl, activityRetainedCImpl, viewModelCImpl, 1);
      this.clientListViewModelProvider = new SwitchingProvider<>(singletonCImpl, activityRetainedCImpl, viewModelCImpl, 2);
      this.clientRegisterViewModelProvider = new SwitchingProvider<>(singletonCImpl, activityRetainedCImpl, viewModelCImpl, 3);
      this.expenseHistoryViewModelProvider = new SwitchingProvider<>(singletonCImpl, activityRetainedCImpl, viewModelCImpl, 4);
      this.mesasDepositoViewModelProvider = new SwitchingProvider<>(singletonCImpl, activityRetainedCImpl, viewModelCImpl, 5);
      this.routeManagementViewModelProvider = new SwitchingProvider<>(singletonCImpl, activityRetainedCImpl, viewModelCImpl, 6);
      this.routesViewModelProvider = new SwitchingProvider<>(singletonCImpl, activityRetainedCImpl, viewModelCImpl, 7);
      this.settlementViewModelProvider = new SwitchingProvider<>(singletonCImpl, activityRetainedCImpl, viewModelCImpl, 8);
    }

    @Override
    public Map<String, Provider<ViewModel>> getHiltViewModelMap() {
      return ImmutableMap.<String, Provider<ViewModel>>builderWithExpectedSize(9).put("com.example.gestaobilhares.ui.mesas.CadastroMesaViewModel", ((Provider) cadastroMesaViewModelProvider)).put("com.example.gestaobilhares.ui.clients.ClientDetailViewModel", ((Provider) clientDetailViewModelProvider)).put("com.example.gestaobilhares.ui.clients.ClientListViewModel", ((Provider) clientListViewModelProvider)).put("com.example.gestaobilhares.ui.clients.ClientRegisterViewModel", ((Provider) clientRegisterViewModelProvider)).put("com.example.gestaobilhares.ui.expenses.ExpenseHistoryViewModel", ((Provider) expenseHistoryViewModelProvider)).put("com.example.gestaobilhares.ui.mesas.MesasDepositoViewModel", ((Provider) mesasDepositoViewModelProvider)).put("com.example.gestaobilhares.ui.routes.management.RouteManagementViewModel", ((Provider) routeManagementViewModelProvider)).put("com.example.gestaobilhares.ui.routes.RoutesViewModel", ((Provider) routesViewModelProvider)).put("com.example.gestaobilhares.ui.settlement.SettlementViewModel", ((Provider) settlementViewModelProvider)).build();
    }

    private static final class SwitchingProvider<T> implements Provider<T> {
      private final SingletonCImpl singletonCImpl;

      private final ActivityRetainedCImpl activityRetainedCImpl;

      private final ViewModelCImpl viewModelCImpl;

      private final int id;

      SwitchingProvider(SingletonCImpl singletonCImpl, ActivityRetainedCImpl activityRetainedCImpl,
          ViewModelCImpl viewModelCImpl, int id) {
        this.singletonCImpl = singletonCImpl;
        this.activityRetainedCImpl = activityRetainedCImpl;
        this.viewModelCImpl = viewModelCImpl;
        this.id = id;
      }

      @SuppressWarnings("unchecked")
      @Override
      public T get() {
        switch (id) {
          case 0: // com.example.gestaobilhares.ui.mesas.CadastroMesaViewModel 
          return (T) new CadastroMesaViewModel(singletonCImpl.mesaRepository());

          case 1: // com.example.gestaobilhares.ui.clients.ClientDetailViewModel 
          return (T) new ClientDetailViewModel(singletonCImpl.clienteRepositoryProvider.get(), singletonCImpl.mesaRepository(), singletonCImpl.acertoRepository());

          case 2: // com.example.gestaobilhares.ui.clients.ClientListViewModel 
          return (T) new ClientListViewModel(singletonCImpl.clienteRepositoryProvider.get());

          case 3: // com.example.gestaobilhares.ui.clients.ClientRegisterViewModel 
          return (T) new ClientRegisterViewModel(singletonCImpl.clienteRepositoryProvider.get());

          case 4: // com.example.gestaobilhares.ui.expenses.ExpenseHistoryViewModel 
          return (T) new ExpenseHistoryViewModel(singletonCImpl.despesaRepositoryProvider.get());

          case 5: // com.example.gestaobilhares.ui.mesas.MesasDepositoViewModel 
          return (T) new MesasDepositoViewModel(singletonCImpl.mesaRepository());

          case 6: // com.example.gestaobilhares.ui.routes.management.RouteManagementViewModel 
          return (T) new RouteManagementViewModel(singletonCImpl.rotaRepositoryProvider.get());

          case 7: // com.example.gestaobilhares.ui.routes.RoutesViewModel 
          return (T) new RoutesViewModel(singletonCImpl.rotaRepositoryProvider.get());

          case 8: // com.example.gestaobilhares.ui.settlement.SettlementViewModel 
          return (T) new SettlementViewModel(singletonCImpl.mesaRepository(), singletonCImpl.clienteRepositoryProvider.get(), singletonCImpl.acertoRepository());

          default: throw new AssertionError(id);
        }
      }
    }
  }

  private static final class ActivityRetainedCImpl extends GestaoBilharesApplication_HiltComponents.ActivityRetainedC {
    private final SingletonCImpl singletonCImpl;

    private final ActivityRetainedCImpl activityRetainedCImpl = this;

    private Provider<ActivityRetainedLifecycle> provideActivityRetainedLifecycleProvider;

    private ActivityRetainedCImpl(SingletonCImpl singletonCImpl) {
      this.singletonCImpl = singletonCImpl;

      initialize();

    }

    @SuppressWarnings("unchecked")
    private void initialize() {
      this.provideActivityRetainedLifecycleProvider = DoubleCheck.provider(new SwitchingProvider<ActivityRetainedLifecycle>(singletonCImpl, activityRetainedCImpl, 0));
    }

    @Override
    public ActivityComponentBuilder activityComponentBuilder() {
      return new ActivityCBuilder(singletonCImpl, activityRetainedCImpl);
    }

    @Override
    public ActivityRetainedLifecycle getActivityRetainedLifecycle() {
      return provideActivityRetainedLifecycleProvider.get();
    }

    private static final class SwitchingProvider<T> implements Provider<T> {
      private final SingletonCImpl singletonCImpl;

      private final ActivityRetainedCImpl activityRetainedCImpl;

      private final int id;

      SwitchingProvider(SingletonCImpl singletonCImpl, ActivityRetainedCImpl activityRetainedCImpl,
          int id) {
        this.singletonCImpl = singletonCImpl;
        this.activityRetainedCImpl = activityRetainedCImpl;
        this.id = id;
      }

      @SuppressWarnings("unchecked")
      @Override
      public T get() {
        switch (id) {
          case 0: // dagger.hilt.android.ActivityRetainedLifecycle 
          return (T) ActivityRetainedComponentManager_LifecycleModule_ProvideActivityRetainedLifecycleFactory.provideActivityRetainedLifecycle();

          default: throw new AssertionError(id);
        }
      }
    }
  }

  private static final class ServiceCImpl extends GestaoBilharesApplication_HiltComponents.ServiceC {
    private final SingletonCImpl singletonCImpl;

    private final ServiceCImpl serviceCImpl = this;

    private ServiceCImpl(SingletonCImpl singletonCImpl, Service serviceParam) {
      this.singletonCImpl = singletonCImpl;


    }
  }

  private static final class SingletonCImpl extends GestaoBilharesApplication_HiltComponents.SingletonC {
    private final ApplicationContextModule applicationContextModule;

    private final SingletonCImpl singletonCImpl = this;

    private Provider<AppDatabase> provideAppDatabaseProvider;

    private Provider<ClienteRepository> clienteRepositoryProvider;

    private Provider<DespesaRepository> despesaRepositoryProvider;

    private Provider<RotaRepository> rotaRepositoryProvider;

    private SingletonCImpl(ApplicationContextModule applicationContextModuleParam) {
      this.applicationContextModule = applicationContextModuleParam;
      initialize(applicationContextModuleParam);

    }

    private MesaDao mesaDao() {
      return DatabaseModule_ProvideMesaDaoFactory.provideMesaDao(provideAppDatabaseProvider.get());
    }

    private MesaRepository mesaRepository() {
      return DatabaseModule_ProvideMesaRepositoryFactory.provideMesaRepository(mesaDao());
    }

    private ClienteDao clienteDao() {
      return DatabaseModule_ProvideClienteDaoFactory.provideClienteDao(provideAppDatabaseProvider.get());
    }

    private AcertoDao acertoDao() {
      return DatabaseModule_ProvideAcertoDaoFactory.provideAcertoDao(provideAppDatabaseProvider.get());
    }

    private AcertoRepository acertoRepository() {
      return DatabaseModule_ProvideAcertoRepositoryFactory.provideAcertoRepository(acertoDao());
    }

    private DespesaDao despesaDao() {
      return DatabaseModule_ProvideDespesaDaoFactory.provideDespesaDao(provideAppDatabaseProvider.get());
    }

    private RotaDao rotaDao() {
      return DatabaseModule_ProvideRotaDaoFactory.provideRotaDao(provideAppDatabaseProvider.get());
    }

    @SuppressWarnings("unchecked")
    private void initialize(final ApplicationContextModule applicationContextModuleParam) {
      this.provideAppDatabaseProvider = DoubleCheck.provider(new SwitchingProvider<AppDatabase>(singletonCImpl, 0));
      this.clienteRepositoryProvider = DoubleCheck.provider(new SwitchingProvider<ClienteRepository>(singletonCImpl, 1));
      this.despesaRepositoryProvider = DoubleCheck.provider(new SwitchingProvider<DespesaRepository>(singletonCImpl, 2));
      this.rotaRepositoryProvider = DoubleCheck.provider(new SwitchingProvider<RotaRepository>(singletonCImpl, 3));
    }

    @Override
    public void injectGestaoBilharesApplication(
        GestaoBilharesApplication gestaoBilharesApplication) {
    }

    @Override
    public Set<Boolean> getDisableFragmentGetContextFix() {
      return ImmutableSet.<Boolean>of();
    }

    @Override
    public ActivityRetainedComponentBuilder retainedComponentBuilder() {
      return new ActivityRetainedCBuilder(singletonCImpl);
    }

    @Override
    public ServiceComponentBuilder serviceComponentBuilder() {
      return new ServiceCBuilder(singletonCImpl);
    }

    private static final class SwitchingProvider<T> implements Provider<T> {
      private final SingletonCImpl singletonCImpl;

      private final int id;

      SwitchingProvider(SingletonCImpl singletonCImpl, int id) {
        this.singletonCImpl = singletonCImpl;
        this.id = id;
      }

      @SuppressWarnings("unchecked")
      @Override
      public T get() {
        switch (id) {
          case 0: // com.example.gestaobilhares.data.database.AppDatabase 
          return (T) DatabaseModule_ProvideAppDatabaseFactory.provideAppDatabase(ApplicationContextModule_ProvideContextFactory.provideContext(singletonCImpl.applicationContextModule));

          case 1: // com.example.gestaobilhares.data.repositories.ClienteRepository 
          return (T) new ClienteRepository(singletonCImpl.clienteDao());

          case 2: // com.example.gestaobilhares.data.repository.DespesaRepository 
          return (T) new DespesaRepository(singletonCImpl.despesaDao());

          case 3: // com.example.gestaobilhares.data.repository.RotaRepository 
          return (T) new RotaRepository(singletonCImpl.rotaDao());

          default: throw new AssertionError(id);
        }
      }
    }
  }
}
