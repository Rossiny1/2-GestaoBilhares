package dagger.hilt.internal.processedrootsentinel.codegen;

import dagger.hilt.internal.processedrootsentinel.ProcessedRootSentinel;

@ProcessedRootSentinel(
    roots = "com.example.gestaobilhares.GestaoBilharesApplication"
)
public final class _com_example_gestaobilhares_GestaoBilharesApplication {
}
