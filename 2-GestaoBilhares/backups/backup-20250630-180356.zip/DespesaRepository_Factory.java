package com.example.gestaobilhares.data.repository;

import com.example.gestaobilhares.data.dao.DespesaDao;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import javax.inject.Provider;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava"
})
public final class DespesaRepository_Factory implements Factory<DespesaRepository> {
  private final Provider<DespesaDao> despesaDaoProvider;

  public DespesaRepository_Factory(Provider<DespesaDao> despesaDaoProvider) {
    this.despesaDaoProvider = despesaDaoProvider;
  }

  @Override
  public DespesaRepository get() {
    return newInstance(despesaDaoProvider.get());
  }

  public static DespesaRepository_Factory create(Provider<DespesaDao> despesaDaoProvider) {
    return new DespesaRepository_Factory(despesaDaoProvider);
  }

  public static DespesaRepository newInstance(DespesaDao despesaDao) {
    return new DespesaRepository(despesaDao);
  }
}
