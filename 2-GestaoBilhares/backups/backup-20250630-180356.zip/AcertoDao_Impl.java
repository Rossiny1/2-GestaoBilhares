package com.example.gestaobilhares.data.dao;

import android.database.Cursor;
import android.os.CancellationSignal;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.room.CoroutinesRoom;
import androidx.room.EntityDeletionOrUpdateAdapter;
import androidx.room.EntityInsertionAdapter;
import androidx.room.RoomDatabase;
import androidx.room.RoomSQLiteQuery;
import androidx.room.util.CursorUtil;
import androidx.room.util.DBUtil;
import androidx.sqlite.db.SupportSQLiteStatement;
import com.example.gestaobilhares.data.database.Converters;
import com.example.gestaobilhares.data.entities.Acerto;
import com.example.gestaobilhares.data.entities.StatusAcerto;
import java.lang.Class;
import java.lang.Exception;
import java.lang.Long;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.lang.SuppressWarnings;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.concurrent.Callable;
import javax.annotation.processing.Generated;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlinx.coroutines.flow.Flow;

@Generated("androidx.room.RoomProcessor")
@SuppressWarnings({"unchecked", "deprecation"})
public final class AcertoDao_Impl implements AcertoDao {
  private final RoomDatabase __db;

  private final EntityInsertionAdapter<Acerto> __insertionAdapterOfAcerto;

  private final Converters __converters = new Converters();

  private final EntityDeletionOrUpdateAdapter<Acerto> __deletionAdapterOfAcerto;

  private final EntityDeletionOrUpdateAdapter<Acerto> __updateAdapterOfAcerto;

  public AcertoDao_Impl(@NonNull final RoomDatabase __db) {
    this.__db = __db;
    this.__insertionAdapterOfAcerto = new EntityInsertionAdapter<Acerto>(__db) {
      @Override
      @NonNull
      protected String createQuery() {
        return "INSERT OR REPLACE INTO `acertos` (`id`,`cliente_id`,`colaborador_id`,`data_acerto`,`periodo_inicio`,`periodo_fim`,`total_mesas`,`debito_anterior`,`valor_total`,`desconto`,`valor_com_desconto`,`valor_recebido`,`debito_atual`,`status`,`observacoes`,`data_criacao`,`data_finalizacao`) VALUES (nullif(?, 0),?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
      }

      @Override
      protected void bind(@NonNull final SupportSQLiteStatement statement,
          @NonNull final Acerto entity) {
        statement.bindLong(1, entity.getId());
        statement.bindLong(2, entity.getClienteId());
        if (entity.getColaboradorId() == null) {
          statement.bindNull(3);
        } else {
          statement.bindLong(3, entity.getColaboradorId());
        }
        final Long _tmp = __converters.dateToTimestamp(entity.getDataAcerto());
        if (_tmp == null) {
          statement.bindNull(4);
        } else {
          statement.bindLong(4, _tmp);
        }
        final Long _tmp_1 = __converters.dateToTimestamp(entity.getPeriodoInicio());
        if (_tmp_1 == null) {
          statement.bindNull(5);
        } else {
          statement.bindLong(5, _tmp_1);
        }
        final Long _tmp_2 = __converters.dateToTimestamp(entity.getPeriodoFim());
        if (_tmp_2 == null) {
          statement.bindNull(6);
        } else {
          statement.bindLong(6, _tmp_2);
        }
        statement.bindDouble(7, entity.getTotalMesas());
        statement.bindDouble(8, entity.getDebitoAnterior());
        statement.bindDouble(9, entity.getValorTotal());
        statement.bindDouble(10, entity.getDesconto());
        statement.bindDouble(11, entity.getValorComDesconto());
        statement.bindDouble(12, entity.getValorRecebido());
        statement.bindDouble(13, entity.getDebitoAtual());
        final String _tmp_3 = __converters.fromStatusAcerto(entity.getStatus());
        if (_tmp_3 == null) {
          statement.bindNull(14);
        } else {
          statement.bindString(14, _tmp_3);
        }
        if (entity.getObservacoes() == null) {
          statement.bindNull(15);
        } else {
          statement.bindString(15, entity.getObservacoes());
        }
        final Long _tmp_4 = __converters.dateToTimestamp(entity.getDataCriacao());
        if (_tmp_4 == null) {
          statement.bindNull(16);
        } else {
          statement.bindLong(16, _tmp_4);
        }
        final Long _tmp_5 = __converters.dateToTimestamp(entity.getDataFinalizacao());
        if (_tmp_5 == null) {
          statement.bindNull(17);
        } else {
          statement.bindLong(17, _tmp_5);
        }
      }
    };
    this.__deletionAdapterOfAcerto = new EntityDeletionOrUpdateAdapter<Acerto>(__db) {
      @Override
      @NonNull
      protected String createQuery() {
        return "DELETE FROM `acertos` WHERE `id` = ?";
      }

      @Override
      protected void bind(@NonNull final SupportSQLiteStatement statement,
          @NonNull final Acerto entity) {
        statement.bindLong(1, entity.getId());
      }
    };
    this.__updateAdapterOfAcerto = new EntityDeletionOrUpdateAdapter<Acerto>(__db) {
      @Override
      @NonNull
      protected String createQuery() {
        return "UPDATE OR ABORT `acertos` SET `id` = ?,`cliente_id` = ?,`colaborador_id` = ?,`data_acerto` = ?,`periodo_inicio` = ?,`periodo_fim` = ?,`total_mesas` = ?,`debito_anterior` = ?,`valor_total` = ?,`desconto` = ?,`valor_com_desconto` = ?,`valor_recebido` = ?,`debito_atual` = ?,`status` = ?,`observacoes` = ?,`data_criacao` = ?,`data_finalizacao` = ? WHERE `id` = ?";
      }

      @Override
      protected void bind(@NonNull final SupportSQLiteStatement statement,
          @NonNull final Acerto entity) {
        statement.bindLong(1, entity.getId());
        statement.bindLong(2, entity.getClienteId());
        if (entity.getColaboradorId() == null) {
          statement.bindNull(3);
        } else {
          statement.bindLong(3, entity.getColaboradorId());
        }
        final Long _tmp = __converters.dateToTimestamp(entity.getDataAcerto());
        if (_tmp == null) {
          statement.bindNull(4);
        } else {
          statement.bindLong(4, _tmp);
        }
        final Long _tmp_1 = __converters.dateToTimestamp(entity.getPeriodoInicio());
        if (_tmp_1 == null) {
          statement.bindNull(5);
        } else {
          statement.bindLong(5, _tmp_1);
        }
        final Long _tmp_2 = __converters.dateToTimestamp(entity.getPeriodoFim());
        if (_tmp_2 == null) {
          statement.bindNull(6);
        } else {
          statement.bindLong(6, _tmp_2);
        }
        statement.bindDouble(7, entity.getTotalMesas());
        statement.bindDouble(8, entity.getDebitoAnterior());
        statement.bindDouble(9, entity.getValorTotal());
        statement.bindDouble(10, entity.getDesconto());
        statement.bindDouble(11, entity.getValorComDesconto());
        statement.bindDouble(12, entity.getValorRecebido());
        statement.bindDouble(13, entity.getDebitoAtual());
        final String _tmp_3 = __converters.fromStatusAcerto(entity.getStatus());
        if (_tmp_3 == null) {
          statement.bindNull(14);
        } else {
          statement.bindString(14, _tmp_3);
        }
        if (entity.getObservacoes() == null) {
          statement.bindNull(15);
        } else {
          statement.bindString(15, entity.getObservacoes());
        }
        final Long _tmp_4 = __converters.dateToTimestamp(entity.getDataCriacao());
        if (_tmp_4 == null) {
          statement.bindNull(16);
        } else {
          statement.bindLong(16, _tmp_4);
        }
        final Long _tmp_5 = __converters.dateToTimestamp(entity.getDataFinalizacao());
        if (_tmp_5 == null) {
          statement.bindNull(17);
        } else {
          statement.bindLong(17, _tmp_5);
        }
        statement.bindLong(18, entity.getId());
      }
    };
  }

  @Override
  public Object inserir(final Acerto acerto, final Continuation<? super Long> arg1) {
    return CoroutinesRoom.execute(__db, true, new Callable<Long>() {
      @Override
      @NonNull
      public Long call() throws Exception {
        __db.beginTransaction();
        try {
          final Long _result = __insertionAdapterOfAcerto.insertAndReturnId(acerto);
          __db.setTransactionSuccessful();
          return _result;
        } finally {
          __db.endTransaction();
        }
      }
    }, arg1);
  }

  @Override
  public Object deletar(final Acerto acerto, final Continuation<? super Unit> arg1) {
    return CoroutinesRoom.execute(__db, true, new Callable<Unit>() {
      @Override
      @NonNull
      public Unit call() throws Exception {
        __db.beginTransaction();
        try {
          __deletionAdapterOfAcerto.handle(acerto);
          __db.setTransactionSuccessful();
          return Unit.INSTANCE;
        } finally {
          __db.endTransaction();
        }
      }
    }, arg1);
  }

  @Override
  public Object atualizar(final Acerto acerto, final Continuation<? super Unit> arg1) {
    return CoroutinesRoom.execute(__db, true, new Callable<Unit>() {
      @Override
      @NonNull
      public Unit call() throws Exception {
        __db.beginTransaction();
        try {
          __updateAdapterOfAcerto.handle(acerto);
          __db.setTransactionSuccessful();
          return Unit.INSTANCE;
        } finally {
          __db.endTransaction();
        }
      }
    }, arg1);
  }

  @Override
  public Flow<List<Acerto>> buscarPorCliente(final long clienteId) {
    final String _sql = "SELECT * FROM acertos WHERE cliente_id = ? ORDER BY data_acerto DESC";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 1);
    int _argIndex = 1;
    _statement.bindLong(_argIndex, clienteId);
    return CoroutinesRoom.createFlow(__db, false, new String[] {"acertos"}, new Callable<List<Acerto>>() {
      @Override
      @NonNull
      public List<Acerto> call() throws Exception {
        final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
        try {
          final int _cursorIndexOfId = CursorUtil.getColumnIndexOrThrow(_cursor, "id");
          final int _cursorIndexOfClienteId = CursorUtil.getColumnIndexOrThrow(_cursor, "cliente_id");
          final int _cursorIndexOfColaboradorId = CursorUtil.getColumnIndexOrThrow(_cursor, "colaborador_id");
          final int _cursorIndexOfDataAcerto = CursorUtil.getColumnIndexOrThrow(_cursor, "data_acerto");
          final int _cursorIndexOfPeriodoInicio = CursorUtil.getColumnIndexOrThrow(_cursor, "periodo_inicio");
          final int _cursorIndexOfPeriodoFim = CursorUtil.getColumnIndexOrThrow(_cursor, "periodo_fim");
          final int _cursorIndexOfTotalMesas = CursorUtil.getColumnIndexOrThrow(_cursor, "total_mesas");
          final int _cursorIndexOfDebitoAnterior = CursorUtil.getColumnIndexOrThrow(_cursor, "debito_anterior");
          final int _cursorIndexOfValorTotal = CursorUtil.getColumnIndexOrThrow(_cursor, "valor_total");
          final int _cursorIndexOfDesconto = CursorUtil.getColumnIndexOrThrow(_cursor, "desconto");
          final int _cursorIndexOfValorComDesconto = CursorUtil.getColumnIndexOrThrow(_cursor, "valor_com_desconto");
          final int _cursorIndexOfValorRecebido = CursorUtil.getColumnIndexOrThrow(_cursor, "valor_recebido");
          final int _cursorIndexOfDebitoAtual = CursorUtil.getColumnIndexOrThrow(_cursor, "debito_atual");
          final int _cursorIndexOfStatus = CursorUtil.getColumnIndexOrThrow(_cursor, "status");
          final int _cursorIndexOfObservacoes = CursorUtil.getColumnIndexOrThrow(_cursor, "observacoes");
          final int _cursorIndexOfDataCriacao = CursorUtil.getColumnIndexOrThrow(_cursor, "data_criacao");
          final int _cursorIndexOfDataFinalizacao = CursorUtil.getColumnIndexOrThrow(_cursor, "data_finalizacao");
          final List<Acerto> _result = new ArrayList<Acerto>(_cursor.getCount());
          while (_cursor.moveToNext()) {
            final Acerto _item;
            final long _tmpId;
            _tmpId = _cursor.getLong(_cursorIndexOfId);
            final long _tmpClienteId;
            _tmpClienteId = _cursor.getLong(_cursorIndexOfClienteId);
            final Long _tmpColaboradorId;
            if (_cursor.isNull(_cursorIndexOfColaboradorId)) {
              _tmpColaboradorId = null;
            } else {
              _tmpColaboradorId = _cursor.getLong(_cursorIndexOfColaboradorId);
            }
            final Date _tmpDataAcerto;
            final Long _tmp;
            if (_cursor.isNull(_cursorIndexOfDataAcerto)) {
              _tmp = null;
            } else {
              _tmp = _cursor.getLong(_cursorIndexOfDataAcerto);
            }
            _tmpDataAcerto = __converters.fromTimestamp(_tmp);
            final Date _tmpPeriodoInicio;
            final Long _tmp_1;
            if (_cursor.isNull(_cursorIndexOfPeriodoInicio)) {
              _tmp_1 = null;
            } else {
              _tmp_1 = _cursor.getLong(_cursorIndexOfPeriodoInicio);
            }
            _tmpPeriodoInicio = __converters.fromTimestamp(_tmp_1);
            final Date _tmpPeriodoFim;
            final Long _tmp_2;
            if (_cursor.isNull(_cursorIndexOfPeriodoFim)) {
              _tmp_2 = null;
            } else {
              _tmp_2 = _cursor.getLong(_cursorIndexOfPeriodoFim);
            }
            _tmpPeriodoFim = __converters.fromTimestamp(_tmp_2);
            final double _tmpTotalMesas;
            _tmpTotalMesas = _cursor.getDouble(_cursorIndexOfTotalMesas);
            final double _tmpDebitoAnterior;
            _tmpDebitoAnterior = _cursor.getDouble(_cursorIndexOfDebitoAnterior);
            final double _tmpValorTotal;
            _tmpValorTotal = _cursor.getDouble(_cursorIndexOfValorTotal);
            final double _tmpDesconto;
            _tmpDesconto = _cursor.getDouble(_cursorIndexOfDesconto);
            final double _tmpValorComDesconto;
            _tmpValorComDesconto = _cursor.getDouble(_cursorIndexOfValorComDesconto);
            final double _tmpValorRecebido;
            _tmpValorRecebido = _cursor.getDouble(_cursorIndexOfValorRecebido);
            final double _tmpDebitoAtual;
            _tmpDebitoAtual = _cursor.getDouble(_cursorIndexOfDebitoAtual);
            final StatusAcerto _tmpStatus;
            final String _tmp_3;
            if (_cursor.isNull(_cursorIndexOfStatus)) {
              _tmp_3 = null;
            } else {
              _tmp_3 = _cursor.getString(_cursorIndexOfStatus);
            }
            _tmpStatus = __converters.toStatusAcerto(_tmp_3);
            final String _tmpObservacoes;
            if (_cursor.isNull(_cursorIndexOfObservacoes)) {
              _tmpObservacoes = null;
            } else {
              _tmpObservacoes = _cursor.getString(_cursorIndexOfObservacoes);
            }
            final Date _tmpDataCriacao;
            final Long _tmp_4;
            if (_cursor.isNull(_cursorIndexOfDataCriacao)) {
              _tmp_4 = null;
            } else {
              _tmp_4 = _cursor.getLong(_cursorIndexOfDataCriacao);
            }
            _tmpDataCriacao = __converters.fromTimestamp(_tmp_4);
            final Date _tmpDataFinalizacao;
            final Long _tmp_5;
            if (_cursor.isNull(_cursorIndexOfDataFinalizacao)) {
              _tmp_5 = null;
            } else {
              _tmp_5 = _cursor.getLong(_cursorIndexOfDataFinalizacao);
            }
            _tmpDataFinalizacao = __converters.fromTimestamp(_tmp_5);
            _item = new Acerto(_tmpId,_tmpClienteId,_tmpColaboradorId,_tmpDataAcerto,_tmpPeriodoInicio,_tmpPeriodoFim,_tmpTotalMesas,_tmpDebitoAnterior,_tmpValorTotal,_tmpDesconto,_tmpValorComDesconto,_tmpValorRecebido,_tmpDebitoAtual,_tmpStatus,_tmpObservacoes,_tmpDataCriacao,_tmpDataFinalizacao);
            _result.add(_item);
          }
          return _result;
        } finally {
          _cursor.close();
        }
      }

      @Override
      protected void finalize() {
        _statement.release();
      }
    });
  }

  @Override
  public Flow<List<Acerto>> listarTodos() {
    final String _sql = "SELECT * FROM acertos ORDER BY data_acerto DESC";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 0);
    return CoroutinesRoom.createFlow(__db, false, new String[] {"acertos"}, new Callable<List<Acerto>>() {
      @Override
      @NonNull
      public List<Acerto> call() throws Exception {
        final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
        try {
          final int _cursorIndexOfId = CursorUtil.getColumnIndexOrThrow(_cursor, "id");
          final int _cursorIndexOfClienteId = CursorUtil.getColumnIndexOrThrow(_cursor, "cliente_id");
          final int _cursorIndexOfColaboradorId = CursorUtil.getColumnIndexOrThrow(_cursor, "colaborador_id");
          final int _cursorIndexOfDataAcerto = CursorUtil.getColumnIndexOrThrow(_cursor, "data_acerto");
          final int _cursorIndexOfPeriodoInicio = CursorUtil.getColumnIndexOrThrow(_cursor, "periodo_inicio");
          final int _cursorIndexOfPeriodoFim = CursorUtil.getColumnIndexOrThrow(_cursor, "periodo_fim");
          final int _cursorIndexOfTotalMesas = CursorUtil.getColumnIndexOrThrow(_cursor, "total_mesas");
          final int _cursorIndexOfDebitoAnterior = CursorUtil.getColumnIndexOrThrow(_cursor, "debito_anterior");
          final int _cursorIndexOfValorTotal = CursorUtil.getColumnIndexOrThrow(_cursor, "valor_total");
          final int _cursorIndexOfDesconto = CursorUtil.getColumnIndexOrThrow(_cursor, "desconto");
          final int _cursorIndexOfValorComDesconto = CursorUtil.getColumnIndexOrThrow(_cursor, "valor_com_desconto");
          final int _cursorIndexOfValorRecebido = CursorUtil.getColumnIndexOrThrow(_cursor, "valor_recebido");
          final int _cursorIndexOfDebitoAtual = CursorUtil.getColumnIndexOrThrow(_cursor, "debito_atual");
          final int _cursorIndexOfStatus = CursorUtil.getColumnIndexOrThrow(_cursor, "status");
          final int _cursorIndexOfObservacoes = CursorUtil.getColumnIndexOrThrow(_cursor, "observacoes");
          final int _cursorIndexOfDataCriacao = CursorUtil.getColumnIndexOrThrow(_cursor, "data_criacao");
          final int _cursorIndexOfDataFinalizacao = CursorUtil.getColumnIndexOrThrow(_cursor, "data_finalizacao");
          final List<Acerto> _result = new ArrayList<Acerto>(_cursor.getCount());
          while (_cursor.moveToNext()) {
            final Acerto _item;
            final long _tmpId;
            _tmpId = _cursor.getLong(_cursorIndexOfId);
            final long _tmpClienteId;
            _tmpClienteId = _cursor.getLong(_cursorIndexOfClienteId);
            final Long _tmpColaboradorId;
            if (_cursor.isNull(_cursorIndexOfColaboradorId)) {
              _tmpColaboradorId = null;
            } else {
              _tmpColaboradorId = _cursor.getLong(_cursorIndexOfColaboradorId);
            }
            final Date _tmpDataAcerto;
            final Long _tmp;
            if (_cursor.isNull(_cursorIndexOfDataAcerto)) {
              _tmp = null;
            } else {
              _tmp = _cursor.getLong(_cursorIndexOfDataAcerto);
            }
            _tmpDataAcerto = __converters.fromTimestamp(_tmp);
            final Date _tmpPeriodoInicio;
            final Long _tmp_1;
            if (_cursor.isNull(_cursorIndexOfPeriodoInicio)) {
              _tmp_1 = null;
            } else {
              _tmp_1 = _cursor.getLong(_cursorIndexOfPeriodoInicio);
            }
            _tmpPeriodoInicio = __converters.fromTimestamp(_tmp_1);
            final Date _tmpPeriodoFim;
            final Long _tmp_2;
            if (_cursor.isNull(_cursorIndexOfPeriodoFim)) {
              _tmp_2 = null;
            } else {
              _tmp_2 = _cursor.getLong(_cursorIndexOfPeriodoFim);
            }
            _tmpPeriodoFim = __converters.fromTimestamp(_tmp_2);
            final double _tmpTotalMesas;
            _tmpTotalMesas = _cursor.getDouble(_cursorIndexOfTotalMesas);
            final double _tmpDebitoAnterior;
            _tmpDebitoAnterior = _cursor.getDouble(_cursorIndexOfDebitoAnterior);
            final double _tmpValorTotal;
            _tmpValorTotal = _cursor.getDouble(_cursorIndexOfValorTotal);
            final double _tmpDesconto;
            _tmpDesconto = _cursor.getDouble(_cursorIndexOfDesconto);
            final double _tmpValorComDesconto;
            _tmpValorComDesconto = _cursor.getDouble(_cursorIndexOfValorComDesconto);
            final double _tmpValorRecebido;
            _tmpValorRecebido = _cursor.getDouble(_cursorIndexOfValorRecebido);
            final double _tmpDebitoAtual;
            _tmpDebitoAtual = _cursor.getDouble(_cursorIndexOfDebitoAtual);
            final StatusAcerto _tmpStatus;
            final String _tmp_3;
            if (_cursor.isNull(_cursorIndexOfStatus)) {
              _tmp_3 = null;
            } else {
              _tmp_3 = _cursor.getString(_cursorIndexOfStatus);
            }
            _tmpStatus = __converters.toStatusAcerto(_tmp_3);
            final String _tmpObservacoes;
            if (_cursor.isNull(_cursorIndexOfObservacoes)) {
              _tmpObservacoes = null;
            } else {
              _tmpObservacoes = _cursor.getString(_cursorIndexOfObservacoes);
            }
            final Date _tmpDataCriacao;
            final Long _tmp_4;
            if (_cursor.isNull(_cursorIndexOfDataCriacao)) {
              _tmp_4 = null;
            } else {
              _tmp_4 = _cursor.getLong(_cursorIndexOfDataCriacao);
            }
            _tmpDataCriacao = __converters.fromTimestamp(_tmp_4);
            final Date _tmpDataFinalizacao;
            final Long _tmp_5;
            if (_cursor.isNull(_cursorIndexOfDataFinalizacao)) {
              _tmp_5 = null;
            } else {
              _tmp_5 = _cursor.getLong(_cursorIndexOfDataFinalizacao);
            }
            _tmpDataFinalizacao = __converters.fromTimestamp(_tmp_5);
            _item = new Acerto(_tmpId,_tmpClienteId,_tmpColaboradorId,_tmpDataAcerto,_tmpPeriodoInicio,_tmpPeriodoFim,_tmpTotalMesas,_tmpDebitoAnterior,_tmpValorTotal,_tmpDesconto,_tmpValorComDesconto,_tmpValorRecebido,_tmpDebitoAtual,_tmpStatus,_tmpObservacoes,_tmpDataCriacao,_tmpDataFinalizacao);
            _result.add(_item);
          }
          return _result;
        } finally {
          _cursor.close();
        }
      }

      @Override
      protected void finalize() {
        _statement.release();
      }
    });
  }

  @Override
  public Object buscarPorId(final long id, final Continuation<? super Acerto> arg1) {
    final String _sql = "SELECT * FROM acertos WHERE id = ?";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 1);
    int _argIndex = 1;
    _statement.bindLong(_argIndex, id);
    final CancellationSignal _cancellationSignal = DBUtil.createCancellationSignal();
    return CoroutinesRoom.execute(__db, false, _cancellationSignal, new Callable<Acerto>() {
      @Override
      @Nullable
      public Acerto call() throws Exception {
        final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
        try {
          final int _cursorIndexOfId = CursorUtil.getColumnIndexOrThrow(_cursor, "id");
          final int _cursorIndexOfClienteId = CursorUtil.getColumnIndexOrThrow(_cursor, "cliente_id");
          final int _cursorIndexOfColaboradorId = CursorUtil.getColumnIndexOrThrow(_cursor, "colaborador_id");
          final int _cursorIndexOfDataAcerto = CursorUtil.getColumnIndexOrThrow(_cursor, "data_acerto");
          final int _cursorIndexOfPeriodoInicio = CursorUtil.getColumnIndexOrThrow(_cursor, "periodo_inicio");
          final int _cursorIndexOfPeriodoFim = CursorUtil.getColumnIndexOrThrow(_cursor, "periodo_fim");
          final int _cursorIndexOfTotalMesas = CursorUtil.getColumnIndexOrThrow(_cursor, "total_mesas");
          final int _cursorIndexOfDebitoAnterior = CursorUtil.getColumnIndexOrThrow(_cursor, "debito_anterior");
          final int _cursorIndexOfValorTotal = CursorUtil.getColumnIndexOrThrow(_cursor, "valor_total");
          final int _cursorIndexOfDesconto = CursorUtil.getColumnIndexOrThrow(_cursor, "desconto");
          final int _cursorIndexOfValorComDesconto = CursorUtil.getColumnIndexOrThrow(_cursor, "valor_com_desconto");
          final int _cursorIndexOfValorRecebido = CursorUtil.getColumnIndexOrThrow(_cursor, "valor_recebido");
          final int _cursorIndexOfDebitoAtual = CursorUtil.getColumnIndexOrThrow(_cursor, "debito_atual");
          final int _cursorIndexOfStatus = CursorUtil.getColumnIndexOrThrow(_cursor, "status");
          final int _cursorIndexOfObservacoes = CursorUtil.getColumnIndexOrThrow(_cursor, "observacoes");
          final int _cursorIndexOfDataCriacao = CursorUtil.getColumnIndexOrThrow(_cursor, "data_criacao");
          final int _cursorIndexOfDataFinalizacao = CursorUtil.getColumnIndexOrThrow(_cursor, "data_finalizacao");
          final Acerto _result;
          if (_cursor.moveToFirst()) {
            final long _tmpId;
            _tmpId = _cursor.getLong(_cursorIndexOfId);
            final long _tmpClienteId;
            _tmpClienteId = _cursor.getLong(_cursorIndexOfClienteId);
            final Long _tmpColaboradorId;
            if (_cursor.isNull(_cursorIndexOfColaboradorId)) {
              _tmpColaboradorId = null;
            } else {
              _tmpColaboradorId = _cursor.getLong(_cursorIndexOfColaboradorId);
            }
            final Date _tmpDataAcerto;
            final Long _tmp;
            if (_cursor.isNull(_cursorIndexOfDataAcerto)) {
              _tmp = null;
            } else {
              _tmp = _cursor.getLong(_cursorIndexOfDataAcerto);
            }
            _tmpDataAcerto = __converters.fromTimestamp(_tmp);
            final Date _tmpPeriodoInicio;
            final Long _tmp_1;
            if (_cursor.isNull(_cursorIndexOfPeriodoInicio)) {
              _tmp_1 = null;
            } else {
              _tmp_1 = _cursor.getLong(_cursorIndexOfPeriodoInicio);
            }
            _tmpPeriodoInicio = __converters.fromTimestamp(_tmp_1);
            final Date _tmpPeriodoFim;
            final Long _tmp_2;
            if (_cursor.isNull(_cursorIndexOfPeriodoFim)) {
              _tmp_2 = null;
            } else {
              _tmp_2 = _cursor.getLong(_cursorIndexOfPeriodoFim);
            }
            _tmpPeriodoFim = __converters.fromTimestamp(_tmp_2);
            final double _tmpTotalMesas;
            _tmpTotalMesas = _cursor.getDouble(_cursorIndexOfTotalMesas);
            final double _tmpDebitoAnterior;
            _tmpDebitoAnterior = _cursor.getDouble(_cursorIndexOfDebitoAnterior);
            final double _tmpValorTotal;
            _tmpValorTotal = _cursor.getDouble(_cursorIndexOfValorTotal);
            final double _tmpDesconto;
            _tmpDesconto = _cursor.getDouble(_cursorIndexOfDesconto);
            final double _tmpValorComDesconto;
            _tmpValorComDesconto = _cursor.getDouble(_cursorIndexOfValorComDesconto);
            final double _tmpValorRecebido;
            _tmpValorRecebido = _cursor.getDouble(_cursorIndexOfValorRecebido);
            final double _tmpDebitoAtual;
            _tmpDebitoAtual = _cursor.getDouble(_cursorIndexOfDebitoAtual);
            final StatusAcerto _tmpStatus;
            final String _tmp_3;
            if (_cursor.isNull(_cursorIndexOfStatus)) {
              _tmp_3 = null;
            } else {
              _tmp_3 = _cursor.getString(_cursorIndexOfStatus);
            }
            _tmpStatus = __converters.toStatusAcerto(_tmp_3);
            final String _tmpObservacoes;
            if (_cursor.isNull(_cursorIndexOfObservacoes)) {
              _tmpObservacoes = null;
            } else {
              _tmpObservacoes = _cursor.getString(_cursorIndexOfObservacoes);
            }
            final Date _tmpDataCriacao;
            final Long _tmp_4;
            if (_cursor.isNull(_cursorIndexOfDataCriacao)) {
              _tmp_4 = null;
            } else {
              _tmp_4 = _cursor.getLong(_cursorIndexOfDataCriacao);
            }
            _tmpDataCriacao = __converters.fromTimestamp(_tmp_4);
            final Date _tmpDataFinalizacao;
            final Long _tmp_5;
            if (_cursor.isNull(_cursorIndexOfDataFinalizacao)) {
              _tmp_5 = null;
            } else {
              _tmp_5 = _cursor.getLong(_cursorIndexOfDataFinalizacao);
            }
            _tmpDataFinalizacao = __converters.fromTimestamp(_tmp_5);
            _result = new Acerto(_tmpId,_tmpClienteId,_tmpColaboradorId,_tmpDataAcerto,_tmpPeriodoInicio,_tmpPeriodoFim,_tmpTotalMesas,_tmpDebitoAnterior,_tmpValorTotal,_tmpDesconto,_tmpValorComDesconto,_tmpValorRecebido,_tmpDebitoAtual,_tmpStatus,_tmpObservacoes,_tmpDataCriacao,_tmpDataFinalizacao);
          } else {
            _result = null;
          }
          return _result;
        } finally {
          _cursor.close();
          _statement.release();
        }
      }
    }, arg1);
  }

  @NonNull
  public static List<Class<?>> getRequiredConverters() {
    return Collections.emptyList();
  }
}
