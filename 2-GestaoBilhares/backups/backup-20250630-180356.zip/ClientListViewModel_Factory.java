package com.example.gestaobilhares.ui.clients;

import com.example.gestaobilhares.data.repositories.ClienteRepository;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import javax.inject.Provider;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava"
})
public final class ClientListViewModel_Factory implements Factory<ClientListViewModel> {
  private final Provider<ClienteRepository> clienteRepositoryProvider;

  public ClientListViewModel_Factory(Provider<ClienteRepository> clienteRepositoryProvider) {
    this.clienteRepositoryProvider = clienteRepositoryProvider;
  }

  @Override
  public ClientListViewModel get() {
    return newInstance(clienteRepositoryProvider.get());
  }

  public static ClientListViewModel_Factory create(
      Provider<ClienteRepository> clienteRepositoryProvider) {
    return new ClientListViewModel_Factory(clienteRepositoryProvider);
  }

  public static ClientListViewModel newInstance(ClienteRepository clienteRepository) {
    return new ClientListViewModel(clienteRepository);
  }
}
