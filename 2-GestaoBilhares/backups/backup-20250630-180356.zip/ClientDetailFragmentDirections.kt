package com.example.gestaobilhares.ui.clients

import android.os.Bundle
import androidx.navigation.NavDirections
import com.example.gestaobilhares.R
import com.example.gestaobilhares.ui.settlement.MesaDTO
import kotlin.Array
import kotlin.Int
import kotlin.Long

public class ClientDetailFragmentDirections private constructor() {
  private data class ActionClientDetailFragmentToSettlementFragment(
    public val mesasCliente: Array<MesaDTO>?,
    public val clienteId: Long = 0L,
  ) : NavDirections {
    public override val actionId: Int = R.id.action_clientDetailFragment_to_settlementFragment

    public override val arguments: Bundle
      get() {
        val result = Bundle()
        result.putLong("clienteId", this.clienteId)
        result.putParcelableArray("mesasCliente", this.mesasCliente)
        return result
      }
  }

  private data class ActionClientDetailFragmentToSettlementDetailFragment(
    public val acertoId: Long = 0L,
  ) : NavDirections {
    public override val actionId: Int = R.id.action_clientDetailFragment_to_settlementDetailFragment

    public override val arguments: Bundle
      get() {
        val result = Bundle()
        result.putLong("acertoId", this.acertoId)
        return result
      }
  }

  private data class ActionClientDetailFragmentToMesasDepositoFragment(
    public val clienteId: Long = 0L,
  ) : NavDirections {
    public override val actionId: Int = R.id.action_clientDetailFragment_to_mesasDepositoFragment

    public override val arguments: Bundle
      get() {
        val result = Bundle()
        result.putLong("clienteId", this.clienteId)
        return result
      }
  }

  public companion object {
    public fun actionClientDetailFragmentToSettlementFragment(mesasCliente: Array<MesaDTO>?,
        clienteId: Long = 0L): NavDirections =
        ActionClientDetailFragmentToSettlementFragment(mesasCliente, clienteId)

    public fun actionClientDetailFragmentToSettlementDetailFragment(acertoId: Long = 0L):
        NavDirections = ActionClientDetailFragmentToSettlementDetailFragment(acertoId)

    public fun actionClientDetailFragmentToMesasDepositoFragment(clienteId: Long = 0L):
        NavDirections = ActionClientDetailFragmentToMesasDepositoFragment(clienteId)
  }
}
